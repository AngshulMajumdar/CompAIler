"""Check whole-function confinement, compiler validation and regression retries."""
import json
from pathlib import Path
import tempfile
from aicc import ROOT,check
from chunk_compile import functions
from function_compile import replace_function,repair
from run_large_programs import COMPILER

def main():
    cases=json.loads((ROOT/'large_program_suite/cases.json').read_text())['cases']
    for c in cases:
        fs=functions(c['source']);assert len({f['name'] for f in fs})==len(fs)==c['metadata']['functions']
        for f in fs:assert replace_function(c['source'],f['name'],'```c\n'+f['text']+'\n```')==c['source']
    source='#include <stdio.h>\nint f(void) { return 1; }\nint main(void) { printf("%d\\n", f()); return 0; }\n'
    for raw in ['int other(void) { return 1; }',
                'int f(void) { return 1; }\nint other(void) { return 2; }',
                'int x;\nint f(void) { return 1; }',
                'long long f(void) { return 1; }']:
        try:replace_function(source,'f',raw)
        except ValueError:pass
        else:raise AssertionError('Invalid scope/interface accepted')
    class Fake:
        def __init__(self):self.n=0
        def propose(self,prompt,target,number):
            self.n+=1
            raw='int f(void) { return 2; }' if self.n==1 else target
            return {'raw':raw,'finish_reason':'stop','seconds':0,'usage':{'prompt_tokens':0,'completion_tokens':0}}
    with tempfile.TemporaryDirectory() as tmp:
        work=Path(tmp);bad=replace_function(source,'f','int f(void) { return + ; }')
        assert not check(bad,work,COMPILER,[{'input':'','output':'1'}])['compiled']
        result=repair(Fake(),source,'Print 1.',[{'input':'','output':'1'}],COMPILER,work/'result')
        assert result['final']['passed'] and result['history'][0]['reason']=='regression_rejected'
        assert result['history'][1]['request']['retry']==1
        assert (work/'result/repaired.c').read_text()==source
    r={'fixture_function_boundaries_and_roundtrip':True,'extra_code_wrong_name_and_signature_rejected':True,
       'compiler_rejects_invalid_body':True,'regressions_rejected_and_retried':True,'unchanged_source_preserved':True}
    (ROOT/'function_guard_checks.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))

if __name__=='__main__':main()
