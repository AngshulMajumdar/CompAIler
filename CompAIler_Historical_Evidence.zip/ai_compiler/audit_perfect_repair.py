"""Reconstruct every selected source from CPU-model proposals and recorded search edits."""
import hashlib
import json
from aicc import ROOT
from chunk_compile import functions,c_tokens
from function_compile import replace_function

def apply(source,edit):
    assert source[edit['start']:edit['end']]==edit['old']
    return source[:edit['start']]+edit['new']+source[edit['end']:]

def main():
    fixture=ROOT/'large_program_suite/cases.json';cases=json.loads(fixture.read_text())['cases']
    for stage,controller in [('search_results','search_compile.py'),('transaction_results','transaction_search.py')]:
        plan=json.loads((ROOT/stage/'frozen_plan.json').read_text())
        assert plan['controller_sha256']==hashlib.sha256((ROOT/controller).read_bytes()).hexdigest()
        assert plan['fixture_sha256']==hashlib.sha256(fixture.read_bytes()).hexdigest()
    rows=[]
    for c in cases:
        folder=ROOT/'function_results'/c['id'];source=c['source']
        report=json.loads((folder/'report.json').read_text())
        for entry in report['history']:
            assert entry['request']['source_sha256']==hashlib.sha256(source.encode()).hexdigest()
            if entry['accepted']:source=replace_function(source,entry['request']['name'],entry['generation']['raw'])
        assert source==(folder/'repaired.c').read_text();model_source=source
        for stage in ['search_results','transaction_results']:
            directory=ROOT/stage/c['id'];r=json.loads((directory/'report.json').read_text())
            if r['seed']=='original':source=c['source']
            elif stage=='search_results':source=model_source
            else:assert source==(directory/'model_seed.c').read_text()
            for edit in r['edits']:source=apply(source,edit)
            assert source==(directory/'repaired.c').read_text()
        get=lambda s:[(f['name'],[t[0] for t in c_tokens(f['signature'])]) for f in functions(s)]
        assert get(source)==get(c['source'])
        if c['kind']=='correct_control':assert source==c['source']
        rows.append({'id':c['id'],'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'reconstructed':True})
    final=json.loads((ROOT/'perfect_verification/summary.json').read_text());assert final['passed']
    for row,verified in zip(rows,final['cases']):assert row['source_sha256']==verified['source_sha256']
    result={'passed':True,'programs':len(rows),'no_manual_C_patches':True,
            'all_function_interfaces_preserved':True,'correct_controls_unchanged':True,
            'original_fixtures_unchanged':True,'recorded_controllers_match_frozen_hashes':True,
            'search_inputs':'Original sources, cached CPU-model proposals and visible tests; no reference C or mutation manifests',
            'all_final_evaluations_passed':True,'cases':rows}
    (ROOT/'perfect_verification/audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
