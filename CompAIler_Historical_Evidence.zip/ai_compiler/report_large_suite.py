"""Create readable results and CSV from the retained case-level evidence."""
import csv
import json
from pathlib import Path
from statistics import median

ROOT=Path(__file__).resolve().parent

def main():
    s=json.loads((ROOT/'large_results/summary.json').read_text())
    rows=s['cases'];faulty=[r for r in rows if r['kind']=='faulty']
    verified=[r for r in faulty if r['validated'] and r['repairs']>0]
    untested=[r for r in faulty if r['validated'] and r['repairs']==0]
    failures=[r for r in faulty if not r['validated']]
    times=[r['generation_seconds'] for r in faulty if r['repairs']]
    fields=['id','task','kind','category','initial_compiled','initial_visible_passed',
            'visible_passed','hidden_passed','validated','repairs','generation_seconds',
            'wall_seconds','hidden_pass_count','hidden_tests','original_unchanged']
    with (ROOT/'large_results/case_results.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
    lines=['# Expanded AI compiler trial','',
           f"Completed **{len(faulty)} faulty variants across {len(set(r['task'] for r in faulty))} tasks**, plus **{s['controls']} correct controls**.",
           '', '## Outcomes','',
           '| Measure | Observed result |','|---|---:|',
           f'| Faulty programs repaired and passing all visible and held-out checks | {len(verified)}/{len(faulty)} |',
           f"| Passed visible checks but failed held-out checks | {s['visible_pass_hidden_fail']} |",
           f'| Faulty programs passing all sampled checks without a model repair | {len(untested)} |',
           f"| Passed after the first model repair, including held-out checks | {s['first_attempt_validated']} |",
           f"| Correct controls left unchanged and passing all checks | {s['controls_unchanged_and_passed']}/{s['controls']} |",
           f"| Held-out input/output executions passing | {s['heldout_passed']}/{s['heldout_tests']} |",
           f"| Total model generation time | {s['total_generation_seconds']/60:.1f} minutes |",
           f'| Median total model generation time per program sent to the model | {median(times):.1f} seconds |',
           '', 'The held-out execution count includes the same task inputs applied to different faulty variants; it is not a count of distinct tasks or unique inputs. Timings exclude downloading, model loading, and execution checks.',
           '', '## Error categories','',
           '| Category | Variants | Passing all checks |','|---|---:|---:|']
    for category,values in s['categories'].items():
        lines.append(f"| {category.replace('_',' ')} | {values['cases']} | {values['validated']} |")
    lines+=['','## Cases that did not pass all checks','',
            '| Case | Repairs attempted | Visible tests | Held-out tests |','|---|---:|---|---:|']
    for r in failures:
        lines.append(f"| {r['id']} | {r['repairs']} | {'Pass' if r['visible_passed'] else 'Fail'} | {r['hidden_pass_count']}/{r['hidden_tests']} |")
    if not failures:lines.append('| None | — | — | — |')
    if failures:
        lines+=['','### Concrete failing examples','',
                '| Case | Input (newlines escaped) | Expected | Actual |','|---|---|---|---|']
        for r in failures:
            folder=ROOT/'large_results'/r['id']
            report=json.loads((folder/'report.json').read_text())
            tests=report['history'][-1]['check']['tests']
            bad=[t for t in tests if not t['passed']]
            if not bad:
                bad=[t for t in json.loads((folder/'heldout.json').read_text())['tests'] if not t['passed']]
            if bad:
                t=bad[0]
                values=[json.dumps(t[key].strip()) for key in ['input','expected','stdout']]
                lines.append(f"| {r['id']} | `{values[0]}` | `{values[1]}` | `{values[2]}` |")
    lines+=['','## How the trial was run','',
            '- Fixed synthetic suite: 24 small C tasks, three single-defect variants each, eight mixed-defect variants, and eight clean controls. Construction seed: 20261123.',
            '- All 24 clean reference implementations first passed their Python-oracle-derived visible and held-out tests with TinyCC.',
            '- Four visible input/output examples per case. All other examples were held out. The model received only the source, a behavioral requirement, compiler diagnostics and visible execution feedback.',
            '- Qwen2.5-Coder-7B-Instruct Q4_K_M, local CPU inference, four threads, zero GPU layers, temperature zero, seed 42; TinyCC 0.9.27.',
            '- Up to three model repair attempts per case. No manual source edits, selective retries, prompt changes, or tuning using held-out results.',
            '- The wrapper first checks the original source. If its visible tests pass, it does not ask the model to rewrite it. This can leave a bug undiscovered when the visible tests miss it; held-out checks expose that limitation.',
            '- Generated executables run with the same filesystem/network restrictions and resource limits as the initial prototype.',
            '', 'This assesses feasibility on deliberately mutated small programs. It does not establish reliability on large repositories, real bug distributions, adversarial programs, or untested inputs. A passing test suite is evidence, not a proof of perfect code.',
            '', '## Inspect and reproduce','',
            '`large_suite/cases.json` contains every original faulty program, behavioral requirement, visible tests and held-out tests. `large_suite/references/` contains the clean sources used only to validate the test harness; they are never included in model requests.',
            '', '`large_results/<case>/` contains the original source, every raw model response, final source, visible compiler/execution history, held-out results and final classification. `large_results/case_results.csv` provides one row per variant.',
            '', 'Run `python run_large_suite.py` after setup. It resumes completed cases. To reproduce a completely fresh trial, move `large_results/` aside first. Run `python report_large_suite.py` to regenerate this report.',
            '']
    (ROOT/'EXPANDED_TRIAL.md').write_text('\n'.join(lines))
    print(json.dumps({'completed':len(rows),'verified_repairs':len(verified),'failures':len(failures),
                      'sampling_blind_spots':len(untested),'heldout_passed':s['heldout_passed'],
                      'heldout_tests':s['heldout_tests']},indent=2))

if __name__=='__main__':main()
