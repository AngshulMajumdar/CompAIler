"""Compact status for the larger-program run."""
import json
from aicc import ROOT
p=ROOT/'large_program_results/summary.json'
if p.exists():
    s=json.loads(p.read_text());print({k:v for k,v in s.items() if k not in ['cases','generation_seconds']})
lines=(ROOT/'large_program_run.log').read_text().splitlines()
print('\n'.join([l for l in lines if not l.startswith(('PROGRESS','REFERENCE','MUTATION','MODEL_END'))][-3:]))
