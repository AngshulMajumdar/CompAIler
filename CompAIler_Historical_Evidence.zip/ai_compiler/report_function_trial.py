"""Report and audit the complete-function CPU trial without hiding failures."""
import hashlib
import json
from aicc import ROOT
from function_compile import replace_function,passing
from chunk_compile import functions

def main():
    out=ROOT/'function_results';p=out/'summary.json';s=json.loads(p.read_text()) if p.exists() else {'cases':[],'completed':0}
    plan=json.loads((out/'frozen_plan.json').read_text())
    fixture=ROOT/'large_program_suite/cases.json';assert hashlib.sha256(fixture.read_bytes()).hexdigest()==plan['fixture_sha256']
    for f,digest in plan['code_sha256'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==digest
    cases=json.loads(fixture.read_text())['cases'];indexed={r['id']:r for r in s['cases']};calls=0
    lines=['# One complete C function at a time','',
      'Qwen2.5-Coder-7B-Instruct Q4_K_M, CPU only, four threads and zero GPU layers. No larger model or paid API is used. This trial replaces fragment-edit JSON with ordinary complete C function definitions.',
      '',f"Completed applications/control probes: {s['completed']}/8.",'',
      '| Program | Lines | Faults | Functions reviewed | Visible | Held-out | Calls | Changed replacements | Model time |',
      '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for c in cases:
        r=indexed.get(c['id'])
        if not r:
            lines.append(f"| {c['id']} | {len(c['source'].splitlines())} | {len(c['mutations'])} | Pending | — | — | — | — | — |")
            continue
        lines.append(f"| {r['id']} | {r['lines']} | {r['faults']} | {r['functions_reviewed']}/{r['functions']} | {r['visible_passed']}/4 | {r['heldout_passed']}/24 | {r['calls']} | {r['changed_replacements']} | {r['model_seconds']/60:.1f} min |")
        folder=out/c['id'];report=json.loads((folder/'report.json').read_text());source=c['source'];best=report['baseline']
        assert report['calls']<=report['function_count']+3
        if c['kind']=='faulty':assert {e['request']['name'] for e in report['history']}=={f['name'] for f in functions(source)}
        assert not {t['input'] for t in c['visible']}.intersection(t['input'] for t in c['heldout'])
        for i,entry in enumerate(report['history'],1):
            calls+=1;assert entry==json.loads((folder/f'call_{i:03d}.json').read_text())
            assert entry['request']['source_sha256']==hashlib.sha256(source.encode()).hexdigest()
            if entry['accepted']:
                generated=replace_function(source,entry['request']['name'],entry['generation']['raw'])
                assert generated==entry['candidate'] and entry['check']['compiled']
                assert passing(best).issubset(passing(entry['check']))
                source=generated;best=entry['check']
        assert source==(folder/'repaired.c').read_text()
        held=json.loads((folder/'heldout.json').read_text())
        assert r['validated']==(report['final']['passed'] and held['passed'])
    if s['cases']:
        lines+=['',f"Faulty applications passing all visible and held-out scenarios: **{s['faulty_validated']}/{s['faulty_completed']}**.",
          '',f"Faulty-input held-out scenarios passed: **{s['faulty_heldout_passed']}/{s['faulty_heldout_total']}**. Clean control probes passing: **{s['controls_validated']}/{s['controls']}**."]
    if s['completed']==8:
        lines+=['', '## Observed result', '',
          'Inventory, with eight simultaneous faults in 185 source lines, passed all four visible and 24 held-out scenarios after seven changed function replacements. The remaining five applications were not fully repaired. Graph queries passed 22/24 held-out scenarios, the parser 9/24 and matrix operations 7/24; gradebook and LRU passed none of their held-out scenarios.', '',
          'The previous grouped-fragment trial passed 0/6 applications and 0/144 held-out scenarios. This complete-function trial passed 1/6 and 62/144. It used 86 calls including two control probes, versus 34 in the fragment trial, so the difference is not attributable to output protocol alone.', '',
          'Completed model inference took 44.5 CPU minutes across the suite. There were 42 changed function replacements, including formatting changes; this is not a count of distinct bugs corrected. Eight proposals were structurally rejected, including six truncated replies. One compiling print-function replacement was rejected for breaking passing scenarios. No applied candidate was rejected by the compiler; separate guard tests deliberately checked malformed-C rejection.', '',
          'Some short initialization and main functions prompted the model to expand beyond their local role and hit the output limit. That is an observed protocol/role problem. Function-specific behavioral contracts and more targeted logical tests are plausible next improvements within the same CPU constraint, but were not tested in this run. No larger model or GPU is proposed as part of this implementation.']
    lines+=['','## Design and limits','',
       'The controller gives the model exactly one current function, the full behavioral requirement, shared declarations, related function signatures, compiler diagnostics and one abbreviated visible integration failure. The output is a complete C definition with the same signature. Deterministic code reinserts only that function.',
       '', 'Every structurally valid replacement is compiled as part of the full program with TinyCC -Wall -Werror, then run against the same four visible scenarios. Replacements must preserve every previously passing complete scenario. Neutral compiling changes can accumulate local repairs before an integration scenario passes. Syntax/type checks do not establish logical correctness.',
       '', 'There is one full pass over all functions in each faulty application, including functions visited after visible examples pass. Compiler diagnostic locations determine which function is visited first when the input does not compile. Rejections can receive one retry with related function bodies and failure feedback, subject to three extra retries per application.',
       '', 'The output limit adapts to the original function token count: at least 256 and at most 1,600 tokens. Context capacity is 8,192 tokens. Generation is ordinary C without a JSON grammar. Function boundaries are identified by the previously checked tolerant lexical scanner; this supports these single-file fixtures, not all C preprocessor or malformed-brace cases.',
       '', 'The same six 179–210-line faulty inputs, 43 injected faults, four visible scenarios and 24 held-out scenarios per application are used. Clean implementations are verified against all 28 scenarios before inference. Reference code, mutation descriptions and held-out scenarios are not sent to the model. Held-out failures do not trigger extra repair.',
       '', 'The two clean controls are explicitly one-function probes, matching the earlier always-review protocol. They verify that reviewing the first region preserves the complete program behavior; they are not full-program model audits.',
       '', 'This policy has more model calls than the earlier five-call whole-file policy or the grouped-fragment policy. Improvements or regressions therefore do not isolate the output protocol from call budget and context differences. Model timings count completed proposals and exclude infrastructure interruptions and compilation/testing time.',
       '', 'No C corrections are written manually during the trial. Raw prompts/replies, selected sources, compiler results and held-out results are retained per application. Each completed proposal is checkpointed; exact request/source matching is required for resume.',
       '', '## Run','',
       'From ai_compiler with the runtime installed: `python test_function_guards.py`, `python run_function_trial.py`, then `python report_function_trial.py`. This workspace uses `PYTHONPATH=../deps` for inference. The regular setup environment can use `.venv/bin/python`.',
       '', 'For a new program, run `python ai_compile_functions.py source.c --requirement-file requirement.txt --tests tests.json --output output_directory`.',
       '']
    (ROOT/'FUNCTION_TRIAL_RESULTS.md').write_text('\n'.join(lines))
    audit={'completed_cases':s['completed'],'completed_model_calls':calls,'all_eight_complete':s['completed']==8,
           'selected_sources_match_original_plus_recorded_function_replacements':True,
           'no_manual_C_repairs':True,'accepted_replacements_compile_and_preserve_passing_scenarios':True,
           'all_functions_visited_in_completed_faulty_applications':True,'frozen_code_and_fixture_hashes_match':True}
    (out/'audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps({k:v for k,v in s.items() if k!='cases'}))

if __name__=='__main__':main()
