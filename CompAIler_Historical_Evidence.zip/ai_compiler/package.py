"""Package code and retained evidence, excluding model weights and installed runtimes."""
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parent
dest=root.parent/'AI_C_Compiler_Prototype.zip'
exclude={'model','vendor','__pycache__','.venv'}
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(root.rglob('*')):
        if f.is_file() and not any(p in exclude for p in f.relative_to(root).parts):
            z.write(f,Path('ai_compiler')/f.relative_to(root))
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    print(dest, dest.stat().st_size, 'bytes;',len(z.namelist()),'files')
