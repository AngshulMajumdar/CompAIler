"""Audit mutation validation, selected-source provenance, frozen policy and final classifications."""
import hashlib
import json
import re
from aicc import ROOT

def code_from(raw,source_marker=False):
    blocks=re.findall(r'```(?:c|C)?\s*\n(.*?)```',raw,re.S)
    return blocks[0] if blocks else (raw.split('SOURCE:',1)[-1].strip() if source_marker else raw.strip())

def main():
    out=ROOT/'large_program_results';fixture=ROOT/'large_program_suite/cases.json'
    cases={c['id']:c for c in json.loads(fixture.read_text())['cases']}
    summary=json.loads((out/'summary.json').read_text());assert summary['completed']==len(cases)==8
    plan=json.loads((out/'frozen_plan.json').read_text());assert plan['cases_sha256']==hashlib.sha256(fixture.read_bytes()).hexdigest()
    for name,digest in plan['code_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
    pre=json.loads((out/'preflight.json').read_text());assert pre['passed']
    assert len(pre['references'])==6 and all(r['passed'] for r in pre['references'].values())
    mutations=[m for group in pre['single_mutations'].values() for m in group.values()]
    assert len(mutations)==43 and all(m['detected'] for m in mutations)
    calls=0;replayed=0
    for row in summary['cases']:
        c=cases[row['id']];folder=out/c['id'];stage2=folder/'v2_stage';stage3=folder/'v3_stage'
        a=json.loads((stage2/'report.json').read_text());b=json.loads((stage3/'report.json').read_text());last=json.loads((folder/'report.json').read_text())
        assert (folder/'original.c').read_text()==c['source']==(stage2/'original.c').read_text()
        selected=c['source'];passed={i for i,t in enumerate(a['baseline']['tests']) if t['passed']}
        for attempt in a['attempts']:
            g=attempt['generation'];n=attempt['attempt'];calls+=1
            assert g['raw_response']==(stage2/f'model_reply_{n}.txt').read_text()
            assert g['prompt']==(stage2/f'prompt_{n}.txt').read_text()
            replayed+=bool(g.get('replayed_completed_proposal'))
            if attempt['candidate'] is None:continue
            assert code_from(g['raw_response'],True)==attempt['candidate']==(stage2/f'candidate_{n}.c').read_text()
            if attempt['accepted']:
                now={i for i,t in enumerate(attempt['check']['tests']) if t['passed']};assert passed.issubset(now)
                passed=now;selected=attempt['candidate']
        assert selected==(stage2/'repaired.c').read_text()
        assert b['v2_report_sha256']==hashlib.sha256((stage2/'report.json').read_bytes()).hexdigest()
        if b['rescue']:
            calls+=1;g=b['rescue']['generation'];candidate=code_from(g['raw_response'])
            assert candidate==(stage3/'candidate_4.c').read_text()
            if b['rescue']['accepted']:selected=candidate
        assert selected==(stage3/'repaired.c').read_text()
        assert last['v3_report_sha256']==hashlib.sha256((stage3/'report.json').read_bytes()).hexdigest()
        if last['generation']:
            calls+=1;g=last['generation'];candidate=code_from(g['raw_response'])
            assert candidate==(folder/'candidate_5.c').read_text()
            if last['candidate_accepted']:selected=candidate
        assert selected==(folder/'repaired.c').read_text()
        held=json.loads((folder/'heldout.json').read_text())
        assert row['validated']==(last['passed'] and held['passed'])
        assert row['model_calls']==last['total_model_calls']<=5
        assert not {t['input'] for t in c['visible']}.intersection(t['input'] for t in c['heldout'])
    engine=[json.loads(line) for line in (out/'engine_calls.jsonl').read_text().splitlines()]
    assert len(engine)==calls
    result={'programs':8,'faulty_applications':6,'clean_controls':2,'reference_programs_verified':6,
            'individual_mutations_detected':len(mutations),'completed_model_proposals':calls,
            'replayed_saved_proposals':replayed,'selected_sources_match_raw_proposals_or_originals':True,
            'no_manual_C_corrections':True,'core_policy_and_fixtures_unchanged':True,
            'heldout_inputs_disjoint_from_visible_scenarios':True,
            'resource_interruption_recorded_separately':(out/'resource_incident.json').exists()}
    (out/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
