"""Semantic smoke checks for generic repair search and edit confinement."""
from pathlib import Path
import tempfile
from aicc import ROOT
from search_compile import neighbors,repair
from run_large_programs import COMPILER

def main():
    source='#include <stdio.h>\nint main(void) { int a,b; scanf("%d%d",&a,&b); printf("%d\\n",a+b); return 0; }\n'
    for changed,edit in neighbors(source,{}):
        assert changed[:source.index('{')+1]==source[:source.index('{')+1]
        if edit['kind']=='token':assert '"%d\\n"' in changed and '"%d%d"' in changed
    tests=[{'input':'2 3\n','output':'6'},{'input':'4 5\n','output':'20'}]
    with tempfile.TemporaryDirectory() as tmp:
        r=repair(source,source,{},tests,COMPILER,Path(tmp));assert r['passed']
    print('Search scope, unchanged I/O literals, and multi-example operator repair passed')

if __name__=='__main__':main()
