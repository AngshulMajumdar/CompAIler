"""Run one independent control in parallel and publish only a complete result."""
import json
import os
from pathlib import Path
import tempfile
import time
from aicc import ROOT,check
from aicc_v2 import repair_program_v2
from aicc_v3 import finalize_v3
from ai_compile import finalize_last
from large_program_runtime import LargeProgramModel

def main():
    cases=json.loads((ROOT/'large_program_suite/cases.json').read_text())['cases']
    c=next(c for c in cases if c['id']=='expression_parser_correct_control')
    destination=ROOT/'large_program_results'/c['id']
    if destination.exists():raise SystemExit('Primary runner already reached this control; no parallel work started.')
    parent=ROOT/'large_program_parallel';parent.mkdir(exist_ok=True)
    folder=parent/c['id'];folder.mkdir(exist_ok=True)
    compiler=str(ROOT/'vendor/tcc-0.9.27/install/bin/tcc')
    model=LargeProgramModel(ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf',parent/'engine_calls.jsonl')
    start=time.monotonic();stage2=folder/'v2_stage';stage3=folder/'v3_stage'
    (folder/'requirement.txt').write_text(c['requirement'])
    (folder/'visible_tests.json').write_text(json.dumps(c['visible'],indent=2))
    repair_program_v2(model,c['source'],c['requirement'],c['visible'],compiler,stage2)
    r2=json.loads((stage2/'report.json').read_text())
    finalize_v3(model,stage2,c['requirement'],c['visible'],compiler,stage3)
    r3=json.loads((stage3/'report.json').read_text())
    final=finalize_last(model,stage3,c['requirement'],c['visible'],compiler,folder)
    with tempfile.TemporaryDirectory(prefix='parallel-control-heldout-') as tmp:
        h=check((folder/'repaired.c').read_text(),Path(tmp),compiler,c['heldout'])
    (folder/'heldout.json').write_text(json.dumps(h,indent=2))
    calls=[a['generation'] for a in r2['attempts']]
    if r3['rescue']:calls.append(r3['rescue']['generation'])
    if final['generation']:calls.append(final['generation'])
    row={'id':c['id'],'kind':c['kind'],'input_lines':len(c['source'].splitlines()),
         'input_nonblank_lines':sum(bool(l.strip()) for l in c['source'].splitlines()),
         'functions':c['metadata']['functions'],'injected_faults':0,
         'output_lines':len((folder/'repaired.c').read_text().splitlines()),
         'initial_compiled':r2['baseline']['compiled'],'initial_visible_passed':sum(t['passed'] for t in r2['baseline']['tests']),
         'visible_passed':final['passed'],'heldout_passed':h['passed'],'validated':final['passed'] and h['passed'],
         'heldout_passed_count':sum(t['passed'] for t in h['tests']),'heldout_count':len(c['heldout']),
         'model_calls':len(calls),'generation_seconds':round(sum(a['seconds'] for a in calls),3),
         'truncated_generations':sum(a['finish_reason']=='length' for a in calls),
         'wall_seconds':round(time.monotonic()-start,3)}
    (folder/'evaluation.json').write_text(json.dumps(row,indent=2))
    if not destination.exists():os.rename(folder,destination);print('PUBLISHED',json.dumps(row),flush=True)
    else:print('Primary runner reached control first; independent result kept separately',flush=True)

if __name__=='__main__':main()
