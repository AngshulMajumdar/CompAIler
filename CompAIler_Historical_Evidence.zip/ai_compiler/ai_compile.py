#!/usr/bin/env python3
"""Final wrapper: three-call repair, source-free rescue, then one simpler bounded-storage candidate."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile
import time
from aicc import ROOT,check
from aicc_v2 import ReviewModel,repair_program_v2
from aicc_v3 import finalize_v3

def finalize_last(model,stage,requirement,tests,compiler,output):
    output.mkdir(parents=True,exist_ok=True)
    prior=json.loads((stage/'report.json').read_text())
    digest=hashlib.sha256((stage/'report.json').read_bytes()).hexdigest()
    saved=output/'report.json'
    if saved.exists():
        r=json.loads(saved.read_text());assert r['v3_report_sha256']==digest
        return r
    source=(stage/'repaired.c').read_text();original=source;generation=None;proposed=None;accepted=False
    with tempfile.TemporaryDirectory(prefix='aicc-final-') as tmp:
        work=Path(tmp)
        if not prior['passed']:
            if model is None:raise ValueError('Model required for the final fallback')
            prompt=('Implement this specification as a simple complete C99 program.\n'+requirement+
                    '\nInput/output examples:\n'+json.dumps(tests)+'\n'
                    'A previous independent implementation failed compilation or execution. Choose a different, '
                    'simpler implementation. When input bounds are provided, prefer fixed-size arrays and explicit '
                    'indices instead of dynamic allocation. Check integer widths, string termination, and all '
                    'required boundary cases. Do not add restrictions absent from the specification. '
                    'Read stdin, print only the requested result, and do not hardcode example answers. '
                    'Return only the complete C program in one ```c block.')
            model.llm.set_seed(2042);start=time.monotonic()
            response=model.llm.create_chat_completion(messages=[{'role':'system','content':'Write simple, correct C programs from precise behavioral specifications.'},
                {'role':'user','content':prompt}],temperature=.2,max_tokens=1200)
            raw=response['choices'][0]['message']['content'] or ''
            blocks=re.findall(r'```(?:c|C)?\s*\n(.*?)```',raw,re.S);candidate=blocks[0] if blocks else raw.strip()
            generation={'prompt':prompt,'raw_response':raw,'candidate':candidate,
                        'seconds':round(time.monotonic()-start,3),'seed':2042,'temperature':.2,
                        'finish_reason':response['choices'][0]['finish_reason'],'usage':response.get('usage')}
            (output/'prompt_5.txt').write_text(prompt);(output/'model_reply_5.txt').write_text(raw)
            (output/'candidate_5.c').write_text(candidate)
            proposed=check(candidate,work,compiler,tests);accepted=proposed['passed']
            if accepted:source=candidate
        final=check(source,work,compiler,tests)
        if final['passed']:shutil.copy2(work/'program',output/'program')
    (output/'original.c').write_text((stage/'original.c').read_text())
    (output/'repaired.c').write_text(source)
    r={'version':'final','passed':final['passed'],'final':final,'v3_report_sha256':digest,
       'extra_candidate_called':generation is not None,'generation':generation,'candidate_check':proposed,
       'candidate_accepted':accepted,'source_unchanged_from_v3':source==original,
       'total_model_calls':prior['total_model_calls']+int(generation is not None)}
    assert r['total_model_calls']<=5
    saved.write_text(json.dumps(r,indent=2));return r

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path)
    req=p.add_mutually_exclusive_group(required=True);req.add_argument('--requirement');req.add_argument('--requirement-file',type=Path)
    p.add_argument('--tests',type=Path);p.add_argument('--compiler',default='tcc' if shutil.which('tcc') else 'gcc')
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
    p.add_argument('--output',type=Path,default=ROOT/'output_final');a=p.parse_args()
    model=ReviewModel(a.model);requirement=a.requirement_file.read_text() if a.requirement_file else a.requirement
    tests=json.loads(a.tests.read_text()) if a.tests else []
    v2=a.output/'v2_stage';v3=a.output/'v3_stage'
    repair_program_v2(model,a.source.read_text(),requirement,tests,a.compiler,v2)
    finalize_v3(model,v2,requirement,tests,a.compiler,v3)
    result=finalize_last(model,v3,requirement,tests,a.compiler,a.output)
    print('Result:',('tests_passed' if a.tests else 'compiled_only') if result['passed'] else 'failed')
    raise SystemExit(0 if result['passed'] else 1)

if __name__=='__main__':main()
