"""Independent fixed-seed evaluation inputs; these never enter model requests."""
import json
import math
from pathlib import Path
import random
from aicc import ROOT

SEED=2026112302

def build_fresh(cases):
    r=random.Random(SEED);old={};out={}
    for c in cases:old.setdefault(c['task'],{t['input'] for t in c['visible']+c['hidden']})
    def add(task,stdin,answer):
        if stdin not in old[task] and stdin not in {t['input'] for t in out.setdefault(task,[])}:
            out[task].append({'input':stdin,'output':str(answer)})
    def arr(a):return str(len(a))+'\n'+' '.join(map(str,a))+'\n'
    def fib(n):
        a,b=0,1
        for _ in range(n):a,b=b,a+b
        return a
    def prime(n):return n>=2 and all(n%d for d in range(2,math.isqrt(n)+1))
    def balanced(s):
        stack=[];match={')':'(',']':'[','}':'{'}
        for ch in s:
            if ch in '([{':stack.append(ch)
            elif not stack or stack.pop()!=match[ch]:return 0
        return int(not stack)
    for task in old:
        out[task]=[]
        if task=='factorial':
            for n in range(13):add(task,f'{n}\n',math.factorial(n))
            continue # Original tests already exhaust this finite domain.
        if task=='fibonacci':
            ns=list(range(46));r.shuffle(ns)
            for n in ns:add(task,f'{n}\n',fib(n))
            out[task]=out[task][:20];continue
        if task=='integer_power':
            ns=[(a,e) for a in range(-10,11) for e in range(10)];r.shuffle(ns)
            for a,e in ns:add(task,f'{a} {e}\n',a**e)
            out[task]=out[task][:20];continue
        while len(out[task])<20:
            if task=='sum_to_n':
                n=r.randint(0,1000000);add(task,f'{n}\n',n*(n+1)//2)
            elif task=='mean':
                a,b=r.randint(-10000,10000),r.randint(-10000,10000);add(task,f'{a} {b}\n',f'{(a+b)/2:.2f}')
            elif task in ['maximum','minimum','positive_count','sort','prefix_sums','distinct_count']:
                a=[r.randint(-10000,10000) for _ in range(r.randint(1,30))]
                if task=='distinct_count':a=sorted(r.choices(range(-10,11),k=len(a)))
                if task=='maximum':answer=max(a)
                elif task=='minimum':answer=min(a)
                elif task=='positive_count':answer=sum(x>0 for x in a)
                elif task=='sort':answer=' '.join(map(str,sorted(a)))
                elif task=='distinct_count':answer=len(set(a))
                else:
                    total=0;sums=[]
                    for x in a:total+=x;sums.append(total)
                    answer=' '.join(map(str,sums))
                add(task,arr(a),answer)
            elif task in ['linear_search','binary_search']:
                a=[r.randint(-9,9) for _ in range(r.randint(1,30))]
                if task=='binary_search':a=sorted(r.sample(range(-1000,1001),len(a)))
                x=r.choice(a) if r.random()<.5 else r.randint(-1100,1100)
                add(task,arr(a)+f'{x}\n',a.index(x) if x in a else -1)
            elif task in ['gcd','lcm']:
                a,b=r.randint(1,1000000),r.randint(1,1000000)
                add(task,f'{a} {b}\n',math.gcd(a,b) if task=='gcd' else math.lcm(a,b))
            elif task=='prime':
                n=r.randint(2,990000)
                kind=len(out[task])%3
                if kind==0:
                    while not prime(n):n+=1
                elif kind==1:n=r.randint(2,1000)**2
                add(task,f'{n}\n',int(prime(n)))
            elif task in ['reverse_string','palindrome','vowel_count']:
                s=''.join(r.choices('abCDxyzAEIOU123!?',k=r.randint(1,45)))
                if task=='palindrome' and len(out[task])%2==0:s=s+s[::-1]
                answer=(s[::-1] if task=='reverse_string' else
                        int(s==s[::-1]) if task=='palindrome' else sum(ch in 'aeiouAEIOU' for ch in s))
                add(task,s+'\n',answer)
            elif task=='digit_sum':
                n=r.randint(-1000000000,1000000000);add(task,f'{n}\n',sum(map(int,str(abs(n)))))
            elif task=='leap_year':
                y=r.randint(1,99)*100 if len(out[task])%3==0 else r.randint(1,9999)
                add(task,f'{y}\n',int(y%4==0 and (y%100!=0 or y%400==0)))
            elif task=='matrix_transpose':
                nr,nc=r.randint(1,5),r.randint(1,5)
                a=[[r.randint(-999,999) for _ in range(nc)] for _ in range(nr)]
                add(task,f'{nr} {nc}\n'+'\n'.join(' '.join(map(str,row)) for row in a)+'\n',
                    '\n'.join(' '.join(map(str,col)) for col in zip(*a)))
            elif task=='dot_product':
                n=r.randint(1,30);a=[r.randint(-100000,100000) for _ in range(n)];b=[r.randint(-100000,100000) for _ in range(n)]
                add(task,arr(a)+' '.join(map(str,b))+'\n',sum(x*y for x,y in zip(a,b)))
            elif task=='balanced_brackets':
                if len(out[task])%2:
                    s=''.join(r.choices('()[]{}',k=r.randint(1,60)))
                else:
                    stack=[];ss=[]
                    for _ in range(r.randint(1,25)):
                        if stack and r.random()<.5:ss.append(stack.pop())
                        else:
                            op,cl=r.choice([('(',')'),('[',']'),('{','}')]);ss.append(op);stack.append(cl)
                    s=''.join(ss+stack[::-1])
                add(task,s+'\n',balanced(s))
            else:raise ValueError(task)
    for name,tests in out.items():
        assert not old[name].intersection(t['input'] for t in tests)
    return out

if __name__=='__main__':
    cases=json.loads((ROOT/'large_suite/cases.json').read_text())
    data=build_fresh(cases)
    (ROOT/'fresh_tests_v2.json').write_text(json.dumps({'seed':SEED,'tasks':data,
       'note':'No unused factorial inputs remain: the original suite covers every n in 0..12.'},indent=2))
    print({k:len(v) for k,v in data.items()})
