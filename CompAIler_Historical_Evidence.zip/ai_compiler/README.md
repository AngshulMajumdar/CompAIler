# Current verified CPU compiler layer

**Start with `ai_compile_verified.py` and `VERIFIED_RESULTS.md`.** All six larger, multiple-error programs passed 78 checks each; both correct controls also passed. TinyCC and GCC with undefined-behavior checks produced 1,248 passing executions. This result applies to the recorded suite.

The method combines the same small CPU model with compiler/test-guided repair search and helper/caller transactions. It uses no GPU. Source is released as an executable only after all supplied behavioral tests pass. The full method, timing, proposal-cache reuse and failed intermediate stages are documented in VERIFIED_RESULTS.md.

The earlier wrappers and reports below are retained as development history. The 80/80 tiny-program result is a smoke test, not the acceptance criterion for this version.

# AI layer in front of a C compiler

A working command-line experiment: imperfect C -> local coding model -> C compiler -> executable -> input/output checks -> automatic repair feedback. The human supplies intended behavior and validates outputs. No API key, paid endpoint, training, or GPU is used.

**Earlier small-program wrapper: `ai_compile.py`.** It reviews every submission, diagnoses errors, changes strategy after stalled attempts, and rejects changes that break already-passing tests. If necessary, it makes source-free fallback attempts, with a maximum of five calls and no extra calls on already-passing branches. The original `aicc.py` and intermediate versions remain intact. Read `FINAL_RESULTS.md` for final measurements and `V2_COMPARISON.md` for the fixed three-call experiment, including its regressions.

**Larger-program stress test:** see `LARGER_PROGRAM_RESULTS.md`. This separate trial uses six 179–211-line multi-function applications with 43 combined faults in total, plus two clean controls. Its results must be read independently of the earlier 80-case short-program score. The larger-context runtime is intended for serial inference; the parallel attempt exceeded available memory.

## What is included

- `aicc.py`: model-driven repair and compilation wrapper, capped at three repairs.
- `demo.py`: three fixed toy examples with syntax and semantic bugs.
- `human_test.py`: try new inputs against a compiled executable.
- `verify_unseen.py`: additional checks that are never sent to the model.
- `results/`: final source, full repair history, raw model answers, and executable outputs from the larger model trial.
- `results_1_5b_gcc/`: the original smaller-model trial, including its failures.
- `TRIAL.md`: observed outcomes and runtime.
- `EXPANDED_TRIAL.md`: results from the expanded 80-faulty-variant and eight-control trial, with per-category counts and failures.
- `large_suite/` and `large_results/`: every expanded case, reference preflight, raw model replies, and separate visible/held-out results.
- `large_results_v2/`: paired V2 results, complete prompts, accepted/rejected candidates, original held-out checks and fresh evaluation inputs.

The runner compares stripped stdout exactly with supplied expected outputs and requires a zero exit status. No examples or model outputs were manually patched during either trial. The examples are hand-written toy problems, not a benchmark or a correctness proof.

## Models and compiler

The first trial used Qwen2.5-Coder-1.5B-Instruct, Q4_K_M, with GCC. The larger trial uses Qwen2.5-Coder-7B-Instruct, Q4_K_M, with TinyCC 0.9.27. Inference uses llama-cpp-python 0.3.36, four CPU threads, zero GPU layers, temperature zero, and seed 42. The comparison changes both model and compiler and is not a controlled model benchmark.

Weights are freely downloadable from the official repositories:

- https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF
- https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF

Weights and installed Python dependencies are not bundled in this small source archive. CPU inference still consumes RAM, time, and electricity. Allow roughly 8 GB or more of available RAM for the 7B trial, and roughly 5 GB for its model download. Runtime depends on the CPU.

TinyCC in the trial was built from https://download.savannah.gnu.org/releases/tinycc/tcc-0.9.27.tar.bz2 using `make BCHECK_O=` to omit its legacy bounds-checking runtime, which is incompatible with this machine's newer glibc. The wrapper also supports system-installed TCC and GCC.

## Run on Linux

Install Python 3.12, a C compiler (`tcc` or `gcc`), `bubblewrap`, and `libseccomp2`. Then:

```bash
bash setup.sh
.venv/bin/python demo.py
.venv/bin/python verify_unseen.py
```

To run the expanded suite and its report:

```bash
.venv/bin/python run_large_suite.py
.venv/bin/python report_large_suite.py
```

The expanded runner resumes completed cases. Move `large_results/` aside before starting a completely fresh run. Clean reference implementations and held-out tests are used only for evaluation, never supplied to the model.

`demo.py` prefers the locally built TinyCC if present, then system TinyCC, then GCC. For your own program, choose the compiler explicitly:

```bash
.venv/bin/python ai_compile.py examples/mean/broken.c \
  --requirement-file examples/mean/requirement.txt \
  --tests examples/mean/tests.json \
  --compiler tcc --output my_result

.venv/bin/python human_test.py my_result/program --input '3 8'
```

The expected mean is `5.50`. To provide human feedback, add an input and expected output to the JSON tests file, then run the wrapper again with the current `my_result/repaired.c` as its source. Use a different output directory to preserve the previous run.

The test-file format is:

```json
[{"input": "1 2\n", "output": "1.50"}]
```

With no tests, the wrapper reports `compiled_only`; it does not claim logical correctness. If the retry limit is reached, it reports failure and retains the attempts. The original program is checked first so real diagnostics and test failures can inform the first model repair.

## Scope and execution

This prototype handles short, single-file console programs. It does not guarantee perfect code, global optimization, or general program correctness. It only repairs failures exposed by supplied requirements, compiler diagnostics, and tests. It does not yet have a graphical interface.

Generated executables run through bubblewrap with a restricted filesystem, an empty environment, private process/IPC/user namespaces, a seccomp filter denying socket creation and related operations, a five-second wall timeout, and CPU/memory/output-size limits. Execution fails closed if the required isolation tools are absent. This is a local demonstration, not a hardened public code-execution service. Compilation itself uses the host compiler outside that execution sandbox; do not expose it to untrusted public uploads.

The human can inspect the repaired source after compilation, test additional inputs, and supply expected behavior without debugging the implementation.

## Rerun the V2 comparison

```bash
.venv/bin/python verify_v2_guards.py
.venv/bin/python run_v2_comparison.py
.venv/bin/python report_v2_comparison.py
.venv/bin/python audit_v2.py
```

The guard checks use explicit stub proposals to check the acceptance mechanism; they are not counted as LLM successes. The 88-case comparison invokes the real local model, with the earlier three unresolved cases first and all other cases and controls afterward. Move `large_results_v2/` aside before a completely fresh run. Keep the frozen policy and evaluation fixtures fixed.

To verify the source-free fallbacks after that run:

```bash
.venv/bin/python run_v3_verification.py
.venv/bin/python report_v3_results.py
.venv/bin/python verify_final.py
```

These commands preserve and recheck passing earlier outputs and invoke extra model calls only where visible tests still fail. `large_results_final/` contains the final sources, compiled executables and evaluations. Use a new output directory when submitting changed code or additional human feedback so each run remains inspectable.

## Larger-program trial

```bash
.venv/bin/python run_large_programs.py
.venv/bin/python summarize_large_programs.py
```

Use `resume_large_programs.py` for the included interrupted run: it replays the two completed inventory proposals from their original responses, then resumes normal inference. Clean references, faulty versions, mutation manifests and scenarios are in `large_program_suite/`; results and all proposal traces are in `large_program_results/`. Run only one larger-context model process at a time on a machine with memory comparable to this test environment.

For an individual larger input, use the larger-capacity entry point:

```bash
.venv/bin/python ai_compile_large.py large_program_suite/inputs/inventory/source.c \
  --requirement-file large_program_suite/inputs/inventory/requirement.txt \
  --tests large_program_suite/inputs/inventory/visible_tests.json \
  --output inventory_large_run
```

This uses the same repair strategy with a 16K context and a 6,144-token output ceiling. It reports failure when the visible tests do not pass; increasing capacity does not imply that a repair will succeed. The earlier small-program score does not establish reliability on these larger inputs.


## Adaptive chunk compiler trial

`ai_compile_chunks.py` repairs connected groups of function bodies and compiles the reassembled full program after every nonempty edit. Its JSON edit grammar, function-boundary checks, actual compiler and visible regression tests form separate guards. It supports the single-file C applications in this prototype; it is not a general C parser.

```bash
.venv/bin/python test_chunk_guards.py
.venv/bin/python run_chunk_trial.py
.venv/bin/python report_chunk_trial.py

.venv/bin/python ai_compile_chunks.py large_program_suite/inputs/inventory/source.c \
  --requirement-file large_program_suite/inputs/inventory/requirement.txt \
  --tests large_program_suite/inputs/inventory/visible_tests.json --output my_chunk_result
```

Read `CHUNK_TRIAL_RESULTS.md` for measured results and limitations. The trial uses the same faulty programs and tests as the whole-file test; the new policy allows up to eight calls rather than five, so this is not an equal-budget ablation.


## Complete-function CPU wrapper

`ai_compile_functions.py` asks the same CPU model for one complete corrected C function per request. It handles reinsertion, validates function identity and signatures, compiles the complete program, and preserves passing visible scenarios. Rejected replacements can receive a bounded retry with dependency bodies.

```bash
.venv/bin/python test_function_guards.py
.venv/bin/python run_function_trial.py
.venv/bin/python report_function_trial.py

.venv/bin/python ai_compile_functions.py source.c \
  --requirement-file requirement.txt --tests tests.json --output function_output
```

`FUNCTION_TRIAL_RESULTS.md` contains measured results and the budget differences from previous policies. No GPU, hosted API or larger model is introduced. Model weights and installed runtimes remain excluded from this archive.
