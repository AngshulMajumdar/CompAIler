"""Replay completed proposals after the memory incident, then resume serial inference."""
import hashlib
import json
import re
from aicc import ROOT
from large_program_runtime import LargeProgramModel
import run_large_programs

class ResumeModel(LargeProgramModel):
    def __init__(self,path,log):
        super().__init__(path,log)
        self.replay=[]
        checkpoint=ROOT/'large_program_results/completed_inventory_proposals.json'
        data=json.loads(checkpoint.read_text())
        self.replay=data['proposals']
    def propose(self,source,requirement,report,tests,previous,attempt,strategy):
        digest=hashlib.sha256(source.encode()).hexdigest()
        for record in self.replay:
            if record['attempt']==attempt and record['source_sha256']==digest and record['requirement']==requirement:
                generation=dict(record['generation']);generation['replayed_completed_proposal']=True
                print('REPLAY_COMPLETED_PROPOSAL',attempt,flush=True)
                return record['candidate'],generation
        return super().propose(source,requirement,report,tests,previous,attempt,strategy)

def checkpoint():
    out=ROOT/'large_program_results';saved=out/'completed_inventory_proposals.json'
    if saved.exists():return
    cases=json.loads((ROOT/'large_program_suite/cases.json').read_text())['cases']
    c=next(c for c in cases if c['id']=='inventory');source=c['source'];records=[]
    engine=[json.loads(line) for line in (out/'engine_calls.jsonl').read_text().splitlines()]
    stage=out/'inventory/v2_stage'
    for attempt in [1,2]:
        raw=(stage/f'model_reply_{attempt}.txt').read_text()
        blocks=re.findall(r'```(?:c|C)?\s*\n(.*?)```',raw,re.S)
        candidate=blocks[0] if blocks else raw.strip();e=engine[attempt-1]
        generation={'raw_response':raw,'prompt':(stage/f'prompt_{attempt}.txt').read_text(),
                    'seconds':e['seconds'],'usage':e['usage'],'finish_reason':e['finish_reason'],
                    'strategy':'repair','temperature':0,'seed':42+attempt,'unchanged':False}
        records.append({'attempt':attempt,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
                        'requirement':c['requirement'],'candidate':candidate,'generation':generation})
        source=candidate
    saved.write_text(json.dumps({'reason':'Memory exhaustion during concurrent inference. Two completed proposals replayed without new model calls.',
                                 'proposals':records},indent=2))
    (out/'resource_incident.json').write_text(json.dumps({'primary_exit':137,'parallel_exit':137,
        'cause':'Parallel 16K-context inference exceeded available memory',
        'completed_primary_proposals_saved':2,'interrupted_primary_call':3,
        'parallel_control_completed_calls':0,'mitigation':'Serial inference; replay completed proposal outputs'},indent=2))

if __name__=='__main__':
    checkpoint()
    run_large_programs.LargeProgramModel=ResumeModel
    run_large_programs.main()
