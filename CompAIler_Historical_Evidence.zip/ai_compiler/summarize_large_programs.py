"""Summarize larger-program results without hiding incomplete or failed repairs."""
import csv
import hashlib
import json
from aicc import ROOT

def main():
    out=ROOT/'large_program_results';p=out/'summary.json'
    s=json.loads(p.read_text()) if p.exists() else {'cases':[],'completed':0}
    rows=s['cases'];fixture=json.loads((ROOT/'large_program_suite/cases.json').read_text());cases=fixture['cases']
    indexed={r['id']:r for r in rows}
    plan=json.loads((out/'frozen_plan.json').read_text())
    assert plan['cases_sha256']==hashlib.sha256((ROOT/'large_program_suite/cases.json').read_bytes()).hexdigest()
    for f,digest in plan['code_sha256'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==digest
    lines=['# Larger programs with interacting errors','',
      'Six multi-function C applications, each with 7–8 simultaneously injected faults, plus two clean controls. The original sources are 179–211 physical lines (164–192 nonblank lines), with 11–15 functions. These are functional applications, not repeated copies of short examples.',
      '',f'Completed submissions: {len(rows)}/{len(cases)}.','',
      '| Program | Input lines | Functions | Faults | Best visible | Selected visible | Selected held-out | Calls | Model time | Output lines |',
      '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for c in cases:
        r=indexed.get(c['id']);size=len(c['source'].splitlines())
        if r:
            folder=out/c['id'];r2=json.loads((folder/'v2_stage/report.json').read_text())
            r3=json.loads((folder/'v3_stage/report.json').read_text());last=json.loads((folder/'report.json').read_text())
            proposals=[r2['baseline']]+[a['check'] for a in r2['attempts'] if a.get('check')]
            if r3['rescue']:proposals.append(r3['rescue']['check'])
            if last['candidate_check']:proposals.append(last['candidate_check'])
            best=max(sum(t['passed'] for t in p['tests']) for p in proposals)
            selected=sum(t['passed'] for t in last['final']['tests'])
            lines.append(f"| {c['id']} | {size} | {r['functions']} | {r['injected_faults']} | {best}/4 | {selected}/4 | {r['heldout_passed_count']}/{r['heldout_count']} | {r['model_calls']} | {r['generation_seconds']/60:.1f} min | {r['output_lines']} |")
        else:lines.append(f"| {c['id']} | {size} | {c['metadata']['functions']} | {len(c['mutations'])} | Pending | — | — | — | — | — |")
    if rows:
        lines+=['',f"Faulty applications passing every scenario: **{s['fully_validated']}/{s['faulty_programs']}**. Correct controls passing: **{s['controls_passed']}/{s['controls']}**.",
                '',f"Held-out scenario executions passed: {s['heldout_passed']}/{s['heldout_total']}. A scenario contains a sequence of commands, expressions or matrix operations; these are not all one-operation tests."]
        with (out/'case_results.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    lines+=['','## Capacity and policy','',
      'The same Qwen2.5-Coder-7B-Instruct Q4_K_M model runs on CPU with four threads and zero GPU layers. The repair strategy remains the previously tested staged policy, capped at five model calls.',
      '', 'To support complete larger files, context was increased from 4,096 to 16,384 tokens and generation capacity from 1,200 to 6,144 tokens. Large runaway stdout/stderr is abbreviated only in model feedback; complete captured outputs remain in test reports. This is capacity scaling, not model training or a task-specific repair rule.',
      '', 'The policy, source-code hashes and scenario fixtures were frozen before model inference. The model receives the faulty C source, behavioral requirements and four visible scenarios. The 24 held-out scenarios and clean references are evaluation-only. No manual C corrections are made.',
      '', 'All six clean implementations first passed all 28 scenarios against independent Python oracles. Each of the 43 injected mutations was then tested individually and detected before the combined-fault trial began. The multi-error versions apply all listed mutations simultaneously.',
      '', 'Each chosen output is checked against the held-out scenarios even if it passes the visible tests. Failure is retained and reported; the held-out failures do not trigger additional repairs. The budget is fixed, so this trial measures limits rather than continuing until a favorable result appears.',
      '', 'Best-visible counts refer to any candidate observed during the run; selected-visible and held-out counts refer to the source the unchanged controller retained. These can differ because the existing fallback stages accept a replacement only when every visible scenario passes. Thus partial fallback improvements can be discarded. No held-out scores are used to choose a source.',
      '', 'The clean programs are deliberately supplied as inputs in the two correct-code controls. A clean reference answer is never supplied when repairing a faulty program.',
      '', 'A parallel inference attempt exceeded available memory and both processes were stopped (exit 137). The trial then resumed serially. Inventory’s two completed proposals were replayed from saved raw responses, without new model calls; the unfinished third invocation was restarted. `resource_incident.json` and the pre-incident log retain this interruption separately from completed-proposal timings.',
      '', '## Inspect and rerun','',
      '`large_program_suite/references/` contains clean sources used only for preflight. `large_program_suite/faulty/` contains the submitted programs. `large_program_suite/cases.json` records exact mutation manifests, requirements and all scenarios.',
      '', '`large_program_results/<program>/` retains original and selected sources, full model requests/replies, compile and visible test history, and held-out results. `engine_calls.jsonl` records actual token usage, completion limits and generation times. The run log includes token progress for long generations.',
      '', 'Run `PYTHONPATH=deps python run_large_programs.py` from the project parent with dependencies available, or use your configured Python environment. Completed cases are resumed; move the results directory aside for a completely fresh trial.',
      '', 'These deliberately constructed applications are larger than the earlier examples but remain small single-file programs. Results do not establish repository-scale repair reliability.',
      '']
    (ROOT/'LARGER_PROGRAM_RESULTS.md').write_text('\n'.join(lines))
    print(json.dumps({k:v for k,v in s.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
