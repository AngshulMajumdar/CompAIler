"""Replay the unchanged V2 branch; invoke rescue only on visible-test failure; check all 88 outputs."""
import hashlib
import json
from pathlib import Path
import tempfile
from aicc import ROOT,check
from aicc_v2 import ReviewModel
from aicc_v3 import finalize_v3

def main():
    v2=json.loads((ROOT/'large_results_v2/summary.json').read_text())
    cases=json.loads((ROOT/'large_suite/cases.json').read_text())
    assert v2['completed']==len(cases)==88,'Complete V2 before this verification'
    out=ROOT/'large_results_v3';out.mkdir(exist_ok=True)
    old={r['id']:r for r in v2['cases']}
    cases.sort(key=lambda c:old[c['id']]['visible_passed'])
    fresh=json.loads((ROOT/'fresh_tests_v2.json').read_text())['tasks']
    compiler=str(ROOT/'vendor/tcc-0.9.27/install/bin/tcc')
    model=None;rows=[]
    for i,c in enumerate(cases,1):
        folder=out/c['id'];folder.mkdir(exist_ok=True)
        evaluation=folder/'evaluation.json'
        if evaluation.exists():rows.append(json.loads(evaluation.read_text()));continue
        stage=ROOT/'large_results_v2'/c['id']
        stage_report=json.loads((stage/'report.json').read_text())
        if not stage_report['passed'] and model is None:
            model=ReviewModel(ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
        print('CASE',i,c['id'],'rescue_needed',not stage_report['passed'],flush=True)
        report=finalize_v3(model,stage,c['requirement'],c['visible'],compiler,folder)
        with tempfile.TemporaryDirectory(prefix='v3-evaluation-') as tmp:
            heldout=check((folder/'repaired.c').read_text(),Path(tmp),compiler,c['hidden'])
            extra=check((folder/'repaired.c').read_text(),Path(tmp),compiler,fresh[c['task']])
        (folder/'heldout.json').write_text(json.dumps(heldout,indent=2))
        (folder/'fresh.json').write_text(json.dumps(extra,indent=2))
        if stage_report['passed']:
            assert report['source_unchanged_from_v2'] and not report['rescue_called']
        row={'id':c['id'],'kind':c['kind'],'task':c['task'],
             'v1_validated':old[c['id']]['v1_validated'],'v2_validated':old[c['id']]['v2_validated'],
             'v3_validated':report['passed'] and heldout['passed'] and extra['passed'],
             'visible_passed':report['passed'],'heldout_passed':heldout['passed'],'fresh_passed':extra['passed'],
             'rescue_called':report['rescue_called'],'source_unchanged_from_v2':report['source_unchanged_from_v2'],
             'extra_model_calls':report['model_calls_added'],'total_model_calls':report['total_model_calls'],
             'rescue_seconds':report['rescue_generation_seconds'],
             'heldout_pass_count':sum(t['passed'] for t in heldout['tests']),'heldout_test_count':len(c['hidden']),
             'fresh_pass_count':sum(t['passed'] for t in extra['tests']),'fresh_test_count':len(fresh[c['task']])}
        evaluation.write_text(json.dumps(row,indent=2));rows.append(row)
        faulty=[r for r in rows if r['kind']=='faulty'];controls=[r for r in rows if r['kind']=='clean_control']
        s={'completed':len(rows),'faulty_cases':len(faulty),'v1_validated':sum(r['v1_validated'] for r in faulty),
           'v2_validated':sum(r['v2_validated'] for r in faulty),'v3_validated':sum(r['v3_validated'] for r in faulty),
           'controls_passed':sum(r['v3_validated'] for r in controls),'controls':len(controls),
           'rescues_called':[r['id'] for r in rows if r['rescue_called']],
           'regressions_vs_v1':[r['id'] for r in rows if r['v1_validated'] and not r['v3_validated']],
           'regressions_vs_v2':[r['id'] for r in rows if r['v2_validated'] and not r['v3_validated']],
           'extra_model_calls':sum(r['extra_model_calls'] for r in rows),
           'extra_generation_seconds':sum(r['rescue_seconds'] for r in rows),
           'heldout_passed':sum(r['heldout_pass_count'] for r in rows),'heldout_total':sum(r['heldout_test_count'] for r in rows),
           'fresh_passed':sum(r['fresh_pass_count'] for r in rows),'fresh_total':sum(r['fresh_test_count'] for r in rows),
           'cases':rows}
        (out/'summary.json').write_text(json.dumps(s,indent=2))
    print('FINISHED',json.dumps({k:v for k,v in s.items() if k!='cases'}),flush=True)

if __name__=='__main__':main()
