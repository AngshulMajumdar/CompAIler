"""Frozen paired test: same faulty inputs, visible examples and held-out scenarios."""
import hashlib
import json
from pathlib import Path
import tempfile
import subprocess
from aicc import ROOT,check
from chunk_compile import ChunkModel,POLICY,repair,groups
from run_large_programs import COMPILER,preflight

OUT=ROOT/'chunk_results'
def write_summary(rows):
    faulty=[r for r in rows if r['kind']=='faulty'];controls=[r for r in rows if r['kind']=='correct_control']
    s={'completed':len(rows),'faulty_complete':len(faulty),'faulty_validated':sum(r['validated'] for r in faulty),
       'faulty_heldout_passed':sum(r['heldout_passed'] for r in faulty),'faulty_heldout_total':sum(r['heldout_total'] for r in faulty),
       'controls':len(controls),'controls_validated':sum(r['validated'] for r in controls),'calls':sum(r['calls'] for r in rows),
       'model_seconds':round(sum(r['model_seconds'] for r in rows),2),'cases':rows}
    (OUT/'summary.json').write_text(json.dumps(s,indent=2));return s

def main():
    OUT.mkdir(exist_ok=True);fixture=ROOT/'large_program_suite/cases.json';cases=json.loads(fixture.read_text())['cases']
    preflight(cases)
    plan={'policy':POLICY,'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
          'controller_sha256':hashlib.sha256((ROOT/'chunk_compile.py').read_bytes()).hexdigest(),
          'initial_chunks':{c['id']:groups(c['source']) for c in cases},
          'evaluation':'same 4 visible and 24 held-out scenarios; no reference implementations or mutations in prompts',
          'comparison_note':'Previous whole-file policy allowed 5 calls; chunk policy allows 8. Not an equal-call ablation.'}
    path=OUT/'frozen_plan.json'
    if path.exists():assert json.loads(path.read_text())==plan
    else:path.write_text(json.dumps(plan,indent=2))
    rows=[];model=None
    for c in cases:
        folder=OUT/c['id'];done=folder/'evaluation.json'
        if done.exists():rows.append(json.loads(done.read_text()));continue
        print('CASE',c['id'],'initial_chunks',plan['initial_chunks'][c['id']],flush=True)
        if model is None:model=ChunkModel(ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
        report=repair(model,c['source'],c['requirement'],c['visible'],COMPILER,folder)
        if report['final']['passed']:
            subprocess.run([COMPILER,'-Wall','-Werror',str(folder/'repaired.c'),'-o',str(folder/'program'),'-lm'],
                           capture_output=True,text=True,timeout=20,check=True)
        with tempfile.TemporaryDirectory(prefix='chunk-heldout-') as tmp:
            held=check((folder/'repaired.c').read_text(),Path(tmp),COMPILER,c['heldout'])
        (folder/'heldout.json').write_text(json.dumps(held,indent=2))
        row={'id':c['id'],'kind':c['kind'],'lines':len(c['source'].splitlines()),'faults':len(c['mutations']),
             'visible_passed':sum(t['passed'] for t in report['final']['tests']),'visible_total':len(c['visible']),
             'heldout_passed':sum(t['passed'] for t in held['tests']),'heldout_total':len(c['heldout']),
             'validated':report['final']['passed'] and held['passed'],'compiled':report['final']['compiled'],
             'calls':report['calls'],'model_seconds':round(sum(x['generation']['seconds'] for x in report['history']),2),
             'accepted_edits':sum(len(x.get('edits',[])) for x in report['history'] if x['accepted']),
             'compiler_rejections':sum(x['reason']=='compiler_rejected' for x in report['history']),
             'edit_guard_rejections':sum(x['reason']=='edit_guard_rejected' for x in report['history']),
             'regression_rejections':sum(x['reason']=='visible_regression' for x in report['history']),
             'prompt_tokens':sum(x['generation']['usage']['prompt_tokens'] for x in report['history']),
             'output_tokens':sum(x['generation']['usage']['completion_tokens'] for x in report['history'])}
        done.write_text(json.dumps(row,indent=2));rows.append(row);s=write_summary(rows)
        print('PROGRESS',json.dumps({k:v for k,v in s.items() if k!='cases'}),flush=True)
    print('FINISHED',json.dumps({k:v for k,v in write_summary(rows).items() if k!='cases'}),flush=True)

if __name__=='__main__':main()
