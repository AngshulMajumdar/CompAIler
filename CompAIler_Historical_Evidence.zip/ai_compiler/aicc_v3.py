#!/usr/bin/env python3
"""V2 plus one source-free rescue call, only if its visible tests still fail."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile
import time
from aicc import ROOT,check
from aicc_v2 import ReviewModel,repair_program_v2

def source_free_proposal(model,requirement,tests):
    prompt=('Write a complete C program implementing this specification for all permitted inputs.\n'
            'Specification: '+requirement+'\nInput/output examples:\n'+json.dumps(tests)+'\n'
            'Read stdin and write only the specified answer to stdout. Do not impose input restrictions '
            'not in the specification. Return only the full program in a ```c code block. '
            'No explanation, no hardcoded example answers.')
    model.llm.set_seed(1042);start=time.monotonic()
    r=model.llm.create_chat_completion(messages=[{'role':'system','content':'Implement precise C specifications with exact input/output behavior.'},
            {'role':'user','content':prompt}],temperature=0,max_tokens=1200)
    raw=r['choices'][0]['message']['content'] or ''
    blocks=re.findall(r'```(?:c|C)?\s*\n(.*?)```',raw,re.S)
    code=blocks[0] if blocks else raw.strip()
    return code,{'prompt':prompt,'raw_response':raw,'seconds':round(time.monotonic()-start,3),
                 'temperature':0,'seed':1042,'finish_reason':r['choices'][0]['finish_reason'],'usage':r.get('usage')}

def finalize_v3(model,v2_folder,requirement,tests,compiler,output):
    output.mkdir(parents=True,exist_ok=True)
    v2=json.loads((v2_folder/'report.json').read_text())
    source=(v2_folder/'repaired.c').read_text();old_source=source;rescue=None
    with tempfile.TemporaryDirectory(prefix='aicc-v3-') as tmp:
        work=Path(tmp)
        if not v2['passed']:
            if model is None:raise ValueError('An LLM is required for the rescue branch')
            candidate,generation=source_free_proposal(model,requirement,tests)
            (output/'rescue_prompt.txt').write_text(generation['prompt'])
            (output/'model_reply_4.txt').write_text(generation['raw_response'])
            (output/'candidate_4.c').write_text(candidate)
            proposed=check(candidate,work,compiler,tests)
            rescue={'generation':generation,'candidate':candidate,'check':proposed,'accepted':proposed['passed']}
            if proposed['passed']:source=candidate
        final=check(source,work,compiler,tests)
        if final['passed']:shutil.copy2(work/'program',output/'program')
    (output/'original.c').write_text((v2_folder/'original.c').read_text())
    (output/'repaired.c').write_text(source)
    report={'version':3,'model':v2['model'],'requirement':requirement,'passed':final['passed'],'final':final,
            'v2_visible_passed':v2['passed'],'v2_report_sha256':hashlib.sha256((v2_folder/'report.json').read_bytes()).hexdigest(),
            'v2_source_sha256':hashlib.sha256(old_source.encode()).hexdigest(),
            'rescue_called':rescue is not None,'rescue':rescue,
            'model_calls_added':int(rescue is not None),'total_model_calls':v2['model_calls']+int(rescue is not None),
            'rescue_generation_seconds':rescue['generation']['seconds'] if rescue else 0,
            'source_unchanged_from_v2':source==old_source}
    (output/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path)
    req=p.add_mutually_exclusive_group(required=True)
    req.add_argument('--requirement');req.add_argument('--requirement-file',type=Path)
    p.add_argument('--tests',type=Path)
    p.add_argument('--compiler',default='tcc' if shutil.which('tcc') else 'gcc')
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
    p.add_argument('--output',type=Path,default=ROOT/'output_v3');args=p.parse_args()
    model=ReviewModel(args.model)
    requirement=args.requirement_file.read_text() if args.requirement_file else args.requirement
    tests=json.loads(args.tests.read_text()) if args.tests else []
    stage=args.output/'v2_stage'
    repair_program_v2(model,args.source.read_text(),requirement,tests,args.compiler,stage)
    report=finalize_v3(model,stage,requirement,tests,args.compiler,args.output)
    print('Result:',('tests_passed' if args.tests else 'compiled_only') if report['passed'] else 'failed')
    raise SystemExit(0 if report['passed'] else 1)

if __name__=='__main__':main()
