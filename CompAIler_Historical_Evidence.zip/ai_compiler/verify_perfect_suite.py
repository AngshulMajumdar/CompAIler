"""Final release gate: fresh data, original tests, boundary tests and GCC UBSan."""
import hashlib
import json
from pathlib import Path
import random
import shutil
import subprocess
import tempfile
from aicc import ROOT,check
from run_large_programs import COMPILER
import build_large_programs as generators

SEED=2026112403
class SafeExpressionRandom(random.Random):
    def randint(self,a,b):
        # At depth <=3, literal magnitudes <=10 bound arithmetic intermediates below 2^31.
        return super().randint(a,10 if (a,b)==(0,30) else b)

def main():
    out=ROOT/'perfect_verification';out.mkdir(exist_ok=True)
    p=out/'fresh_final.json'
    if p.exists():fresh=json.loads(p.read_text())
    else:
        generators.R=SafeExpressionRandom(SEED)
        fresh={'seed':SEED,'role':'Final evaluation only; never used by repair search',
               'tests':{name:tests[4:] for name,tests in generators.fixtures().items()}}
        p.write_text(json.dumps(fresh,indent=2))
    cases=json.loads((ROOT/'large_program_suite/cases.json').read_text())['cases']
    quality=json.loads((ROOT/'quality_checks.json').read_text());rows=[]
    gcc=shutil.which('gcc');assert gcc,'GCC is required for independent validation'
    with tempfile.TemporaryDirectory(prefix='perfect-verify-') as tmp:
        work=Path(tmp);wrapper=work/'gcc-ubsan'
        wrapper.write_text('#!/bin/sh\nexec '+gcc+' -O2 -fsanitize=undefined -fno-sanitize-recover=all -Wno-unused-function -Wno-unused-variable "$@"\n')
        wrapper.chmod(0o755)
        for c in cases:
            task=c['id'].replace('_correct_control','');folder=out/c['id'];folder.mkdir(exist_ok=True)
            source=(ROOT/'transaction_results'/c['id']/'repaired.c').read_text()
            tests=c['visible']+quality['stress'][task]+c['heldout']+quality['fresh'][task]+fresh['tests'][task]
            reference=(ROOT/'large_program_suite/references'/(task+'.c')).read_text()
            pre=check(reference,work,COMPILER,tests);assert pre['passed'],('oracle/reference mismatch',c['id'])
            reports={}
            for name,compiler in [('tinycc',COMPILER),('gcc_ubsan',str(wrapper))]:
                r=check(source,work,compiler,tests);reports[name]=r
                (folder/(name+'.json')).write_text(json.dumps(r,indent=2))
                print('VERIFY',c['id'],name,sum(t['passed'] for t in r['tests']),len(tests),flush=True)
            rows.append({'id':c['id'],'kind':c['kind'],'scenarios_per_compiler':len(tests),
                'tinycc_passed':sum(t['passed'] for t in reports['tinycc']['tests']),
                'gcc_ubsan_passed':sum(t['passed'] for t in reports['gcc_ubsan']['tests']),
                'passed':all(r['passed'] for r in reports.values()),
                'source_sha256':hashlib.sha256(source.encode()).hexdigest()})
    passed=all(r['passed'] for r in rows)
    result={'passed':passed,'programs':len(rows),'faulty_programs':6,'controls':2,
            'scenarios_per_compiler':sum(r['scenarios_per_compiler'] for r in rows),
            'scenario_executions':2*sum(r['scenarios_per_compiler'] for r in rows),
            'fresh_final_seed':SEED,'fresh_final_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
            'gcc_version':subprocess.run([gcc,'--version'],capture_output=True,text=True).stdout.splitlines()[0],
            'cases':rows}
    (out/'summary.json').write_text(json.dumps(result,indent=2))
    for c in cases:
        target=ROOT/'transaction_results'/c['id']/'program'
        if passed:
            subprocess.run([COMPILER,'-Wall','-Werror',str(target.parent/'repaired.c'),'-o',str(target),'-lm'],check=True,capture_output=True,text=True)
        else:target.unlink(missing_ok=True)
    print('RELEASE_GATE',json.dumps({k:v for k,v in result.items() if k!='cases'}),flush=True)
    if not passed:raise SystemExit(1)

if __name__=='__main__':main()
