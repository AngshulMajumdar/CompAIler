"""Rerun the frozen 88-case suite, preserving V1 and using unseen extra evaluations."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import tempfile
import time
from aicc import ROOT,check
from aicc_v2 import POLICY,ReviewModel,repair_program_v2
from fresh_tests_v2 import build_fresh,SEED

OUT=ROOT/'large_results_v2'

def save_summary(rows):
    faulty=[r for r in rows if r['kind']=='faulty'];controls=[r for r in rows if r['kind']=='clean_control']
    s={'completed':len(rows),'faulty_cases':len(faulty),'v2_validated':sum(r['v2_validated'] for r in faulty),
       'v1_validated':sum(r['v1_validated'] for r in faulty),
       'gains':[r['id'] for r in faulty if r['v2_validated'] and not r['v1_validated']],
       'regressions':[r['id'] for r in rows if r['v1_validated'] and not r['v2_validated']],
       'controls_passed':sum(r['v2_validated'] for r in controls),'controls':len(controls),
       'controls_unchanged':sum(not r['source_changed'] for r in controls),
       'generation_seconds':round(sum(r['generation_seconds'] for r in rows),3),
       'model_calls':sum(r['model_calls'] for r in rows),
       'original_heldout_passed':sum(r['heldout_pass_count'] for r in rows),
       'original_heldout_total':sum(r['heldout_test_count'] for r in rows),
       'fresh_passed':sum(r['fresh_pass_count'] for r in rows),
       'fresh_total':sum(r['fresh_test_count'] for r in rows),'cases':rows}
    (OUT/'summary.json').write_text(json.dumps(s,indent=2));return s

def main():
    OUT.mkdir(exist_ok=True)
    cases=json.loads((ROOT/'large_suite/cases.json').read_text())
    prior=json.loads((ROOT/'large_results/summary.json').read_text())
    old={r['id']:r for r in prior['cases']}
    targets={r['id'] for r in prior['cases'] if r['kind']=='faulty' and not r['validated']}
    cases.sort(key=lambda c:(c['id'] not in targets, c['kind']=='clean_control'))
    fp=ROOT/'fresh_tests_v2.json'
    if not fp.exists():fp.write_text(json.dumps({'seed':SEED,'tasks':build_fresh(cases)},indent=2))
    fresh=json.loads(fp.read_text())['tasks']
    compiler=str(ROOT/'vendor/tcc-0.9.27/install/bin/tcc')
    plan={'policy':POLICY,'cases_sha256':hashlib.sha256((ROOT/'large_suite/cases.json').read_bytes()).hexdigest(),
          'implementation_sha256':hashlib.sha256((ROOT/'aicc_v2.py').read_bytes()).hexdigest(),
          'fresh_tests_sha256':hashlib.sha256(fp.read_bytes()).hexdigest(),
          'fresh_seed':SEED,'target_first':sorted(targets),
          'note':'Policies frozen before model runs. Old held-out and new tests are evaluation-only.'}
    policyfile=OUT/'frozen_plan.json'
    if policyfile.exists():assert json.loads(policyfile.read_text())==plan
    else:policyfile.write_text(json.dumps(plan,indent=2))
    pre=OUT/'reference_preflight.json'
    if not pre.exists():
        refs={}
        with tempfile.TemporaryDirectory(prefix='v2-ref-') as tmp:
            for c in cases:
                if c['task'] in refs:continue
                tests=c['visible']+c['hidden']+fresh[c['task']]
                source=(ROOT/'large_suite/references'/(c['task']+'.c')).read_text()
                report=check(source,Path(tmp),compiler,tests)
                refs[c['task']]={'passed':report['passed'],'test_count':len(tests)}
                print('REFERENCE',c['task'],refs[c['task']],flush=True)
                if not report['passed']:
                    (OUT/'preflight_error.json').write_text(json.dumps(report,indent=2))
                    raise RuntimeError('Reference disagreement: '+c['task'])
        pre.write_text(json.dumps(refs,indent=2))
    model=None;rows=[]
    for i,c in enumerate(cases,1):
        folder=OUT/c['id'];folder.mkdir(exist_ok=True);done=folder/'evaluation.json'
        if done.exists():rows.append(json.loads(done.read_text()));continue
        if model is None:model=ReviewModel(ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
        print('CASE',i,len(cases),c['id'],flush=True);start=time.monotonic()
        reportfile=folder/'report.json'
        if reportfile.exists():report=json.loads(reportfile.read_text())
        else:report=repair_program_v2(model,c['source'],c['requirement'],c['visible'],compiler,folder)
        with tempfile.TemporaryDirectory(prefix='v2-eval-') as tmp:
            heldout=check((folder/'repaired.c').read_text(),Path(tmp),compiler,c['hidden'])
            extra=check((folder/'repaired.c').read_text(),Path(tmp),compiler,fresh[c['task']])
            oldfresh=check((ROOT/'large_results'/c['id']/'repaired.c').read_text(),Path(tmp),compiler,fresh[c['task']])
        for name,data in [('heldout',heldout),('fresh',extra),('v1_fresh',oldfresh)]:
            (folder/(name+'.json')).write_text(json.dumps(data,indent=2))
        row={'id':c['id'],'task':c['task'],'kind':c['kind'],'category':c['category'],
             'v1_validated':old[c['id']]['validated'] and oldfresh['passed'],
             'v1_original_heldout_validated':old[c['id']]['validated'],
             'v2_validated':report['passed'] and heldout['passed'] and extra['passed'],
             'visible_passed':report['passed'],'heldout_passed':heldout['passed'],'fresh_passed':extra['passed'],
             'model_calls':report['model_calls'],'source_changed':report['source_changed'],
             'generation_seconds':report['generation_seconds'],'wall_seconds':round(time.monotonic()-start,3),
             'heldout_pass_count':sum(t['passed'] for t in heldout['tests']),'heldout_test_count':len(c['hidden']),
             'fresh_pass_count':sum(t['passed'] for t in extra['tests']),'fresh_test_count':len(fresh[c['task']]),
             'baseline_fresh_pass_count':sum(t['passed'] for t in oldfresh['tests'])}
        done.write_text(json.dumps(row,indent=2));rows.append(row)
        s=save_summary(rows)
        print('PROGRESS',json.dumps({k:v for k,v in s.items() if k!='cases'}),flush=True)
    print('FINISHED',json.dumps({k:v for k,v in save_summary(rows).items() if k!='cases'}),flush=True)

if __name__=='__main__':main()
