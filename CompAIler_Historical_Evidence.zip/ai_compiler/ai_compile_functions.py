"""CPU repair through complete function replacements and actual compiler checks."""
import argparse
import json
from pathlib import Path
from aicc import ROOT
from function_compile import FunctionModel,repair
from run_large_programs import COMPILER

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path)
    p.add_argument('--requirement-file',type=Path,required=True);p.add_argument('--tests',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--compiler',default=COMPILER)
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf');a=p.parse_args()
    r=repair(FunctionModel(a.model),a.source.read_text(),a.requirement_file.read_text(),
             json.loads(a.tests.read_text()),a.compiler,a.output)
    print(json.dumps({'passed':r['final']['passed'],'compiled':r['final']['compiled'],'calls':r['calls'],
                      'source':str(a.output/'repaired.c'),'model_file':str(a.model)}))
    if not r['final']['passed']:(a.output/'program').unlink(missing_ok=True)
    raise SystemExit(0 if r['final']['passed'] else 1)

if __name__=='__main__':main()
