"""Small CPU model proposals, compiler-guided search, and fail-closed test release."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
from aicc import ROOT,check
from chunk_compile import functions,c_tokens
from function_compile import FunctionModel,repair as model_repair
from search_compile import function_pool,repair as local_search
from transaction_search import repair as dependency_search
from run_large_programs import COMPILER

def signatures(source):
    return [(f['name'],[t[0] for t in c_tokens(f['signature'])]) for f in functions(source)]

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path)
    p.add_argument('--requirement-file',type=Path,required=True);p.add_argument('--tests',type=Path,required=True)
    p.add_argument('--extra-tests',type=Path,help='Additional user-supplied boundary/behavior tests')
    p.add_argument('--llm-cache',type=Path,help='Reuse prior complete-function CPU proposals for this exact source and requirement')
    p.add_argument('--output',type=Path,required=True);p.add_argument('--compiler',default=COMPILER)
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf');a=p.parse_args()
    source=a.source.read_text();req=a.requirement_file.read_text();base=json.loads(a.tests.read_text())
    extra=json.loads(a.extra_tests.read_text()) if a.extra_tests else []
    if not isinstance(base,list) or not base:p.error('At least one behavioral test is required')
    tests=base+extra;a.output.mkdir(parents=True,exist_ok=True)
    manifest={'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'requirement':req,
              'base_tests':base,'extra_tests':extra,'compiler':a.compiler,'model_file':str(a.model)}
    path=a.output/'input_manifest.json'
    if path.exists() and json.loads(path.read_text())!=manifest:p.error('Output directory belongs to different inputs; choose a fresh directory')
    path.write_text(json.dumps(manifest,indent=2))
    (a.output/'program').unlink(missing_ok=True)
    if a.llm_cache:
        if (a.llm_cache/'original.c').read_text()!=source:p.error('Cached proposals belong to different source')
        model_report=json.loads((a.llm_cache/'report.json').read_text())
        if not all(e['request']['prompt'].startswith('Program behavior:\n'+req+'\n') for e in model_report['history']):
            p.error('Cached proposals belong to a different requirement')
        model_source=(a.llm_cache/'repaired.c').read_text();new_calls=0
    else:
        stage=a.output/'model_stage'
        model_report=model_repair(FunctionModel(a.model),source,req,base,a.compiler,stage)
        model_source=(stage/'repaired.c').read_text();new_calls=model_report['calls']
        (stage/'program').unlink(missing_ok=True)
    pool=function_pool(source,model_report);wanted=dict(signatures(source))
    pool={name:[code for code in variants if signatures(code)==[(name,wanted[name])]] for name,variants in pool.items()}
    local_search(source,model_source,pool,base,a.compiler,a.output/'local_search')
    seed=(a.output/'local_search/repaired.c').read_text()
    dependency_search(source,seed,pool,tests,a.compiler,a.output/'dependency_search')
    selected=(a.output/'dependency_search/repaired.c').read_text();assert signatures(selected)==signatures(source)
    (a.output/'repaired.c').write_text(selected)
    with tempfile.TemporaryDirectory(prefix='verified-release-') as tmp:
        result=check(selected,Path(tmp),a.compiler,tests)
        if result['passed']:shutil.copy2(Path(tmp)/'program',a.output/'program')
    report={'passed':result['passed'],'compiled':result['compiled'],'tests_passed':sum(t['passed'] for t in result['tests']),
            'test_count':len(tests),'new_model_calls':new_calls,'cached_model_proposals':bool(a.llm_cache),
            'final':result,'executable_released':result['passed'],'gpu_layers':0}
    (a.output/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='final'}))
    raise SystemExit(0 if result['passed'] else 1)

if __name__=='__main__':main()
