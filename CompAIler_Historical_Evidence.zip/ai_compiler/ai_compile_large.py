#!/usr/bin/env python3
"""Run the same staged compiler wrapper with capacity for larger C source files."""
import argparse
import json
from pathlib import Path
import shutil
from aicc import ROOT
from aicc_v2 import repair_program_v2
from aicc_v3 import finalize_v3
from ai_compile import finalize_last
from large_program_runtime import LargeProgramModel

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path)
    req=p.add_mutually_exclusive_group(required=True);req.add_argument('--requirement');req.add_argument('--requirement-file',type=Path)
    p.add_argument('--tests',type=Path)
    local=ROOT/'vendor/tcc-0.9.27/install/bin/tcc'
    p.add_argument('--compiler',default=str(local) if local.exists() else ('tcc' if shutil.which('tcc') else 'gcc'))
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
    p.add_argument('--output',type=Path,default=ROOT/'output_large');a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    model=LargeProgramModel(a.model,a.output/'engine_calls.jsonl')
    requirement=a.requirement_file.read_text() if a.requirement_file else a.requirement
    tests=json.loads(a.tests.read_text()) if a.tests else []
    first=a.output/'v2_stage';second=a.output/'v3_stage'
    repair_program_v2(model,a.source.read_text(),requirement,tests,a.compiler,first)
    finalize_v3(model,first,requirement,tests,a.compiler,second)
    result=finalize_last(model,second,requirement,tests,a.compiler,a.output)
    print('Result:',('tests_passed' if a.tests else 'compiled_only') if result['passed'] else 'failed')
    raise SystemExit(0 if result['passed'] else 1)

if __name__=='__main__':main()
