"""Larger, stateful C tasks, independent Python oracles, and explicit multi-fault mutations."""
import ast
from collections import OrderedDict,deque
import json
import math
import random
import re
from aicc import ROOT

DEST=ROOT/'large_program_suite'
SEED=2026112401
R=random.Random(SEED)

def command_input(commands,prefix=None):
    first=str(len(commands)) if prefix is None else f'{prefix} {len(commands)}'
    return first+'\n'+'\n'.join(commands)+'\n'

def inventory_oracle(commands):
    items={};revenue=0;out=[]
    for line in commands:
        op,*raw=line.split();a=list(map(int,raw));ok=True
        if op=='ADD':
            k,p=a;ok=k not in items and p>=0 and len(items)<100
            if ok:items[k]=[0,p]
        elif op=='RECEIVE':
            k,n=a;ok=k in items and n>=0
            if ok:items[k][0]+=n
        elif op=='SELL':
            k,n=a;ok=k in items and n>=0 and items[k][0]>=n
            if ok:items[k][0]-=n;revenue+=n*items[k][1]
        elif op=='PRICE':
            k,p=a;ok=k in items and p>=0
            if ok:items[k][1]=p
        elif op=='DROP':
            k=a[0];ok=k in items and items[k][0]==0
            if ok:del items[k]
        elif op=='GET':
            k=a[0];out.append(f'{k} {items[k][0]} {items[k][1]}' if k in items else 'ERR');continue
        elif op=='LIST':
            out.append(str(len(items)))
            out.extend(f'{k} {items[k][0]} {items[k][1]}' for k in sorted(items));continue
        else:out.append(f'{sum(n*p for n,p in items.values())} {revenue}');continue
        out.append('OK' if ok else 'ERR')
    return '\n'.join(out)

def grade_oracle(commands):
    students={};out=[]
    def score(g):return (2*g[0]+3*g[1]+5*g[2])//10
    for line in commands:
        op,*raw=line.split();a=list(map(int,raw));ok=True
        if op=='ADD':
            k,*g=a;ok=k not in students and len(students)<100 and all(0<=v<=100 for v in g)
            if ok:students[k]=g
        elif op=='UPDATE':
            k,s,g=a;ok=k in students and 0<=s<3 and 0<=g<=100
            if ok:students[k][s]=g
        elif op=='DROP':
            k=a[0];ok=k in students
            if ok:del students[k]
        elif op=='SCORE':
            k=a[0];out.append(str(score(students[k])) if k in students else 'ERR');continue
        elif op=='RANK':
            order=sorted(students,key=lambda k:(-score(students[k]),k));out.append(str(len(order)))
            out.extend(f'{k} {score(students[k])}' for k in order);continue
        else:
            values=[score(g) for g in students.values()]
            out.append(f'{len(values)} {sum(values)//len(values) if values else 0} {sum(v>=50 for v in values)}');continue
        out.append('OK' if ok else 'ERR')
    return '\n'.join(out)

def lru_oracle(capacity,commands):
    cache=OrderedDict();out=[]
    for line in commands:
        op,*raw=line.split();a=list(map(int,raw))
        if op=='PUT':
            k,v=a
            if k in cache:del cache[k]
            elif len(cache)==capacity:cache.popitem(last=False)
            cache[k]=v;out.append('OK')
        elif op=='GET':
            k=a[0]
            if k not in cache:out.append('MISS')
            else:
                v=cache.pop(k);cache[k]=v;out.append(str(v))
        elif op=='DEL':
            k=a[0];out.append('OK' if k in cache else 'MISS');cache.pop(k,None)
        elif op=='RESIZE':
            capacity=a[0]
            while len(cache)>capacity:cache.popitem(last=False)
            out.append('OK')
        elif op=='CLEAR':cache.clear();out.append('OK')
        elif op=='SIZE':out.append(str(len(cache)))
        else:out.append(' '.join(map(str,[len(cache)]+list(reversed(cache)))))
    return '\n'.join(out)

def graph_oracle(n,edges,commands):
    matrix=[[None]*n for _ in range(n)]
    def edge(u,v,w):
        if matrix[u][v] is None or w<matrix[u][v]:matrix[u][v]=w
    def reset():
        for i in range(n):
            for j in range(n):matrix[i][j]=0 if i==j else None
    def distances(source):
        # Bellman-Ford oracle, independent of the reference Dijkstra implementation.
        d=[None]*n;d[source]=0
        for _ in range(n-1):
            changed=False
            for i in range(n):
                for j in range(n):
                    w=matrix[i][j]
                    if d[i] is not None and w is not None and (d[j] is None or d[i]+w<d[j]):
                        d[j]=d[i]+w;changed=True
            if not changed:break
        return d
    reset()
    for e in edges:edge(*e)
    out=[]
    for line in commands:
        op,*raw=line.split();a=list(map(int,raw))
        if op=='EDGE':edge(*a);out.append('OK');continue
        if op=='RESET':reset();out.append('OK');continue
        if op=='BFS':
            s,t=a;d=[-1]*n;d[s]=0;q=deque([s])
            while q:
                u=q.popleft()
                for v,w in enumerate(matrix[u]):
                    if w is not None and d[v]<0:d[v]=d[u]+1;q.append(v)
            out.append(str(d[t]));continue
        d=distances(a[0]);fmt=lambda x:'INF' if x is None else str(x)
        if op=='DIST':out.append(fmt(d[a[1]]))
        elif op=='ALL':out.append(' '.join(map(fmt,d)))
        elif op=='REACH':out.append(str(sum(v is not None for v in d)))
        else:out.append('INF' if None in d else str(sum(d)))
    return '\n'.join(out)

def expression_oracle(expressions):
    def evaluate(node):
        if isinstance(node,ast.Constant) and type(node.value) is int:return node.value
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            a=evaluate(node.operand);return -a if isinstance(node.op,ast.USub) else a
        if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Div)):
            a,b=evaluate(node.left),evaluate(node.right)
            if isinstance(node.op,ast.Add):return a+b
            if isinstance(node.op,ast.Sub):return a-b
            if isinstance(node.op,ast.Mult):return a*b
            if b==0:raise ValueError('division by zero')
            return (abs(a)//abs(b))*(-1 if (a<0)!=(b<0) else 1)
        raise ValueError('unsupported syntax')
    out=[]
    for text in expressions:
        try:
            if re.search(r'[^0-9+*/()\s-]',text) or '//' in text or '**' in text:raise ValueError('invalid token')
            tree=ast.parse(text.strip(),mode='eval');answer=evaluate(tree.body)
            out.append(str(answer))
        except (SyntaxError,ValueError,ZeroDivisionError):out.append('ERROR')
    return '\n'.join(out)

def sparse_oracle(operations):
    def dense(nr,nc,entries):
        a=[[0]*nc for _ in range(nr)]
        for i,j,x in entries:a[i][j]+=x
        return a
    out=[];input_lines=[str(len(operations))]
    for op,shape,entries_a,entries_b in operations:
        if op=='TRANS':
            nr,nc=shape;input_lines.append(f'TRANS {nr} {nc} {len(entries_a)}')
            a=dense(nr,nc,entries_a);result=list(map(list,zip(*a)));rr,cc=nc,nr
        elif op=='ADD':
            nr,nc=shape;input_lines.append(f'ADD {nr} {nc} {len(entries_a)} {len(entries_b)}')
            a=dense(nr,nc,entries_a);b=dense(nr,nc,entries_b)
            result=[[a[i][j]+b[i][j] for j in range(nc)] for i in range(nr)];rr,cc=nr,nc
        else:
            nr,inner,nc=shape;input_lines.append(f'MUL {nr} {inner} {nc} {len(entries_a)} {len(entries_b)}')
            a=dense(nr,inner,entries_a);b=dense(inner,nc,entries_b)
            result=[[sum(a[i][k]*b[k][j] for k in range(inner)) for j in range(nc)] for i in range(nr)];rr,cc=nr,nc
        input_lines.extend(' '.join(map(str,e)) for e in entries_a+entries_b)
        nonzero=[(i,j,result[i][j]) for i in range(rr) for j in range(cc) if result[i][j]]
        out.append(f'{rr} {cc} {len(nonzero)}');out.extend(' '.join(map(str,e)) for e in nonzero)
    return '\n'.join(input_lines)+'\n','\n'.join(out)

def fixtures():
    data={}
    inv=[
      ['ADD 9 100','RECEIVE 9 4','RECEIVE 9 3','GET 9','SELL 9 7','GET 9','DROP 9','LIST','TOTAL'],
      ['ADD 8 1000000','ADD 2 17','RECEIVE 8 1000000','SELL 8 5','TOTAL','PRICE 8 3','TOTAL','LIST','DROP 8','GET 8'],
      ['ADD 4 50','ADD 4 80','ADD 1 -1','RECEIVE 3 4','SELL 4 -2','RECEIVE 4 2','SELL 4 3','GET 4','TOTAL'],
      ['ADD 5 2','ADD 3 4','ADD 1 8','DROP 3','LIST','ADD 3 7','RECEIVE 3 5','SELL 3 0','LIST','TOTAL']]
    for _ in range(24):
        cmds=[f'ADD {i} {R.randint(0,1000000)}' for i in [7,2,11]]
        for _ in range(35):
            op=R.choice(['ADD','RECEIVE','SELL','PRICE','DROP','GET','LIST','TOTAL']);k=R.randint(1,12)
            if op in ['LIST','TOTAL']:cmds.append(op)
            elif op in ['DROP','GET']:cmds.append(f'{op} {k}')
            else:cmds.append(f'{op} {k} {R.randint(-2,1000000) if op in ["ADD","PRICE"] else R.randint(-2,30)}')
        cmds+=['LIST','TOTAL'];inv.append(cmds)
    data['inventory']=[{'input':command_input(c),'output':inventory_oracle(c)} for c in inv]
    grades=[
      ['ADD 8 50 50 50','ADD 2 50 50 50','ADD 4 100 0 0','RANK','SUMMARY','SCORE 8'],
      ['ADD 3 10 20 30','UPDATE 3 2 100','SCORE 3','UPDATE 3 0 90','SCORE 3','SUMMARY'],
      ['ADD 7 100 100 100','ADD 2 30 40 50','ADD 9 0 0 0','DROP 2','RANK','DROP 7','SUMMARY','DROP 9','SUMMARY'],
      ['ADD 1 100 100 101','ADD 4 20 30 40','ADD 4 99 99 99','UPDATE 4 3 4','UPDATE 4 1 -1','SCORE 4','SCORE 99','RANK']]
    for _ in range(24):
        cmds=[f'ADD {i} {R.randint(0,100)} {R.randint(0,100)} {R.randint(0,100)}' for i in [8,2,4]]
        for _ in range(32):
            op=R.choice(['ADD','UPDATE','DROP','SCORE','RANK','SUMMARY']);k=R.randint(1,10)
            if op=='ADD':cmds.append(f'ADD {k} {R.randint(-1,101)} {R.randint(-1,101)} {R.randint(-1,101)}')
            elif op=='UPDATE':cmds.append(f'UPDATE {k} {R.randint(-1,3)} {R.randint(-1,101)}')
            elif op in ['DROP','SCORE']:cmds.append(f'{op} {k}')
            else:cmds.append(op)
        cmds+=['RANK','SUMMARY'];grades.append(cmds)
    data['gradebook']=[{'input':command_input(c),'output':grade_oracle(c)} for c in grades]
    lru=[
      (2,['PUT 1 10','PUT 2 20','GET 1','PUT 3 30','KEYS','GET 2','PUT 1 99','GET 1','KEYS']),
      (4,['PUT 1 1','PUT 2 2','PUT 3 3','PUT 4 4','RESIZE 1','KEYS','SIZE','DEL 4','SIZE','KEYS','CLEAR','KEYS']),
      (3,['PUT 1 1','PUT 2 2','PUT 3 3','DEL 2','KEYS','GET 1','KEYS','PUT 4 4','PUT 5 5','KEYS']),
      (1,['GET 9','DEL 9','PUT 4 8','PUT 4 3','GET 4','PUT 5 -9','GET 4','GET 5','SIZE','CLEAR','SIZE'])]
    for _ in range(24):
        cap=R.randint(1,8);cmds=[]
        for _ in range(45):
            op=R.choices(['PUT','GET','DEL','RESIZE','CLEAR','SIZE','KEYS'],weights=[8,4,2,1,1,1,3])[0]
            if op=='PUT':cmds.append(f'PUT {R.randint(0,12)} {R.randint(-100,100)}')
            elif op in ['GET','DEL']:cmds.append(f'{op} {R.randint(0,12)}')
            elif op=='RESIZE':cmds.append(f'RESIZE {R.randint(1,8)}')
            else:cmds.append(op)
        cmds+=['KEYS','SIZE'];lru.append((cap,cmds))
    data['lru_cache']=[{'input':command_input(c,cap),'output':lru_oracle(cap,c)} for cap,c in lru]
    graphs=[
      (4,[(0,1,9),(0,1,2),(1,2,0)],['ALL 0','DIST 2 0','BFS 0 2','REACH 0','ROUND 0','EDGE 2 3 1','ALL 0','ROUND 0']),
      (3,[],['DIST 0 0','BFS 0 0','REACH 0','ALL 2','EDGE 2 0 0','BFS 2 0','ALL 2']),
      (4,[(0,1,1),(1,2,2),(0,2,10),(2,3,3)],['DIST 0 3','ALL 1','ROUND 0','EDGE 0 3 0','ALL 0','RESET','ALL 0']),
      (2,[(1,0,0),(1,0,8)],['ALL 1','BFS 1 0','DIST 0 1','REACH 1','ROUND 1','EDGE 0 1 5','ALL 0'])]
    for _ in range(24):
        n=R.randint(2,8);edges=[(R.randrange(n),R.randrange(n),R.randint(0,20)) for _ in range(R.randint(0,25))];cmds=[]
        for _ in range(25):
            op=R.choice(['EDGE','DIST','ALL','BFS','REACH','ROUND','RESET']);u=R.randrange(n);v=R.randrange(n)
            if op=='EDGE':cmds.append(f'EDGE {u} {v} {R.randint(0,20)}')
            elif op in ['DIST','BFS']:cmds.append(f'{op} {u} {v}')
            elif op=='RESET':cmds.append(op)
            else:cmds.append(f'{op} {u}')
        graphs.append((n,edges,cmds))
    data['graph_engine']=[]
    for n,e,c in graphs:
        stdin=f'{n} {len(e)} {len(c)}\n'+''.join(' '.join(map(str,x))+'\n' for x in e)+'\n'.join(c)+'\n'
        data['graph_engine'].append({'input':stdin,'output':graph_oracle(n,e,c)})
    expressions=[
      ['12+3*4','(2+3)*4','-7/3','8-3-2','5/0','1+2x'],
      ['--4','2*-3','+(8-10)','20/(3+2)','(4+5','1+2)','0/4'],
      ['  7 + 8 * 2 ','100-20/3','4*(2+(3*5))','5/-2','3**2','','1 2'],
      ['999','-(4+3)*2','3--2','2++3','0-0','()','7/(-3)','(1+2)/(2-2)']]
    def generate(depth):
        if depth==0:return str(R.randint(0,30))
        if R.random()<.25:return R.choice(['-','+'])+'('+generate(depth-1)+')'
        return '('+generate(depth-1)+R.choice(['+','-','*','/'])+generate(depth-1)+')'
    for _ in range(24):
        es=[generate(R.randint(1,3)) for _ in range(12)]
        es += [R.choice(['2+','(3*4','1/0','9z','4//2','8 8'])]
        expressions.append(es)
    data['expression_parser']=[{'input':str(len(es))+'\n'+'\n'.join(es)+'\n','output':expression_oracle(es)} for es in expressions]
    sparse=[
      [('TRANS',(2,3),[(0,1,2),(0,1,5),(1,2,0),(1,0,4)],[]),('ADD',(2,2),[(0,1,8)],[(0,1,-8),(1,0,3)])],
      [('MUL',(2,3,2),[(0,2,3),(1,0,4)],[(2,1,5),(0,0,2)]),('TRANS',(1,3),[(0,2,9),(0,0,1)],[])],
      [('ADD',(3,2),[(2,1,3),(0,1,4),(0,0,2)],[(0,1,5),(2,0,7)]),('MUL',(1,1,1),[(0,0,100000)],[(0,0,100000)])],
      [('TRANS',(2,1),[],[]),('MUL',(2,2,3),[(0,0,2),(0,0,-2)],[(0,2,8)]),('ADD',(1,1),[(0,0,0)],[(0,0,0)])]]
    def entries(nr,nc):return [(R.randrange(nr),R.randrange(nc),R.randint(-10,10)) for _ in range(R.randint(0,20))]
    for _ in range(24):
        operations=[]
        for _ in range(4):
            op=R.choice(['ADD','MUL','TRANS']);nr,nc,inner=R.randint(1,5),R.randint(1,5),R.randint(1,5)
            if op=='MUL':operations.append((op,(nr,inner,nc),entries(nr,inner),entries(inner,nc)))
            else:operations.append((op,(nr,nc),entries(nr,nc),entries(nr,nc) if op=='ADD' else []))
        sparse.append(operations)
    data['sparse_matrix']=[dict(zip(['input','output'],sparse_oracle(ops))) for ops in sparse]
    return data

REQUIREMENTS={
 'inventory':'''Inventory service. Input q (0..200), then q commands. At most 100 distinct items; IDs are integers 0..1000. Prices and quantities supplied to commands are integers in [-2,1000000]. ADD id price creates an absent item with zero stock; reject duplicates, negative price, or capacity overflow. RECEIVE id qty adds nonnegative qty to an existing item. SELL id qty subtracts nonnegative qty only if sufficient stock; exact-stock sales and zero-quantity sales are allowed. Successful sale adds qty*current_price to lifetime revenue. PRICE id price updates an existing item's nonnegative price. DROP id removes only an existing item with zero stock. These five mutating commands print OK on success, ERR otherwise and change nothing on failure. GET id prints 'id stock price' or ERR. LIST prints item count, then rows 'id stock price' in increasing ID order. TOTAL prints 'stock_value revenue', both exact 64-bit totals; stock_value=sum(stock*current_price). Revenue is not changed by price updates or deletion. Every output record ends with newline.''',
 'gradebook':'''Gradebook. Read q (0..200), then q commands. Up to 100 students, IDs 0..1000. ADD id a b c adds an absent student with three marks 0..100. UPDATE id subject mark updates an existing student's subject indexed 0,1,2, rejecting other subject numbers or marks outside 0..100. DROP id removes an existing student. Mutations print OK or ERR and rejected mutations change nothing. SCORE id prints floor((2*a+3*b+5*c)/10), or ERR if absent. RANK prints student count then 'id score' rows sorted by decreasing score, breaking ties by increasing ID. SUMMARY prints 'count mean_score passing_count', where mean_score is floor of the mean of already-rounded student scores and passing_count counts scores >=50. Empty summary is '0 0 0'. Supplied invalid marks and subject indices must be rejected. One output record per line.''',
 'graph_engine':'''Directed weighted graph service. Input n m q, n=1..32, m<=100, q<=100. Next m rows are u v w, then q commands. Vertices are 0..n-1; weights 0..1000000. Parallel edges retain their minimum weight, including EDGE updates. Self-distance is zero; edges are directed. EDGE u v w adds/min-updates an edge and prints OK. DIST s t prints exact shortest distance or INF if unreachable. ALL s prints n shortest distances in vertex order, separated by single spaces, using INF. BFS s t prints minimum number of edges ignoring weights (zero-weight edges are valid), or -1 when unreachable; BFS s s is 0. REACH s counts reachable vertices INCLUDING s. ROUND s prints the sum of all shortest distances from s if every vertex is reachable, otherwise INF. RESET removes all edges, preserving n and zero self-distances, and prints OK. Output each command's result on one line.''',
 'expression_parser':'''Integer expression evaluator. Input t (0..40) on first line, followed by t complete expression lines, each at most 200 characters. Grammar supports unsigned decimal integer literals, spaces, parentheses, unary + and -, and binary + - * /. Unary signs bind most tightly, then * and /, then + and -. Binary operators associate left-to-right. Division truncates toward zero, including negative operands. Print the exact integer result for each valid line. Print ERROR for division by zero, invalid characters/tokens, empty expression, missing operand, unmatched parentheses or trailing unparsed text. Only these operators are allowed, not // or **. Permitted valid inputs have integer intermediates within signed 32-bit range. One result per line; do not print prompts.''',
 'lru_cache':'''LRU cache. Input capacity q, capacity=1..20 and q<=200, then q commands. Keys and values are signed integers of magnitude <=1000000. PUT key value inserts or replaces; an existing key's value is replaced and it becomes most recently used. A new key at full capacity evicts the least recently used key. PUT prints OK. GET key prints its value and makes it most recently used, or MISS and leaves the cache unchanged. DEL key prints OK and removes it, or MISS if absent. RESIZE capacity (1..20) changes capacity, repeatedly evicting least-recently-used entries if needed, and prints OK. CLEAR empties the cache and prints OK. SIZE prints the number of entries. KEYS prints count followed by keys in MOST-to-LEAST-recent order on one line, single spaces, with just 0 when empty. All command output ends with newline.''',
 'sparse_matrix':'''Sparse integer matrix service. Input q<=20 operations. TRANS r c na is followed by na triplets row col value for A; print A transpose. ADD r c na nb is followed by na triplets for A then nb for B (both r-by-c); print A+B. MUL r k c na nb is followed by A's na triplets (r-by-k) then B's nb triplets (k-by-c); print A*B. Dimensions 1..8, counts 0..100, coordinates zero-based and in range, entries magnitude <=100000. Duplicate coordinates in each input are SUMMED; explicit zero entries and zero sums must be omitted from output. Use exact 64-bit arithmetic. For every result print 'rows columns nnz', then nnz rows 'row col value' in increasing row then column order. Separate values by one space and end every record with newline.'''}

MUTATIONS={
 'inventory':[
  ('last_item_lookup','for (i = 0; i < item_count; ++i) {\n        if (items[i].id == id)','for (i = 0; i < item_count - 1; ++i) {\n        if (items[i].id == id)'),
  ('receive_overwrites_stock','items[index].stock += quantity;','items[index].stock = quantity;'),
  ('reject_exact_stock_sale','items[index].stock < quantity','items[index].stock <= quantity'),
  ('sale_increases_stock','items[index].stock -= quantity;','items[index].stock += quantity;'),
  ('stock_valuation_int_overflow','total += (long long) items[i].stock * items[i].price;','total += items[i].stock * items[i].price;'),
  ('reverse_listing','items[order[j]].id < items[order[i]].id','items[order[j]].id > items[order[i]].id'),
  ('inverted_drop_rule','items[index].stock != 0','items[index].stock == 0'),
  ('missing_semicolon','++item_count;\n    return 1;','++item_count\n    return 1;')],
 'gradebook':[
  ('wrong_grade_weights','2 * student->marks[0] + 3 * student->marks[1]\n            + 5 * student->marks[2]','5 * student->marks[0] + 3 * student->marks[1]\n            + 2 * student->marks[2]'),
  ('update_wrong_subject','students[index].marks[subject] = mark;','students[index].marks[(subject + 1) % 3] = mark;'),
  ('broken_delete_compaction','students[i] = students[i + 1];','students[i + 1] = students[i];'),
  ('rank_ascending','return a > b;','return a < b;'),
  ('rank_tie_reversed','return students[left].id < students[right].id;','return students[left].id > students[right].id;'),
  ('exclude_exact_pass','value >= 50','value > 50'),
  ('wrong_class_average','total / student_count','total / (student_count + 1)')],
 'graph_engine':[
  ('overwrite_parallel_minimum','if (weight < graph[from][to])','if (1)'),
  ('make_graph_undirected','graph[from][to] = weight;','graph[from][to] = weight;\n        graph[to][from] = weight;'),
  ('source_distance_offset','distance[source] = 0;','distance[source] = 1;'),
  ('wrong_vertex_selection','distance[i] < best','distance[i] > best'),
  ('inverted_relaxation','candidate < distance[next]','candidate > distance[next]'),
  ('ignore_zero_weight_in_bfs','graph[node][next] < INF && hops[next] < 0','graph[node][next] > 0 && graph[node][next] < INF && hops[next] < 0'),
  ('exclude_source_from_reach','int result = 0;','int result = -1;')],
 'expression_parser':[
  ('wrong_decimal_accumulation','value = value * 10 + digit;','value = value + digit;'),
  ('wrong_closing_delimiter',"if (!take(parser, ')'))", "if (!take(parser, ']'))"),
  ('ignore_unary_minus','return -parse_unary(parser);','return parse_unary(parser);'),
  ('addition_instead_of_multiplication','value *= right;','value += right;'),
  ('inverted_division','return left / right;','return right / left;'),
  ('addition_instead_of_subtraction','value -= right;','value += right;'),
  ('inverted_end_validation',"if (current(&parser) != '\\0')", "if (current(&parser) == '\\0')")],
 'lru_cache':[
  ('wrong_key_matching','node->key == key','node->key != key'),
  ('get_does_not_refresh','    move_to_front(node);\n    printf("%d\\n", node->value);','    printf("%d\\n", node->value);'),
  ('update_adds_to_old_value','node->value = value;','node->value += value;'),
  ('evict_most_recent','release_node(cache.tail);\n    }\n}\n\nstatic int cache_put','release_node(cache.head);\n    }\n}\n\nstatic int cache_put'),
  ('resize_evicts_only_once','while (cache.count > cache.capacity)','if (cache.count > cache.capacity)'),
  ('broken_back_link','node->next->previous = node->previous;','node->next->previous = NULL;'),
  ('size_not_decremented','--cache.count;','cache.count = cache.count;')],
 'sparse_matrix':[
  ('overwrite_duplicate_coordinates','matrix->entries[index].value += value;','matrix->entries[index].value = value;'),
  ('reverse_column_order','return a->column - b->column;','return b->column - a->column;'),
  ('keep_only_zero_entries','matrix->entries[read].value != 0','matrix->entries[read].value == 0'),
  ('wrong_transpose_shape','initialize_matrix(output, input->columns, input->rows);','initialize_matrix(output, input->rows, input->columns);'),
  ('subtract_second_matrix','Entry entry = b->entries[i];\n        add_entry(output, entry.row, entry.column, entry.value);','Entry entry = b->entries[i];\n        add_entry(output, entry.row, entry.column, -entry.value);'),
  ('wrong_inner_coordinate','a->entries[i].column == b->entries[j].row','a->entries[i].column == b->entries[j].column'),
  ('add_instead_of_multiply','a->entries[i].value * b->entries[j].value','a->entries[i].value + b->entries[j].value')]
}

def build():
    data=fixtures();cases=[]
    for task,tests in data.items():
        source=(DEST/'references'/(task+'.c')).read_text();broken=source;manifest=[]
        for name,old,new in MUTATIONS[task]:
            assert source.count(old)==1,(task,name,source.count(old))
            assert broken.count(old)==1,(task,name,'overlapping replacement')
            broken=broken.replace(old,new,1);manifest.append({'name':name,'old':old,'new':new})
        folder=DEST/'faulty';folder.mkdir(exist_ok=True);(folder/(task+'.c')).write_text(broken)
        metadata={'lines':len(source.splitlines()),'nonblank_lines':sum(bool(x.strip()) for x in source.splitlines()),
                  'functions':len(re.findall(r'^(?:static )?(?:int|void|long long|char|Node \*)[^;\n]*\([^;\n]*\)\n\{',source,re.M)),
                  'bytes':len(source.encode()),'faults':len(manifest)}
        cases.append({'id':task,'kind':'faulty','source':broken,'requirement':REQUIREMENTS[task],
                      'visible':tests[:4],'heldout':tests[4:],'mutations':manifest,'metadata':metadata})
    for task in ['inventory','expression_parser']:
        base=next(c for c in cases if c['id']==task)
        cases.append({**base,'id':task+'_correct_control','kind':'correct_control',
                      'source':(DEST/'references'/(task+'.c')).read_text(),'mutations':[],
                      'metadata':{**base['metadata'],'faults':0}})
    (DEST/'cases.json').write_text(json.dumps({'seed':SEED,'cases':cases},indent=2))
    print(json.dumps([{k:c[k] for k in ['id','kind','metadata']} for c in cases],indent=2))
    return cases

if __name__=='__main__':build()
