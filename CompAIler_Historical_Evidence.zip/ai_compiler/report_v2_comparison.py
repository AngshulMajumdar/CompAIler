"""Create a paired, regression-aware report; retain failures and all raw evidence."""
import csv
import json
from statistics import median
from aicc import ROOT

def main():
    s=json.loads((ROOT/'large_results_v2/summary.json').read_text());rows=s['cases']
    faulty=[r for r in rows if r['kind']=='faulty'];controls=[r for r in rows if r['kind']=='clean_control']
    old_original=sum(r['v1_original_heldout_validated'] for r in faulty)
    new_original=sum(r['visible_passed'] and r['heldout_passed'] for r in faulty)
    times=[r['generation_seconds'] for r in rows]
    fields=list(rows[0])
    with (ROOT/'large_results_v2/case_results.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    lines=['# AI compiler V2: paired comparison','',
      f"Completed {len(faulty)} faulty variants and {len(controls)} correct controls using the same 7B Q4_K_M model and TinyCC.",'',
      '| Outcome | V1 | V2 |','|---|---:|---:|',
      f'| Faulty cases passing original visible and held-out tests | {old_original}/{len(faulty)} | {new_original}/{len(faulty)} |',
      f"| Faulty cases passing original tests AND fresh evaluation inputs | {s['v1_validated']}/{len(faulty)} | {s['v2_validated']}/{len(faulty)} |",
      f"| Correct controls passing all evaluations | {len(controls)}/{len(controls)} | {s['controls_passed']}/{len(controls)} |",
      '',f"**Gains:** {len(s['gains'])}. **Regressions against previously passing V1 outputs:** {len(s['regressions'])}.",
      '',f"V2 passed {s['original_heldout_passed']}/{s['original_heldout_total']} original held-out executions and {s['fresh_passed']}/{s['fresh_total']} fresh executions.",
      '',f"V2 used {s['model_calls']} model calls, {s['generation_seconds']/60:.1f} minutes of generation in total, with a median of {median(times):.1f} seconds per submission. Model loading, compilation and evaluation are excluded.",
      '', '## Policy changes tested','',
      '- Every input receives an AI review, including programs already passing visible tests. The model can explicitly return UNCHANGED.',
      '- A one-sentence diagnosis precedes each proposed program. Subsequent requests show the previous diff, its observed effect, and expected versus actual outputs.',
      '- Repeated tokens, no score improvement, or a regression triggers a fresh implementation strategy with temperature 0.2 or 0.4. Successful incremental attempts stay at temperature zero.',
      '- A candidate that breaks any previously passing visible test is rejected. The best source is retained. The budget remains at most three model calls.',
      '- The old implementation and results remain in the archive. The V2 policy, source hash and evaluation fixtures were frozen before model runs.',
      '', '## Original unresolved cases','',
      '| Case | V1 | V2 | Calls |','|---|---|---|---:|']
    targets=json.loads((ROOT/'large_results_v2/frozen_plan.json').read_text())['target_first']
    indexed={r['id']:r for r in rows}
    for name in targets:
        if name in indexed:
            r=indexed[name];lines.append(f"| {name} | Fail | {'Pass' if r['v2_validated'] else 'Fail'} | {r['model_calls']} |")
    lines+=['','## Unresolved or regressed cases','',
            '| Case | V1 passed all evaluations | V2 visible | V2 original held-out | V2 fresh |',
            '|---|---|---|---|---|']
    failed=[r for r in rows if not r['v2_validated']]
    for r in failed:
        yn=lambda b:'Pass' if b else 'Fail'
        lines.append(f"| {r['id']} | {yn(r['v1_validated'])} | {yn(r['visible_passed'])} | {yn(r['heldout_passed'])} | {yn(r['fresh_passed'])} |")
    if not failed:lines.append('| None | — | — | — | — |')
    lines+=['','## Evaluation boundaries','',
      'The three earlier failures informed these general policy changes. Original held-out tests are retained for a paired regression comparison; the fresh inputs provide additional checks not used when designing the changes.',
      '', 'Fresh fixture seed: 2026112302. Twenty new input instances per task were generated, excluding every earlier visible and held-out input. Factorial has no fresh instances because all 13 valid inputs were already covered. There are 460 distinct task-level new inputs; their execution count is higher because each task has multiple variants.',
      '', 'Clean references were checked against all original and fresh tests before the model ran. References and evaluation inputs were never included in model requests. The model received only source code, requirements, the four original visible tests, and its own previous visible results.',
      '', 'This is a small-program synthetic suite, not a real-world bug benchmark or a correctness proof. The experiment measures the combined policy; it does not isolate the causal effect of each change.',
      '', '## Reproduce and inspect','',
      '`aicc_v2.py` implements the revised wrapper. `run_v2_comparison.py` resumes the frozen trial. `fresh_tests_v2.json` holds the evaluation fixtures. Each `large_results_v2/<case>/` contains complete prompts, raw responses, proposed sources, rejected changes, the selected final source, original held-out results, fresh results, and V1 fresh results.',
      '', 'Run `python report_v2_comparison.py` to regenerate this report. To rerun from scratch, move `large_results_v2/` aside first. Keep the policy and fixtures unchanged when comparing results.',
      '']
    (ROOT/'V2_COMPARISON.md').write_text('\n'.join(lines))
    print(json.dumps({k:v for k,v in s.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
