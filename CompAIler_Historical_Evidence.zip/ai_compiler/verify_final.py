"""Verify all final outputs, including unchanged earlier branches and the extra candidate."""
import hashlib
import json
from pathlib import Path
import tempfile
from aicc import ROOT,check
from aicc_v2 import ReviewModel
from ai_compile import finalize_last

def main():
    v3=json.loads((ROOT/'large_results_v3/summary.json').read_text());assert v3['completed']==88
    plan=json.loads((ROOT/'final_policy.json').read_text())
    assert plan['policy_sha256']==hashlib.sha256((ROOT/'ai_compile.py').read_bytes()).hexdigest()
    cases=json.loads((ROOT/'large_suite/cases.json').read_text())
    old={r['id']:r for r in v3['cases']};fresh=json.loads((ROOT/'fresh_tests_v2.json').read_text())['tasks']
    out=ROOT/'large_results_final';out.mkdir(exist_ok=True);model=None;rows=[]
    compiler=str(ROOT/'vendor/tcc-0.9.27/install/bin/tcc')
    for i,c in enumerate(cases,1):
        folder=out/c['id'];folder.mkdir(exist_ok=True);done=folder/'evaluation.json'
        if done.exists():rows.append(json.loads(done.read_text()));continue
        stage=ROOT/'large_results_v3'/c['id'];prior=json.loads((stage/'report.json').read_text())
        if not prior['passed'] and not (folder/'report.json').exists() and model is None:
            model=ReviewModel(ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
        r=finalize_last(model,stage,c['requirement'],c['visible'],compiler,folder)
        if prior['passed']:assert r['source_unchanged_from_v3'] and not r['extra_candidate_called']
        with tempfile.TemporaryDirectory(prefix='final-evaluation-') as tmp:
            h=check((folder/'repaired.c').read_text(),Path(tmp),compiler,c['hidden'])
            f=check((folder/'repaired.c').read_text(),Path(tmp),compiler,fresh[c['task']])
        (folder/'heldout.json').write_text(json.dumps(h,indent=2));(folder/'fresh.json').write_text(json.dumps(f,indent=2))
        row={'id':c['id'],'kind':c['kind'],'v1_validated':old[c['id']]['v1_validated'],
             'v2_validated':old[c['id']]['v2_validated'],'v3_validated':old[c['id']]['v3_validated'],
             'final_validated':r['passed'] and h['passed'] and f['passed'],
             'source_unchanged_from_v3':r['source_unchanged_from_v3'],
             'extra_candidate_called':r['extra_candidate_called'],'total_model_calls':r['total_model_calls'],
             'extra_seconds':r['generation']['seconds'] if r['generation'] else 0,
             'heldout_passed':sum(t['passed'] for t in h['tests']),'heldout_total':len(c['hidden']),
             'fresh_passed':sum(t['passed'] for t in f['tests']),'fresh_total':len(fresh[c['task']])}
        done.write_text(json.dumps(row,indent=2));rows.append(row)
        faulty=[x for x in rows if x['kind']=='faulty'];controls=[x for x in rows if x['kind']=='clean_control']
        s={'completed':len(rows),'faulty_cases':len(faulty),
           'original_passed':sum(x['v1_validated'] for x in faulty),
           'three_call_passed':sum(x['v2_validated'] for x in faulty),
           'four_call_passed':sum(x['v3_validated'] for x in faulty),
           'final_passed':sum(x['final_validated'] for x in faulty),
           'controls_passed':sum(x['final_validated'] for x in controls),'controls':len(controls),
           'regressions_vs_original':[x['id'] for x in rows if x['v1_validated'] and not x['final_validated']],
           'fifth_calls':[x['id'] for x in rows if x['extra_candidate_called']],
           'total_model_calls':sum(x['total_model_calls'] for x in rows),
           'extra_generation_seconds':sum(x['extra_seconds'] for x in rows),
           'heldout_passed':sum(x['heldout_passed'] for x in rows),'heldout_total':sum(x['heldout_total'] for x in rows),
           'fresh_passed':sum(x['fresh_passed'] for x in rows),'fresh_total':sum(x['fresh_total'] for x in rows),'cases':rows}
        (out/'summary.json').write_text(json.dumps(s,indent=2))
        print('VERIFIED',i,c['id'],row['final_validated'],flush=True)
    lines=['# Final compiler-layer results','',
      '| Version | Faulty variants passing all evaluations | Correct controls |','|---|---:|---:|',
      f"| Original | {s['original_passed']}/80 | 8/8 |",
      f"| Revised three-call policy | {s['three_call_passed']}/80 | 8/8 |",
      f"| One source-free rescue, max four calls | {s['four_call_passed']}/80 | 8/8 |",
      f"| Final staged policy, max five calls | {s['final_passed']}/80 | {s['controls_passed']}/8 |",
      '',f"Final outputs passed {s['heldout_passed']}/{s['heldout_total']} old held-out executions and {s['fresh_passed']}/{s['fresh_total']} fresh executions.",
      '', '## What changed','',
      'The final entry point is `ai_compile.py`. It reviews every submission, asks for a diagnosis and concrete patches, tracks progress, rejects changes breaking prior passing tests, and changes strategy when attempts stall.',
      '', 'If three calls still fail visible tests, it tries one fresh implementation using only requirements and visible examples. If that also fails, it tries one further candidate with a different seed and a simpler bounded-storage design preference. These are general conditional branches; no case IDs, reference implementations, or held-out answers enter the requests.',
      '', 'The fixed three-call experiment corrected the three original failures but introduced three different failures. The source-free call recovered GCD and linear search; its bracket implementation did not compile and was rejected. The final bounded-storage candidate is recorded separately, preserving the intermediate failure evidence and its additional call cost.',
      '',f"The fifth-call branch was used on {len(s['fifth_calls'])} case(s): {', '.join(s['fifth_calls'])}. It added {s['extra_generation_seconds']:.1f} seconds of model generation beyond the four-call policy.",
      '',f"Regressions versus original outputs: {len(s['regressions_vs_original'])}. Final total model calls across all 88 submissions: {s['total_model_calls']}.",
      '', '## Verification','',
      'All 88 outputs were compiled and checked again against the original visible examples, old held-out tests and fresh tests. Earlier passing branches were retained byte-for-byte rather than regenerated. Only branches still failing visible tests invoked an extra model call. Original and intermediate results remain intact.',
      '', 'Fresh fixtures include 460 distinct task-level inputs absent from the original suite. Factorial has no new valid inputs because its 0..12 domain was already exhausted. The number of test executions is larger because each task has multiple variants.',
      '', 'The selected final sources trace to retained outputs or raw model responses; no manual C corrections were made. `large_results_final/` contains the final programs and evaluation evidence. `V2_COMPARISON.md` and `FINAL_IMPROVEMENTS.md` show the intermediate policies and failures.',
      '', 'The maximum budget increased from three to five calls, used only as needed. These are results on deliberately mutated small C programs, not a proof of correctness or a real-world repository benchmark.',
      '']
    (ROOT/'FINAL_RESULTS.md').write_text('\n'.join(lines))
    print('FINISHED',json.dumps({k:v for k,v in s.items() if k!='cases'}),flush=True)

if __name__=='__main__':main()
