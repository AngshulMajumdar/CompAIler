"""Run/resume the expanded trial. Held-out tests and references never enter model prompts."""
import argparse
from collections import Counter,defaultdict
import json
from pathlib import Path
import shutil
import tempfile
import time
from aicc import RepairModel,check,repair_program
from build_large_suite import build,ROOT

def summarize(rows,out):
    faulty=[r for r in rows if r['kind']=='faulty']
    controls=[r for r in rows if r['kind']=='clean_control']
    categories={}
    for name in sorted({r['category'] for r in faulty}):
        group=[r for r in faulty if r['category']==name]
        categories[name]={'cases':len(group),'validated':sum(r['validated'] for r in group)}
    summary={'completed':len(rows),'faulty_cases':len(faulty),
             'validated_repairs':sum(r['validated'] for r in faulty),
             'visible_pass_hidden_fail':sum(r['visible_passed'] and not r['hidden_passed'] for r in faulty),
             'first_attempt_validated':sum(r['validated'] and r['repairs']==1 for r in faulty),
             'controls':len(controls),'controls_unchanged_and_passed':sum(r['validated'] and r['repairs']==0 for r in controls),
             'total_generation_seconds':round(sum(r.get('generation_seconds',0) for r in rows),2),
             'heldout_tests':sum(r['hidden_tests'] for r in rows),
             'heldout_passed':sum(r['hidden_pass_count'] for r in rows),
             'categories':categories,'cases':rows}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    return summary

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
    p.add_argument('--max-repairs',type=int,default=3)
    args=p.parse_args()
    cases=build()
    out=ROOT/'large_results';out.mkdir(exist_ok=True)
    compiler=str(ROOT/'vendor/tcc-0.9.27/install/bin/tcc')
    if not Path(compiler).exists():compiler=shutil.which('tcc') or shutil.which('gcc')
    pre=out/'reference_preflight.json'
    if not pre.exists():
        reference_results={}
        with tempfile.TemporaryDirectory(prefix='aicc-reference-') as temp:
            for c in cases:
                if c['task'] in reference_results:continue
                source=(ROOT/'large_suite/references'/(c['task']+'.c')).read_text()
                report=check(source,Path(temp),compiler,c['visible']+c['hidden'])
                reference_results[c['task']]={'passed':report['passed'],'tests':len(report['tests']),
                                               'diagnostics':report['diagnostics']}
                print('REFERENCE',c['task'],reference_results[c['task']],flush=True)
                if not report['passed']:
                    (out/'preflight_failure.json').write_text(json.dumps(report,indent=2))
                    raise RuntimeError('Reference/oracle disagreement: '+c['task'])
        pre.write_text(json.dumps(reference_results,indent=2))
    else:
        reference_results=json.loads(pre.read_text())
        assert all(r['passed'] for r in reference_results.values())
    model=None;rows=[]
    for index,c in enumerate(cases,1):
        folder=out/c['id'];folder.mkdir(exist_ok=True)
        done=folder/'evaluation.json'
        if done.exists():
            rows.append(json.loads(done.read_text()));continue
        print(f'CASE {index}/{len(cases)} {c["id"]}',flush=True)
        if model is None:model=RepairModel(args.model)
        (folder/'requirement.txt').write_text(c['requirement']+'\n')
        (folder/'visible_tests.json').write_text(json.dumps(c['visible'],indent=2))
        start=time.monotonic()
        reportfile=folder/'report.json'
        if reportfile.exists():report=json.loads(reportfile.read_text())
        else:
            report=repair_program(model,c['source'],c['requirement'],c['visible'],compiler,folder,args.max_repairs)
        with tempfile.TemporaryDirectory(prefix='aicc-heldout-') as temp:
            heldout=check((folder/'repaired.c').read_text(),Path(temp),compiler,c['hidden'])
        (folder/'heldout.json').write_text(json.dumps(heldout,indent=2))
        row={'id':c['id'],'task':c['task'],'kind':c['kind'],'category':c['category'],
             'initial_compiled':report['history'][0]['check']['compiled'],
             'initial_visible_passed':report['history'][0]['check']['passed'],
             'visible_passed':report['passed'],'hidden_passed':heldout['passed'],
             'validated':report['passed'] and heldout['passed'],
             'repairs':report['repairs'],
             'generation_seconds':round(sum(h.get('generation',{}).get('seconds',0) for h in report['history']),3),
             'wall_seconds':round(time.monotonic()-start,3),
             'hidden_pass_count':sum(t['passed'] for t in heldout['tests']),
             'hidden_tests':len(c['hidden']),
             'original_unchanged':(folder/'original.c').read_text()==(folder/'repaired.c').read_text()}
        done.write_text(json.dumps(row,indent=2));rows.append(row)
        s=summarize(rows,out)
        print('PROGRESS',json.dumps({k:s[k] for k in ['completed','faulty_cases','validated_repairs','visible_pass_hidden_fail','total_generation_seconds']}),flush=True)
    print('FINISHED',json.dumps({k:v for k,v in summarize(rows,out).items() if k not in ['cases']}),flush=True)

if __name__=='__main__':main()
