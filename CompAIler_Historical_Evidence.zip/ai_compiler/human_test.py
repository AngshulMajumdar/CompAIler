"""Try an already-built program through the same isolated runner."""
import argparse
from pathlib import Path
from aicc import execute

p=argparse.ArgumentParser()
p.add_argument('program',type=Path)
p.add_argument('--input',required=True,help='Literal stdin text; a newline is appended')
args=p.parse_args()
r=execute(args.program,args.input+'\n')
print(r['stdout'],end='')
if r['stderr']:print(r['stderr'])
raise SystemExit(r['returncode'] != 0)
