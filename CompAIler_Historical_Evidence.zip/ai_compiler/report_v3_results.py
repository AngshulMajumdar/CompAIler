"""Report the source-free rescue separately from the frozen three-call experiment."""
import csv
import hashlib
import json
import re
from aicc import ROOT

def main():
    out=ROOT/'large_results_v3';s=json.loads((out/'summary.json').read_text());rows=s['cases']
    v2=json.loads((ROOT/'large_results_v2/summary.json').read_text())
    assert len(rows)==88
    plan=json.loads((ROOT/'v3_frozen_plan.json').read_text())
    assert plan['aicc_v3_sha256']==hashlib.sha256((ROOT/'aicc_v3.py').read_bytes()).hexdigest()
    assert plan['evaluation_fixture_sha256']==hashlib.sha256((ROOT/'fresh_tests_v2.json').read_bytes()).hexdigest()
    for r in rows:
        folder=out/r['id'];report=json.loads((folder/'report.json').read_text())
        stage=ROOT/'large_results_v2'/r['id']
        assert report['v2_report_sha256']==hashlib.sha256((stage/'report.json').read_bytes()).hexdigest()
        if not report['rescue_called']:
            assert (folder/'repaired.c').read_bytes()==(stage/'repaired.c').read_bytes()
        else:
            assert not report['v2_visible_passed']
            generation=report['rescue']['generation'];raw=generation['raw_response']
            blocks=re.findall(r'```(?:c|C)?\s*\n(.*?)```',raw,re.S)
            candidate=blocks[0] if blocks else raw.strip()
            assert candidate==(folder/'candidate_4.c').read_text()
            assert raw==(folder/'model_reply_4.txt').read_text()
            assert generation['prompt']==(folder/'rescue_prompt.txt').read_text()
            if report['rescue']['accepted']:assert candidate==(folder/'repaired.c').read_text()
        assert report['total_model_calls']<=4
    with (out/'case_results.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    audit={'cases':88,'passing_v2_outputs_unchanged':True,'rescue_only_on_visible_failure':True,
           'max_four_model_calls':True,'all_sources_trace_to_v2_or_saved_rescue_response':True,
           'rescue_calls':s['extra_model_calls']}
    (out/'audit.json').write_text(json.dumps(audit,indent=2))
    lines=['# Final revised compiler layer','',
      '| Paired evaluation | Original V1 | Revised V2, max 3 calls | Final wrapper, max 4 calls |',
      '|---|---:|---:|---:|',
      f"| Faulty cases passing original and fresh checks | {s['v1_validated']}/80 | {s['v2_validated']}/80 | {s['v3_validated']}/80 |",
      f"| Correct controls passing all checks | 8/8 | {v2['controls_passed']}/8 | {s['controls_passed']}/8 |",
      '', f"Final outputs passed {s['heldout_passed']}/{s['heldout_total']} original held-out executions and {s['fresh_passed']}/{s['fresh_total']} fresh executions.",
      '', f"Regressions versus V1: {len(s['regressions_vs_v1'])}. Regressions versus V2: {len(s['regressions_vs_v2'])}.",
      '', '## Why there is a fourth-call option','',
      'The fixed V2 experiment corrected the three original failures but exposed a regression on a different GCD variant. Its retries repeatedly diagnosed an irrelevant excluded input while leaving the wrong output variable unchanged. That result is preserved in `V2_COMPARISON.md`; it is not hidden or counted as a V2 success.',
      '', 'The final wrapper therefore adds one generic last-resort call only when the three-call stage still fails visible tests. This request contains the behavioral requirement and visible input/output examples only. It omits the old code, previous patches and speculative diagnosis to avoid anchoring on the same mistake. The fallback has no task-name or case-ID routing.',
      '', f"The extra branch ran on {len(s['rescues_called'])} submission(s), used {s['extra_model_calls']} additional model call(s), and took {s['extra_generation_seconds']:.1f} seconds of generation in total.",
      '', '## What was rechecked','',
      'Compilation and evaluation were attempted again for all 88 outputs against their original visible tests, old held-out tests and fresh inputs. For every submission already passing V2 visible tests, the exact V2 source was retained byte-for-byte and no extra model call was made. This verification reuses that unchanged branch rather than regenerating known passing programs.',
      '', 'Fresh fixtures comprise 460 distinct task-level input instances not present in the original suite; their execution count is larger because each task has several variants. Factorial already covers its entire valid domain. References and evaluation inputs are never sent to either repair or rescue model requests.',
      '', '## Use','',
      'Use `aicc_v3.py` for the final wrapper. Its arguments match `aicc_v2.py`. The original V1 and the fixed-budget V2 implementations remain available for comparison.',
      '', 'Run `run_v3_verification.py` after `run_v2_comparison.py` to reproduce the conditional rescue verification. Read `large_results_v3/<case>/` for the selected source and all evaluation results, and the rescue prompt/response where applicable.',
      '', 'The observed results apply to these deliberately mutated small C programs. They do not establish perfect code or reliability on real repositories. The extra-call policy has a different budget from V1/V2; the table reports that distinction explicitly.',
      '']
    if s['regressions_vs_v1'] or s['regressions_vs_v2']:
        lines+=['## Remaining regressions','',json.dumps({'vs_v1':s['regressions_vs_v1'],'vs_v2':s['regressions_vs_v2']},indent=2)]
    (ROOT/'FINAL_IMPROVEMENTS.md').write_text('\n'.join(lines))
    print(json.dumps({k:v for k,v in s.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
