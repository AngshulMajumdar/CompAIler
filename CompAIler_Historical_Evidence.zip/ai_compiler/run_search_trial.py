"""Use CPU model proposal caches plus generic compiler/test-guided search."""
import hashlib
import json
from pathlib import Path
import tempfile
from aicc import ROOT,check
from search_compile import POLICY,function_pool,repair
from run_large_programs import COMPILER

OUT=ROOT/'search_results'
def summarize(rows):
    faulty=[r for r in rows if r['kind']=='faulty'];controls=[r for r in rows if r['kind']=='correct_control']
    s={'completed':len(rows),'faulty_completed':len(faulty),'faulty_validated':sum(r['validated'] for r in faulty),
       'heldout_passed':sum(r['heldout_passed'] for r in faulty),'heldout_total':sum(r['heldout_total'] for r in faulty),
       'controls':len(controls),'controls_passed':sum(r['validated'] for r in controls),'cases':rows}
    (OUT/'summary.json').write_text(json.dumps(s,indent=2));return s

def main():
    OUT.mkdir(exist_ok=True);fixture=ROOT/'large_program_suite/cases.json';cases=json.loads(fixture.read_text())['cases']
    plan={'policy':POLICY,'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
          'controller_sha256':hashlib.sha256((ROOT/'search_compile.py').read_bytes()).hexdigest(),
          'seeds':'Original input and previously generated CPU-model functions; no reference code or mutation descriptions.',
          'selection':'Four visible scenarios only; held-out scenarios checked after search returns.',
          'new_model_calls':0,'cached_prior_model_calls':86}
    p=OUT/'frozen_plan.json'
    if p.exists():assert json.loads(p.read_text())==plan
    else:p.write_text(json.dumps(plan,indent=2))
    rows=[]
    for c in cases:
        folder=OUT/c['id'];done=folder/'evaluation.json'
        if done.exists():rows.append(json.loads(done.read_text()));continue
        folder.mkdir(exist_ok=True);prior=ROOT/'function_results'/c['id']
        assert (prior/'original.c').read_text()==c['source']
        model_source=(prior/'repaired.c').read_text();model_report=json.loads((prior/'report.json').read_text())
        pool=function_pool(c['source'],model_report)
        (folder/'original.c').write_text(c['source']);(folder/'model_seed.c').write_text(model_source)
        (folder/'pool.json').write_text(json.dumps(pool,indent=2))
        print('CASE',c['id'],flush=True)
        r=repair(c['source'],model_source,pool,c['visible'],COMPILER,folder)
        with tempfile.TemporaryDirectory(prefix='search-heldout-') as tmp:
            h=check((folder/'repaired.c').read_text(),Path(tmp),COMPILER,c['heldout'])
        (folder/'heldout.json').write_text(json.dumps(h,indent=2))
        row={'id':c['id'],'kind':c['kind'],'visible_passed':sum(t['passed'] for t in r['final']['tests']),
             'heldout_passed':sum(t['passed'] for t in h['tests']),'heldout_total':len(c['heldout']),
             'validated':r['passed'] and h['passed'],'search_edits':len(r['edits']),
             'search_seconds':r['seconds'],'candidates_this_session':r['evaluated_this_session']}
        done.write_text(json.dumps(row,indent=2));rows.append(row)
        print('PROGRESS',json.dumps({k:v for k,v in summarize(rows).items() if k!='cases'}),flush=True)
    print('FINISHED',json.dumps({k:v for k,v in summarize(rows).items() if k!='cases'}),flush=True)

if __name__=='__main__':main()
