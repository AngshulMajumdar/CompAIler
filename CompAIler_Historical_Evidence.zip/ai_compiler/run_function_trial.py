"""Paired large-program trial using whole-function C generation on CPU."""
import hashlib
import json
from pathlib import Path
import tempfile
from aicc import ROOT,check
from function_compile import FunctionModel,POLICY,repair
from run_large_programs import COMPILER

OUT=ROOT/'function_results'
def summary(rows):
    faulty=[r for r in rows if r['kind']=='faulty'];controls=[r for r in rows if r['kind']=='correct_control']
    s={'completed':len(rows),'faulty_completed':len(faulty),'faulty_validated':sum(r['validated'] for r in faulty),
       'faulty_heldout_passed':sum(r['heldout_passed'] for r in faulty),'faulty_heldout_total':sum(r['heldout_total'] for r in faulty),
       'controls':len(controls),'controls_validated':sum(r['validated'] for r in controls),
       'calls':sum(r['calls'] for r in rows),'model_seconds':round(sum(r['model_seconds'] for r in rows),3),'cases':rows}
    (OUT/'summary.json').write_text(json.dumps(s,indent=2));return s

def main():
    OUT.mkdir(exist_ok=True);fixture=ROOT/'large_program_suite/cases.json';cases=json.loads(fixture.read_text())['cases']
    files=['function_compile.py','chunk_compile.py','aicc.py','run_function_trial.py']
    plan={'policy':POLICY,'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
          'code_sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files},
          'evaluation':'Same four visible and 24 held-out scenarios. No reference code, mutations or held-out feedback in model prompts.',
          'budget':'One full function pass, up to three extra rejection retries. Controls review the first function only.'}
    p=OUT/'frozen_plan.json'
    if p.exists():assert json.loads(p.read_text())==plan
    else:p.write_text(json.dumps(plan,indent=2))
    pre=OUT/'preflight.json'
    if not pre.exists():
        refs={}
        with tempfile.TemporaryDirectory() as tmp:
            for c in cases:
                if c['kind']!='faulty':continue
                src=(ROOT/'large_program_suite/references'/(c['id']+'.c')).read_text()
                r=check(src,Path(tmp),COMPILER,c['visible']+c['heldout']);assert r['passed'],c['id']
                refs[c['id']]={'passed':True,'scenarios':28}
        pre.write_text(json.dumps(refs,indent=2))
    rows=[];model=None
    for c in cases:
        folder=OUT/c['id'];done=folder/'evaluation.json'
        if done.exists():rows.append(json.loads(done.read_text()));continue
        print('CASE',c['id'],'functions',c['metadata']['functions'],flush=True)
        if model is None:model=FunctionModel(ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
        r=repair(model,c['source'],c['requirement'],c['visible'],COMPILER,folder,control=c['kind']=='correct_control')
        with tempfile.TemporaryDirectory() as tmp:held=check((folder/'repaired.c').read_text(),Path(tmp),COMPILER,c['heldout'])
        (folder/'heldout.json').write_text(json.dumps(held,indent=2));history=r['history']
        row={'id':c['id'],'kind':c['kind'],'lines':len(c['source'].splitlines()),'faults':len(c['mutations']),
             'functions':r['function_count'],'functions_reviewed':len({e['request']['name'] for e in history}),
             'visible_passed':sum(t['passed'] for t in r['final']['tests']),
             'heldout_passed':sum(t['passed'] for t in held['tests']),'heldout_total':len(c['heldout']),
             'compiled':r['final']['compiled'],'validated':r['final']['passed'] and held['passed'],
             'calls':len(history),'changed_replacements':sum(e['reason']=='accepted' for e in history),
             'compiler_rejections':sum(e['reason']=='compiler_rejected' for e in history),
             'structure_rejections':sum(e['reason']=='structure_rejected' for e in history),
             'regression_rejections':sum(e['reason']=='regression_rejected' for e in history),
             'truncated':sum(e['generation']['finish_reason']=='length' for e in history),
             'model_seconds':round(sum(e['generation']['seconds'] for e in history),3),
             'prompt_tokens':sum(e['generation']['usage']['prompt_tokens'] for e in history),
             'output_tokens':sum(e['generation']['usage']['completion_tokens'] for e in history)}
        done.write_text(json.dumps(row,indent=2));rows.append(row)
        print('PROGRESS',json.dumps({k:v for k,v in summary(rows).items() if k!='cases'}),flush=True)
    print('FINISHED',json.dumps({k:v for k,v in summary(rows).items() if k!='cases'}),flush=True)

if __name__=='__main__':main()
