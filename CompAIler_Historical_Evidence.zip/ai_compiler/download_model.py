"""Download one free GGUF model; no API credential is needed."""
import argparse
from pathlib import Path
import urllib.request

p=argparse.ArgumentParser()
p.add_argument('--size', choices=['1.5b','7b'], default='7b')
args=p.parse_args()
size=args.size
repo=f'Qwen/Qwen2.5-Coder-{size.upper()}-Instruct-GGUF'
name=f'qwen2.5-coder-{size}-instruct-q4_k_m.gguf'
target=Path(__file__).resolve().parent/'model'/name
target.parent.mkdir(exist_ok=True)
if target.exists():
    raise SystemExit(f'{target} already exists; remove it explicitly to download again.')
partial=target.with_suffix('.partial')
print('Downloading',repo,name,flush=True)
with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/main/{name}',timeout=120) as r,partial.open('wb') as f:
    while chunk:=r.read(4*1024*1024):
        f.write(chunk)
partial.replace(target)
print(target)
