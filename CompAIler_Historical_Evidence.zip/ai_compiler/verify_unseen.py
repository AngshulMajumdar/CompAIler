"""Check fixed executables on additional inputs never sent to the repair model."""
import json
import math
from pathlib import Path
import random
from aicc import execute

ROOT=Path(__file__).resolve().parent
rng=random.Random(20261123)
cases={
 'factorial':[(f'{n}\n',str(math.factorial(n))) for n in range(13) if n not in (0,1,5,10)],
 'mean':[(f'{a} {b}\n',f'{(a+b)/2:.2f}') for a,b in
         [(rng.randint(-10000,10000),rng.randint(-10000,10000)) for _ in range(30)]],
 'maximum':[],
}
for _ in range(30):
    a=[rng.randint(-10000,10000) for _ in range(rng.randint(1,100))]
    cases['maximum'].append((str(len(a))+'\n'+' '.join(map(str,a))+'\n',str(max(a))))
results={}
for name,pairs in cases.items():
    binary=ROOT/'results'/name/'program'
    checks=[]
    for stdin,want in pairs:
        if binary.exists():
            actual=execute(binary,stdin)
            passed=actual['returncode']==0 and actual['stdout'].strip()==want
        else:
            actual={'error':'No successful executable'};passed=False
        checks.append({'input':stdin,'expected':want,'actual':actual,'passed':passed})
    results[name]={'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks}
(ROOT/'results/additional_checks.json').write_text(json.dumps(results,indent=2))
print(json.dumps({k:{'passed':v['passed'],'total':v['total']} for k,v in results.items()},indent=2))
