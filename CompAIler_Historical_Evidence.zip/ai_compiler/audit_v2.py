"""Audit accepted-source provenance, regression guard, complete review and frozen policy."""
import hashlib
import json
import re
from aicc import ROOT

out=ROOT/'large_results_v2';s=json.loads((out/'summary.json').read_text())
cases={c['id']:c for c in json.loads((ROOT/'large_suite/cases.json').read_text())}
assert len(s['cases'])==len(cases)==88
plan=json.loads((out/'frozen_plan.json').read_text())
assert plan['implementation_sha256']==hashlib.sha256((ROOT/'aicc_v2.py').read_bytes()).hexdigest()
assert plan['fresh_tests_sha256']==hashlib.sha256((ROOT/'fresh_tests_v2.json').read_bytes()).hexdigest()
assert plan['cases_sha256']==hashlib.sha256((ROOT/'large_suite/cases.json').read_bytes()).hexdigest()
rejects=0;rewrites=0;calls=0;truncated=[]
for row in s['cases']:
    folder=out/row['id'];report=json.loads((folder/'report.json').read_text())
    best=cases[row['id']]['source'];passed={i for i,t in enumerate(report['baseline']['tests']) if t['passed']}
    assert (folder/'original.c').read_text()==best
    assert 1<=len(report['attempts'])<=3
    for a in report['attempts']:
        calls+=1;g=a['generation'];n=a['attempt']
        assert (folder/f'prompt_{n}.txt').read_text()==g['prompt']
        assert (folder/f'model_reply_{n}.txt').read_text()==g['raw_response']
        if g['strategy']=='rewrite':rewrites+=1
        if g['finish_reason']=='length':truncated.append(row['id'])
        if a['candidate'] is None:continue
        raw=g['raw_response'];blocks=re.findall(r'```(?:c|C)?\s*\n(.*?)```',raw,re.S)
        extracted=blocks[0] if blocks else raw.split('SOURCE:',1)[-1].strip()
        assert extracted==a['candidate']==(folder/f'candidate_{n}.c').read_text()
        newpassed={i for i,t in enumerate(a['check']['tests']) if t['passed']}
        if a['accepted']:
            assert passed.issubset(newpassed);passed=newpassed;best=a['candidate']
        elif a.get('regressed_test_indices'):rejects+=1
    assert best==(folder/'repaired.c').read_text()
result={'cases':88,'all_submissions_reviewed':True,'max_three_calls_enforced':True,
        'all_selected_sources_trace_to_raw_model_outputs_or_originals':True,
        'no_accepted_visible_test_regressions':True,'rejected_regressing_candidates':rejects,
        'fresh_implementation_attempts':rewrites,'model_calls':calls,
        'truncated_generations':truncated,'policy_and_fixtures_unchanged':True}
(out/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
