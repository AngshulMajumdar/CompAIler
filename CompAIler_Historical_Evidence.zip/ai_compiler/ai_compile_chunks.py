"""Repair a C program through adaptive chunks and full-program compiler checks."""
import argparse
import json
import subprocess
from pathlib import Path
from aicc import ROOT
from chunk_compile import ChunkModel,repair
from run_large_programs import COMPILER

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path)
    p.add_argument('--requirement-file',type=Path,required=True);p.add_argument('--tests',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--compiler',default=COMPILER)
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf');a=p.parse_args()
    report=repair(ChunkModel(a.model),a.source.read_text(),a.requirement_file.read_text(),
                  json.loads(a.tests.read_text()),a.compiler,a.output)
    if report['final']['passed']:
        subprocess.run([a.compiler,'-Wall','-Werror',str(a.output/'repaired.c'),'-o',str(a.output/'program'),'-lm'],
                       capture_output=True,text=True,timeout=20,check=True)
    print(json.dumps({'passed':report['final']['passed'],'calls':report['calls'],'source':str(a.output/'repaired.c')}))

if __name__=='__main__':main()
