"""Requirement-derived visible boundary tests and a separate fresh random audit."""
import json
import random
from aicc import ROOT
import build_large_programs as g

SEED=2026112402
def build():
    g.R=random.Random(SEED);fresh={k:v[4:] for k,v in g.fixtures().items()};stress={}
    def commands(ops,oracle,prefix=None):
        return {'input':g.command_input(ops,prefix),'output':oracle(ops) if prefix is None else oracle(prefix,ops)}
    inv=[f'ADD {i} {1000000-i}' for i in range(100)]
    inv+=['ADD 100 1','DROP 50','ADD 100 1','LIST','TOTAL']
    lifetime=['ADD 1 1000000']
    for _ in range(20):lifetime+=['RECEIVE 1 1000000','SELL 1 1000000','DROP 1','ADD 1 1000000','TOTAL']
    stress['inventory']=[commands(inv,g.inventory_oracle),commands(lifetime,g.inventory_oracle)]
    grades=[f'ADD {i} {i%101} {(100-i)%101} {(3*i)%101}' for i in range(100)]
    grades += ['RANK','SUMMARY']+[f'DROP {i}' for i in range(0,100,2)]+['RANK','SUMMARY']
    weights=['ADD 1 100 0 0','ADD 2 0 100 0','ADD 3 0 0 100','ADD 4 50 50 50','RANK','SUMMARY',
             'UPDATE 1 0 0','UPDATE 1 2 100','UPDATE 2 1 0','UPDATE 2 0 100','RANK','SUMMARY']
    stress['gradebook']=[commands(grades,g.grade_oracle),commands(weights,g.grade_oracle)]
    stress['lru_cache']=[]
    for capacity in [1,20]:
        ops=[f'PUT {i} {i*7-5}' for i in range(180)]
        ops+=['KEYS','SIZE','GET 0','GET 179','KEYS','CLEAR','KEYS','SIZE']
        stress['lru_cache'].append(commands(ops,g.lru_oracle,capacity))
    n=32;edges=[(i,i+1,0) for i in range(n-1)]
    ops=[f'ALL {i}' for i in range(n)]+[f'REACH {i}' for i in range(n)]+['BFS 0 31','DIST 31 0','ROUND 0','EDGE 0 1 1000000','ALL 0','RESET','ALL 0']
    stress['graph_engine']=[{'input':f'{n} {len(edges)} {len(ops)}\n'+''.join(f'{a} {b} {w}\n' for a,b,w in edges)+'\n'.join(ops)+'\n',
                             'output':g.graph_oracle(n,edges,ops)}]
    n=32;edges=[(i,i+1,1000000) for i in range(n-1)];ops=['ALL 0','ROUND 0','BFS 0 31','REACH 31','DIST 0 31','DIST 31 0','EDGE 0 31 0','ALL 0','ROUND 0']
    stress['graph_engine'].append({'input':f'{n} {len(edges)} {len(ops)}\n'+''.join(f'{a} {b} {w}\n' for a,b,w in edges)+'\n'.join(ops)+'\n','output':g.graph_oracle(n,edges,ops)})
    expressions=['2147483647','-2147483647','2147483647-2147483647','1000000000*2','-1000000000*2','1'+'+0'*99,
                 '---5','2*-(-3)','7/-3','-7/3','-7/-3','8-3-2','36/3/2','0/0','1/(3-3)','()','2**3','2//3','1 2','']
    expressions=(expressions*2)[:40]
    stress['expression_parser']=[{'input':str(len(expressions))+'\n'+'\n'.join(expressions)+'\n','output':g.expression_oracle(expressions)},
                                  {'input':'0\n','output':''}]
    a=[(i,j,100000) for i in range(8) for j in range(8)]+[(i%8,(i*3)%8,100000) for i in range(36)]
    b=[(i,j,-100000) for i in range(8) for j in range(8)]+[(i%8,(i*5)%8,100000) for i in range(36)]
    operations=[('MUL',(8,8,8),a,b),('ADD',(8,8),a,b),('TRANS',(8,8),a,[])]
    cancellation=[('ADD',(1,1),[(0,0,100000)]*100,[(0,0,-100000)]*100),
                  ('MUL',(8,8,8),[(0,0,1),(0,0,-1)],[(0,0,100000)]),('TRANS',(8,8),[],[])]
    stress['sparse_matrix']=[dict(zip(['input','output'],g.sparse_oracle(operations))),dict(zip(['input','output'],g.sparse_oracle(cancellation)))]
    result={'seed':SEED,'stress_role':'Additional visible tests derived from requirements; may guide repair.',
            'fresh_role':'24 independently seeded scenarios per application; evaluation only.',
            'stress':stress,'fresh':fresh}
    path=ROOT/'quality_checks.json'
    if path.exists():assert json.loads(path.read_text())==result
    else:path.write_text(json.dumps(result,indent=2))
    print({k:{'stress':len(stress[k]),'fresh':len(fresh[k])} for k in stress})
    return result

if __name__=='__main__':build()
