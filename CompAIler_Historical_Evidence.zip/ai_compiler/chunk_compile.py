"""Adaptive function chunks, constrained edits, compiler gates and visible regression checks."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import tempfile
import time
from aicc import check

POLICY={'version':3,'chunk_characters':1500,'expanded_characters':2800,
        'passes':2,'maximum_calls':8,'context_tokens':8192,'output_tokens':1000,
        'threads':4,'seed':72,'temperature':0,
        'accept_neutral_compiling_edits':True,'preserve_whole_passing_scenarios':True,'line_matches_are_feedback_only':True,
        'unique_token_match_fallback':True}
SCHEMA={'type':'object','properties':{'edits':{'type':'array','items':{'type':'object',
    'properties':{'old':{'type':'string'},'new':{'type':'string'}},
    'required':['old','new'],'additionalProperties':False}}},'required':['edits'],'additionalProperties':False}

def masked(source):
    pattern=r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    return re.sub(pattern,lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()),source)

def functions(source):
    """Tolerant lexical boundaries; strings/comments cannot create fake braces."""
    clean=masked(source);depth=0;opening=None;result=[]
    for i,char in enumerate(clean):
        if char=='{':
            if depth==0:opening=i
            depth+=1
        elif char=='}':
            depth-=1
            if depth<0:raise ValueError('Unbalanced closing brace')
            if depth==0:
                prefix=clean[:opening]
                m=re.search(r'(?m)^[ \t]*[\w* \t]+?\b([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\Z',prefix)
                if m:
                    start=m.start();signature=source[start:opening].strip()
                    result.append({'name':m.group(1),'start':start,'body':opening,'end':i+1,
                                   'signature':signature,'text':source[start:i+1]})
    if depth:raise ValueError('Unbalanced braces: structural recovery required')
    if not result:raise ValueError('No C functions located')
    return result

def topology(source):
    fs=functions(source);names={f['name'] for f in fs}
    for f in fs:
        f['calls']=sorted((set(re.findall(r'\b([A-Za-z_]\w*)\s*\(',masked(source[f['body']+1:f['end']-1])))&names)-{f['name']})
    return fs

def groups(source,expanded=False):
    fs=topology(source);by={f['name']:f for f in fs};pending=[f['name'] for f in fs];out=[]
    limit=POLICY['expanded_characters'] if expanded else POLICY['chunk_characters']
    while pending:
        names=[pending.pop(0)];size=len(by[names[0]]['text'])
        while pending:
            linked=[n for n in pending if any(n in by[a]['calls'] or a in by[n]['calls'] for a in names)]
            choices=linked+pending
            nxt=next((n for n in choices if size+len(by[n]['text'])<=limit),None)
            if nxt is None:break
            pending.remove(nxt);names.append(nxt);size+=len(by[nxt]['text'])
        out.append(names)
    return out

def context(source,names):
    fs=topology(source);parts=[];last=0
    for f in fs:
        parts.append(source[last:f['start']]);last=f['end']
    parts.append(source[last:])
    declarations=''.join(parts)
    interfaces='\n'.join(f['signature']+'; /* calls: '+','.join(f['calls'])+' */' for f in fs if f['name'] not in names)
    chunk='\n\n'.join(f['text'] for f in fs if f['name'] in names)
    return declarations,interfaces,chunk

def c_tokens(text):
    pattern=r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\d+(?:\.\d+)?|>>=|<<=|->|\+\+|--|<=|>=|==|!=|&&|\|\||[+*/%&|^<>=!-]=|<<|>>|[^\s]'
    return [(m.group(),m.start(),m.end()) for m in re.finditer(pattern,text)
            if not m.group().startswith(('/*','//'))]

def apply_edits(source,names,edits):
    """Exact edits must live within one assigned function, preserving every interface."""
    original=functions(source);allowed=set(names);changed=source
    for edit in edits:
        old,new=edit['old'],edit['new']
        if not old or old==new:raise ValueError('Empty or ineffective edit')
        fs=functions(changed)
        matches=[]
        for f in fs:
            if f['name'] in allowed:
                for m in re.finditer(re.escape(old),changed[f['body']+1:f['end']-1]):
                    matches.append((f['body']+1+m.start(),f['body']+1+m.end()))
        if not matches:
            wanted=[t[0] for t in c_tokens(old)]
            if not wanted:raise ValueError('Empty token fragment')
            for f in fs:
                if f['name'] not in allowed:continue
                tokens=c_tokens(changed[f['body']+1:f['end']-1]);values=[t[0] for t in tokens]
                for i in range(len(values)-len(wanted)+1):
                    if values[i:i+len(wanted)]==wanted:
                        matches.append((f['body']+1+tokens[i][1],f['body']+1+tokens[i+len(wanted)-1][2]))
        if len(matches)!=1:raise ValueError('Old fragment must match uniquely in assigned function bodies')
        start,end=matches[0];changed=changed[:start]+new+changed[end:]
    after=functions(changed)
    if [(f['name'],f['signature']) for f in original]!=[(f['name'],f['signature']) for f in after]:
        raise ValueError('Function interface changed')
    for before,now in zip(original,after):
        if before['name'] not in allowed and before['text']!=now['text']:raise ValueError('Edit escaped chunk')
    return changed

def observations(report):
    matched=set();whole=set()
    for i,t in enumerate(report['tests']):
        if t['passed']:whole.add(i)
        if t['returncode']!=0:continue
        expected=t['expected'].strip().splitlines();actual=t['stdout'].strip().splitlines()
        for block in difflib.SequenceMatcher(None,expected,actual,autojunk=False).get_matching_blocks():
            matched.update((i,j) for j in range(block.a,block.a+block.size))
    return matched,whole

def accept(before,after):
    if not after['compiled']:return False,'compiler_rejected'
    old,whole=observations(before);new,now=observations(after)
    if not whole.issubset(now):return False,'visible_regression'
    return True,'improved' if len(new)>len(old) or not before['compiled'] else 'neutral'

class ChunkModel:
    def __init__(self,path):
        from llama_cpp import Llama,LlamaGrammar
        self.llm=Llama(model_path=str(path),n_ctx=POLICY['context_tokens'],n_threads=4,
                       n_threads_batch=4,n_batch=256,n_gpu_layers=0,seed=POLICY['seed'],verbose=False)
        self.grammar=LlamaGrammar.from_json_schema(json.dumps(SCHEMA),verbose=False)
    def propose(self,prompt,number):
        self.llm.set_seed(POLICY['seed']+number);start=time.monotonic()
        print('MODEL_BEGIN',number,'prompt_chars',len(prompt),flush=True)
        r=self.llm.create_chat_completion(messages=[{'role':'system','content':
            'You repair C function bodies. Return only JSON edits using exact old and new source fragments. Audit every assigned function.'},
            {'role':'user','content':prompt}],temperature=0,max_tokens=POLICY['output_tokens'],grammar=self.grammar)
        raw=r['choices'][0]['message']['content'];g={'raw':raw,'usage':r.get('usage'),
              'seconds':round(time.monotonic()-start,3),'finish_reason':r['choices'][0]['finish_reason']}
        print('MODEL_END',number,g['seconds'],g['usage'],flush=True)
        return g

def prompt_for(source,names,requirement,report,previous):
    decl,interfaces,chunk=context(source,names)
    failures=[{'input':t['input'][:650],'expected':t['expected'][:500],
               'actual':t['stdout'][:500],'exit':t['returncode']} for t in report['tests'] if not t['passed']][:2]
    return ('Repair ALL incorrect logic within the assigned functions, including boundary cases. '
        'Other functions may also contain bugs; change only the assigned function bodies. '
        'Keep interfaces, input/output protocol and algorithms. Use short exact uniquely matching old fragments. '
        'Return {"edits":[{"old":"exact fragment","new":"replacement"}]}. '
        'Use an empty edits array only if every assigned function is correct. No explanations.\n'
        +'Complete behavioral requirement:\n'+requirement+'\nShared declarations:\n'+decl
        +'\nOther interfaces and call relationships:\n'+interfaces
        +'\nASSIGNED FUNCTIONS:\n'+chunk+'\nCompiler diagnostics:\n'+re.sub(r'/tmp/aicc-chunk-[^/]+/candidate\.c','candidate.c',report['diagnostics'][-1600:])
        +'\nVisible failing integration examples:\n'+json.dumps(failures)
        +'\nPrevious edit outcome:\n'+json.dumps(previous)[-900:])

def repair(model,source,requirement,tests,compiler,output):
    output.mkdir(parents=True,exist_ok=True);original=source;history=[];previous={}
    with tempfile.TemporaryDirectory(prefix='aicc-chunk-') as tmp:
        work=Path(tmp);best=check(source,work,compiler,tests);baseline=best
        for turn in range(POLICY['passes']):
            plan=groups(source,expanded=bool(turn))
            if not best['compiled']:
                lines=re.findall(r'candidate.c:(\d+)',best['diagnostics'])
                if lines:
                    pos=sum(len(l) for l in source.splitlines(True)[:int(lines[0])-1])
                    culprit=next((f['name'] for f in functions(source) if f['start']<=pos<f['end']),None)
                    plan.sort(key=lambda names:culprit not in names)
            for names in plan:
                if len(history)>=POLICY['maximum_calls']:break
                number=len(history)+1;record_path=output/f'call_{number:02d}.json'
                prompt=prompt_for(source,names,requirement,best,previous)
                request={'pass':turn+1,'names':names,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'prompt':prompt}
                if record_path.exists():
                    entry=json.loads(record_path.read_text());assert entry['request']==request
                    generation=entry['generation']
                else:
                    generation=model.propose(prompt,number)
                    record_path.write_text(json.dumps({'request':request,'generation':generation},indent=2))
                entry={'request':request,'generation':generation};candidate=None
                try:
                    if generation['finish_reason']=='length':raise ValueError('Truncated JSON response')
                    edits=json.loads(generation['raw'])['edits'];entry['edits']=edits
                    candidate=apply_edits(source,names,edits)
                    if not edits:entry.update(accepted=False,reason='unchanged',check=None)
                    else:
                        result=check(candidate,work,compiler,tests);accepted,reason=accept(best,result)
                        entry.update(accepted=accepted,reason=reason,check=result,candidate=candidate)
                        if accepted:source=candidate;best=result
                except (ValueError,KeyError,TypeError) as e:
                    entry.update(accepted=False,reason='edit_guard_rejected',error=str(e),check=None)
                history.append(entry);previous={k:entry[k] for k in ['reason','error'] if k in entry}
                record_path.write_text(json.dumps(entry,indent=2));(output/'current.c').write_text(source)
                print('CHUNK',number,names,entry['reason'],'visible',sum(t['passed'] for t in best['tests']),
                      'matched_lines',len(observations(best)[0]),flush=True)
                if best['passed']:break
            if best['passed'] or len(history)>=POLICY['maximum_calls']:break
        final=check(source,work,compiler,tests)
    (output/'original.c').write_text(original);(output/'repaired.c').write_text(source)
    report={'policy':POLICY,'baseline':baseline,'final':final,'calls':len(history),'history':history}
    (output/'report.json').write_text(json.dumps(report,indent=2));return report
