"""Report only measured chunk-repair results, including failures and budget differences."""
import hashlib
import json
from aicc import ROOT
from chunk_compile import POLICY,apply_edits,accept

def main():
    out=ROOT/'chunk_results';summary_path=out/'summary.json'
    s=json.loads(summary_path.read_text()) if summary_path.exists() else {'cases':[],'completed':0}
    plan=json.loads((out/'frozen_plan.json').read_text())
    assert plan['controller_sha256']==hashlib.sha256((ROOT/'chunk_compile.py').read_bytes()).hexdigest()
    assert plan['fixture_sha256']==hashlib.sha256((ROOT/'large_program_suite/cases.json').read_bytes()).hexdigest()
    cases=json.loads((ROOT/'large_program_suite/cases.json').read_text())['cases']
    indexed={r['id']:r for r in s['cases']};calls=0;all_audited=True
    lines=['# Adaptive chunks with compiler guardrails','',
      'Same Qwen2.5-Coder-7B-Instruct Q4_K_M model, CPU only, same C inputs, behavioral requirements and test fixtures as the whole-file trial. Six faulty applications contain 43 simultaneous faults in total; two controls contain none.',
      '',f"Completed: {s['completed']}/8.",'',
      '| Program | Lines | Faults | Visible scenarios | Held-out scenarios | Calls | Accepted edits | Model time |',
      '|---|---:|---:|---:|---:|---:|---:|---:|']
    for c in cases:
        r=indexed.get(c['id'])
        if not r:
            lines.append(f"| {c['id']} | {len(c['source'].splitlines())} | {len(c['mutations'])} | Pending | — | — | — | — |")
            continue
        lines.append(f"| {r['id']} | {r['lines']} | {r['faults']} | {r['visible_passed']}/4 | {r['heldout_passed']}/24 | {r['calls']} | {r['accepted_edits']} | {r['model_seconds']/60:.1f} min |")
        folder=out/c['id'];report=json.loads((folder/'report.json').read_text());source=c['source'];best=report['baseline']
        for i,entry in enumerate(report['history'],1):
            calls+=1;assert entry==json.loads((folder/f'call_{i:02d}.json').read_text())
            assert entry['request']['source_sha256']==hashlib.sha256(source.encode()).hexdigest()
            if entry['accepted']:
                proposed=apply_edits(source,entry['request']['names'],json.loads(entry['generation']['raw'])['edits'])
                assert proposed==entry['candidate']
                assert accept(best,entry['check'])[0]
                source=proposed;best=entry['check']
        assert source==(folder/'repaired.c').read_text()
        held=json.loads((folder/'heldout.json').read_text())
        assert r['validated']==(report['final']['passed'] and held['passed'])
    if s['cases']:
        lines+=['',f"Faulty applications passing every visible and held-out scenario: **{s['faulty_validated']}/{s['faulty_complete']}**.",
         '',f"Faulty-input held-out scenarios passed: **{s['faulty_heldout_passed']}/{s['faulty_heldout_total']}**. Clean controls passing all scenarios: **{s['controls_validated']}/{s['controls']}**."]
    if s['completed']==8:
        lines+=['', '## Interpretation', '',
          'The chunked pipeline did not improve repair reliability in this trial: no faulty application passed all checks, and none of its held-out scenarios passed. Both clean controls were preserved. All selected sources compiled.', '',
          'Across the final run, 34 proposals produced 19 accepted edits. Eight proposals failed edit-confinement or fragment checks; no applied candidate was rejected by the compiler. Most remaining proposals declared no changes. The separate guard tests deliberately supplied malformed C and verified compiler rejection.', '',
          'These outcomes do not isolate chunking from prompt design, fragment-edit generation, dependency context, acceptance policy or model capability. A useful next comparison would replace complete individual function bodies, avoiding fragile fragment edits, while keeping the same tests and a matched token budget. This is an untested next step, not a claimed improvement.']
    lines+=['','## What changed','',
       'A tolerant lexical scanner identifies function boundaries while masking strings and comments. A call graph groups connected functions into approximately 1,500-character source chunks. Shared types, globals and other function signatures accompany each chunk. This is not a full C parser: unbalanced top-level braces require structural recovery that this version does not implement.',
       '', 'On a second pass, unresolved programs use larger dependency groups, up to approximately 2,800 source characters. A single oversized function stays intact. Compiler diagnostic locations prioritize a chunk when the input does not compile. The model can emit only JSON fragment edits to assigned function bodies (exact match first, uniquely matching C tokens as a whitespace-tolerant fallback); names and interfaces remain fixed.',
       '', 'Every nonempty, structurally valid edit is reassembled into the full C program and compiled with TinyCC using -Wall -Werror before execution. Malformed C is rejected. Passing whole scenarios must be preserved. Matching-line counts are diagnostic feedback only; they cannot reject a repair because fixing an earlier state error can change later outputs. Neutral compiling changes are allowed to accumulate fixes that whole-scenario scoring previously discarded.',
       '', 'The line score uses ordered exact-line matches for logging, not newly authored unit tests. It does not prove individual function correctness and is not used to select accepted repairs.',
       '', 'Generation is grammar-constrained JSON, at most 1,000 output tokens, with an 8,192-token context. There are at most two passes and eight calls per application. The previous whole-file policy allowed five calls. This is a test of the combined new pipeline, not a controlled demonstration that chunking alone causes any improvement.',
       '', 'Clean references, mutation descriptions and the 24 held-out scenarios are never passed into the repair function or model. No held-out failures trigger further repairs. Source code is changed only by recorded model edits. Compiler guardrails enforce compilability; observed test behavior is checked separately.',
       '', 'An early setup run exposed an overlapping-boundary scanner bug and was stopped before a completed proposal. That code and log are retained in chunk_setup_attempt_1. A second setup run revealed that preserving individually matching output lines could reject a correct lookup-bound correction: earlier state repairs change subsequent outputs. Before held-out evaluation, that gate was removed; only previously passing complete scenarios constrain acceptance. Its prompts, replies and original controller remain in chunk_setup_attempt_2. A third development run exposed indentation changes in copied model fragments; unique C-token matching was added without relaxing chunk boundaries or changing string literals. That run remains in chunk_setup_attempt_3. Inventory had completed there; this format correction was motivated by the visible gradebook reply, not inventory held-out performance. Seven completed responses were reused only where the entire prompt (apart from normalized temporary compiler paths) and source hash matched. Development attempts are retained separately; this is an engineering trial on known tasks, not a pristine unseen benchmark. The final run freezes the corrected controller.',
       '', 'An execution-environment restart interrupted matrix call two. Its completed first proposal was replayed, then the remaining calls resumed serially. The record is in chunk_results/environment_restart.json; incomplete generation time is excluded from completed-call totals.', '', '## Files and reproduction','',
       'Run `python test_chunk_guards.py`, then `PYTHONPATH=../deps python run_chunk_trial.py` from the ai_compiler directory with the model/runtime installed. With the normal setup environment, use `.venv/bin/python` instead. Completed model replies are checkpointed and replayed on resume.',
       '', '`chunk_results/frozen_plan.json` freezes the controller and fixture hashes. Each case directory contains original and selected source, each complete prompt/reply, accepted/rejected edits, compiler/visible-test history and held-out results. `chunk_guard_checks.json` records implementation checks.',
       '']
    (ROOT/'CHUNK_TRIAL_RESULTS.md').write_text('\n'.join(lines))
    audit={'completed_cases':s['completed'],'completed_model_calls':calls,'selected_sources_reconstructed_from_model_edits':True,
           'accepted_edits_confined_to_assigned_functions':True,'accepted_edits_compile_and_preserve_passing_scenarios':True,
           'frozen_controller_and_fixture_hashes_match':True,'all_eight_cases_complete':s['completed']==8}
    (out/'audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps({k:v for k,v in s.items() if k!='cases'}))

if __name__=='__main__':main()
