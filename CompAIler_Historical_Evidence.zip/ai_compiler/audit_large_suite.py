"""Check retained evidence for completeness and source integrity; does not rerun repairs."""
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parent
cases=json.loads((ROOT/'large_suite/cases.json').read_text())
summary=json.loads((ROOT/'large_results/summary.json').read_text())
assert len(summary['cases'])==len(cases)==88
assert len({c['id'] for c in cases})==88
assert summary['faulty_cases']==80 and summary['controls']==8
generations=0;truncations=[];initial_passes=[]
for c in cases:
    visible={t['input'] for t in c['visible']}
    assert not visible.intersection(t['input'] for t in c['hidden'])
    folder=ROOT/'large_results'/c['id']
    report=json.loads((folder/'report.json').read_text())
    assert (folder/'original.c').read_text()==c['source']
    assert (folder/'repaired.c').read_text()==report['history'][-1]['source']
    assert report['history'][0]['source']==c['source']
    for i,h in enumerate(report['history'][:-1]):
        raw=h['generation']['raw_response']
        assert raw==(folder/f'model_reply_{i+1}.txt').read_text()
        blocks=re.findall(r'```(?:c|C)?\s*\n(.*?)```',raw,re.S)
        generated=blocks[0] if blocks else raw.strip()
        assert generated==report['history'][i+1]['source']
        generations+=1
        if h['generation']['finish_reason']=='length':truncations.append(c['id'])
    assert len(report['history'])-1==report['repairs']
    if c['kind']=='clean_control':
        assert report['repairs']==0 and report['passed']
    elif report['history'][0]['check']['passed']:initial_passes.append(c['id'])
audit={'cases':len(cases),'faulty':80,'correct_controls':8,
       'visible_heldout_inputs_disjoint_per_case':True,
       'every_model_generated_source_matches_saved_raw_response':True,
       'no_manual_edits_to_final_sources':True,
       'all_original_sources_match_fixed_suite':True,
       'model_generations':generations,'truncated_generations':truncations,
       'faulty_cases_not_triggering_model':initial_passes}
(ROOT/'large_results/audit.json').write_text(json.dumps(audit,indent=2))
print(json.dumps(audit,indent=2))
