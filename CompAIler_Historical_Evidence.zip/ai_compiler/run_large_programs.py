"""Preflight real multi-function C tasks, verify mutations, and run the frozen final pipeline."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
from aicc import ROOT,check,execute
from aicc_v2 import repair_program_v2
from aicc_v3 import finalize_v3
from ai_compile import finalize_last
from large_program_runtime import LargeProgramModel,CONFIG

SUITE=ROOT/'large_program_suite';OUT=ROOT/'large_program_results'
LOCAL_COMPILER=ROOT/'vendor/tcc-0.9.27/install/bin/tcc'
COMPILER=str(LOCAL_COMPILER) if LOCAL_COMPILER.exists() else (shutil.which('tcc') or shutil.which('gcc'))

def first_failure(source,tests,work):
    p=work/'single.c';p.write_text(source);binary=work/'single'
    r=subprocess.run([COMPILER,'-Wall','-Werror',str(p),'-o',str(binary),'-lm'],capture_output=True,text=True,timeout=20)
    if r.returncode:return {'detected':True,'type':'compile','diagnostics':r.stderr}
    for i,t in enumerate(tests):
        a=execute(binary,t['input'])
        if a['returncode'] or a['stdout'].strip()!=t['output'].strip():
            return {'detected':True,'type':'execution','test_index':i,'exit':a['returncode']}
    return {'detected':False}

def preflight(cases):
    p=OUT/'preflight.json'
    if p.exists():
        previous=json.loads(p.read_text());assert previous['passed'];return
    result={'references':{},'single_mutations':{},'passed':False}
    with tempfile.TemporaryDirectory(prefix='large-preflight-') as tmp:
        work=Path(tmp)
        for c in cases:
            if c['kind']!='faulty':continue
            task=c['id'];source=(SUITE/'references'/(task+'.c')).read_text();tests=c['visible']+c['heldout']
            r=check(source,work,COMPILER,tests)
            result['references'][task]={'passed':r['passed'],'test_count':len(tests)}
            print('REFERENCE',task,result['references'][task],flush=True)
            if not r['passed']:
                (OUT/'preflight_failure.json').write_text(json.dumps(r,indent=2));raise RuntimeError('Reference/oracle disagreement: '+task)
            result['single_mutations'][task]={}
            for mutation in c['mutations']:
                single=source.replace(mutation['old'],mutation['new'],1)
                detection=first_failure(single,tests,work)
                result['single_mutations'][task][mutation['name']]=detection
                print('MUTATION',task,mutation['name'],detection['detected'],flush=True)
                if not detection['detected']:
                    (OUT/'preflight_failure.json').write_text(json.dumps(result,indent=2));raise RuntimeError('Ineffective mutation or test blind spot: '+task+'/'+mutation['name'])
    result['passed']=True;p.write_text(json.dumps(result,indent=2))

def summary(rows):
    faulty=[r for r in rows if r['kind']=='faulty'];controls=[r for r in rows if r['kind']=='correct_control']
    s={'completed':len(rows),'faulty_programs':len(faulty),'fully_validated':sum(r['validated'] for r in faulty),
       'controls_passed':sum(r['validated'] for r in controls),'controls':len(controls),
       'heldout_passed':sum(r['heldout_passed_count'] for r in rows),'heldout_total':sum(r['heldout_count'] for r in rows),
       'model_calls':sum(r['model_calls'] for r in rows),'generation_seconds':sum(r['generation_seconds'] for r in rows),
       'cases':rows}
    (OUT/'summary.json').write_text(json.dumps(s,indent=2));return s

def main():
    OUT.mkdir(exist_ok=True);cases=json.loads((SUITE/'cases.json').read_text())['cases']
    preflight(cases)
    files=['aicc.py','aicc_v2.py','aicc_v3.py','ai_compile.py','large_program_runtime.py']
    plan={'config':CONFIG,'cases_sha256':hashlib.sha256((SUITE/'cases.json').read_bytes()).hexdigest(),
          'code_sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files},
          'evaluation':'4 visible scenarios and 24 held-out scenarios per program; no references or held-out data in model prompts'}
    pp=OUT/'frozen_plan.json'
    if pp.exists():assert json.loads(pp.read_text())==plan
    else:pp.write_text(json.dumps(plan,indent=2))
    model=None;rows=[]
    for i,c in enumerate(cases,1):
        folder=OUT/c['id'];folder.mkdir(exist_ok=True);done=folder/'evaluation.json'
        if done.exists():rows.append(json.loads(done.read_text()));continue
        if model is None:model=LargeProgramModel(ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf',OUT/'engine_calls.jsonl')
        print('CASE',i,len(cases),c['id'],c['metadata'],flush=True);start=time.monotonic()
        (folder/'requirement.txt').write_text(c['requirement'])
        (folder/'visible_tests.json').write_text(json.dumps(c['visible'],indent=2))
        stage2=folder/'v2_stage';stage3=folder/'v3_stage'
        if not (stage2/'report.json').exists():repair_program_v2(model,c['source'],c['requirement'],c['visible'],COMPILER,stage2)
        r2=json.loads((stage2/'report.json').read_text())
        if not (stage3/'report.json').exists():finalize_v3(model,stage2,c['requirement'],c['visible'],COMPILER,stage3)
        r3=json.loads((stage3/'report.json').read_text())
        final=finalize_last(model,stage3,c['requirement'],c['visible'],COMPILER,folder)
        with tempfile.TemporaryDirectory(prefix='large-heldout-') as tmp:
            h=check((folder/'repaired.c').read_text(),Path(tmp),COMPILER,c['heldout'])
        (folder/'heldout.json').write_text(json.dumps(h,indent=2))
        calls=[a['generation'] for a in r2['attempts']]
        if r3['rescue']:calls.append(r3['rescue']['generation'])
        if final['generation']:calls.append(final['generation'])
        row={'id':c['id'],'kind':c['kind'],'input_lines':len(c['source'].splitlines()),
             'input_nonblank_lines':sum(bool(l.strip()) for l in c['source'].splitlines()),
             'functions':c['metadata']['functions'],'injected_faults':len(c['mutations']),
             'output_lines':len((folder/'repaired.c').read_text().splitlines()),
             'initial_compiled':r2['baseline']['compiled'],
             'initial_visible_passed':sum(t['passed'] for t in r2['baseline']['tests']),
             'visible_passed':final['passed'],'heldout_passed':h['passed'],
             'validated':final['passed'] and h['passed'],
             'heldout_passed_count':sum(t['passed'] for t in h['tests']),'heldout_count':len(c['heldout']),
             'model_calls':len(calls),'generation_seconds':round(sum(a['seconds'] for a in calls),3),
             'truncated_generations':sum(a['finish_reason']=='length' for a in calls),
             'wall_seconds':round(time.monotonic()-start,3)}
        done.write_text(json.dumps(row,indent=2));rows.append(row)
        s=summary(rows);print('PROGRESS',json.dumps({k:v for k,v in s.items() if k!='cases'}),flush=True)
    print('FINISHED',json.dumps({k:v for k,v in summary(rows).items() if k!='cases'}),flush=True)

if __name__=='__main__':main()
