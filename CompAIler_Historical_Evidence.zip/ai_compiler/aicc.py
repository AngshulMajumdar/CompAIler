#!/usr/bin/env python3
"""Local-model source repair, compilation, and input/output feedback for small C programs."""
import argparse
import ctypes
import ctypes.util
import errno
import json
import os
from pathlib import Path
import re
import resource
import shutil
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parent


def limits():
    resource.setrlimit(resource.RLIMIT_CPU, (3, 3))
    resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1024 * 1024, 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def network_filter(fd):
    lib = ctypes.CDLL(ctypes.util.find_library('seccomp') or 'libseccomp.so.2')
    lib.seccomp_init.argtypes = [ctypes.c_uint32]
    lib.seccomp_init.restype = ctypes.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    lib.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    lib.seccomp_export_bpf.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.seccomp_release.argtypes = [ctypes.c_void_p]
    ctx = lib.seccomp_init(0x7fff0000)  # default ALLOW
    if not ctx:
        raise RuntimeError('Cannot initialize network filter')
    try:
        for name in ('socket', 'socketpair', 'connect', 'bind', 'listen', 'accept', 'accept4',
                     'ptrace', 'mount', 'umount2', 'bpf', 'io_uring_setup'):
            num = lib.seccomp_syscall_resolve_name(name.encode())
            if num >= 0 and lib.seccomp_rule_add(ctx, 0x00050000 | errno.EPERM, num, 0):
                raise RuntimeError('Cannot configure network filter')
        if lib.seccomp_export_bpf(ctx, fd):
            raise RuntimeError('Cannot export network filter')
    finally:
        lib.seccomp_release(ctx)
    os.lseek(fd, 0, os.SEEK_SET)


def execute(binary, stdin):
    """Fail closed unless bubblewrap and seccomp isolation are available."""
    if not shutil.which('bwrap'):
        raise RuntimeError('bubblewrap is required to execute generated programs')
    with tempfile.TemporaryFile() as filt, tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        network_filter(filt.fileno())
        cmd = ['bwrap', '--die-with-parent', '--new-session', '--unshare-user', '--unshare-pid',
               '--unshare-ipc', '--unshare-uts', '--clearenv', '--setenv', 'PATH', '/usr/bin',
               '--ro-bind', '/usr', '/usr', '--ro-bind', '/lib', '/lib',
               '--ro-bind', '/lib64', '/lib64', '--proc', '/proc', '--dev', '/dev',
               '--tmpfs', '/tmp', '--ro-bind', str(binary.resolve()), '/program',
               '--chdir', '/tmp', '--seccomp', str(filt.fileno()), '/program']
        try:
            result = subprocess.run(cmd, input=stdin, text=True, stdout=out, stderr=err,
                                    pass_fds=(filt.fileno(),), timeout=5, preexec_fn=limits)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = -999
        out.seek(0); err.seek(0)
        return {'returncode': code, 'stdout': out.read(65536).decode(errors='replace'),
                'stderr': err.read(65536).decode(errors='replace')}


def check(source, work, compiler, tests):
    path = work / 'candidate.c'
    binary = work / 'program'
    path.write_text(source)
    built = subprocess.run([compiler, '-Wall', '-Werror', str(path), '-o', str(binary), '-lm'],
                           capture_output=True, text=True, timeout=20)
    report = {'compiled': built.returncode == 0, 'diagnostics': (built.stdout + built.stderr)[-6000:],
              'tests': []}
    if not report['compiled']:
        report['passed'] = False
        return report
    for case in tests:
        actual = execute(binary, case['input'])
        actual.update(input=case['input'], expected=case['output'],
                      passed=actual['returncode'] == 0 and actual['stdout'].strip() == case['output'].strip())
        report['tests'].append(actual)
    report['passed'] = all(t['passed'] for t in report['tests'])
    return report


class RepairModel:
    def __init__(self, model, threads=4):
        from llama_cpp import Llama
        self.name = Path(model).name
        self.llm = Llama(model_path=str(model), n_ctx=4096, n_threads=threads,
                         n_gpu_layers=0, seed=42, verbose=False)

    def repair(self, source, requirement, feedback):
        prompt = ('Repair this C program. Implement the requirement for all valid inputs, not just the examples. '
                  'Do not hardcode test answers. Read stdin and write stdout without prompts. '
                  'Return the complete C source only, no explanation.\n'
                  'Requirement: ' + requirement + '\nCurrent source:\n```c\n' + source +
                  '\n```\nCompiler and execution feedback:\n' + json.dumps(feedback))
        start = time.monotonic()
        response = self.llm.create_chat_completion(
            messages=[{'role': 'system', 'content': 'You repair small C programs accurately.'},
                      {'role': 'user', 'content': prompt}],
            temperature=0, max_tokens=1200)
        raw = response['choices'][0]['message']['content'] or ''
        blocks = re.findall(r'```(?:c|C)?\s*\n(.*?)```', raw, re.S)
        code = blocks[0] if blocks else raw.strip()
        return code, {'raw_response': raw, 'seconds': round(time.monotonic()-start, 3),
                      'usage': response.get('usage'),
                      'finish_reason': response['choices'][0]['finish_reason']}


def repair_program(model, source, requirement, tests, compiler, output, max_repairs=3):
    output.mkdir(parents=True, exist_ok=True)
    original = source
    history = []
    with tempfile.TemporaryDirectory(prefix='aicc-') as tmp:
        work = Path(tmp)
        for attempt in range(max_repairs + 1):
            report = check(source, work, compiler, tests)
            history.append({'attempt': attempt, 'source': source, 'check': report})
            print(json.dumps({'attempt': attempt, 'compiled': report['compiled'],
                              'passed': sum(x['passed'] for x in report['tests']),
                              'tests': len(tests)}), flush=True)
            if report['passed']:
                shutil.copy2(work / 'program', output / 'program')
                break
            if attempt == max_repairs:
                break
            source, generation = model.repair(source, requirement, report)
            history[-1]['generation'] = generation
            (output / f'model_reply_{attempt+1}.txt').write_text(generation['raw_response'])
    (output / 'original.c').write_text(original)
    (output / 'repaired.c').write_text(source)
    summary = {'requirement': requirement, 'compiler': compiler, 'model': model.name,
               'inference': {'gpu_layers': 0, 'threads': 4, 'temperature': 0, 'seed': 42},
               'passed': history[-1]['check']['passed'],
               'status': ('tests_passed' if tests else 'compiled_only') if history[-1]['check']['passed'] else 'failed',
               'repairs': len(history)-1, 'history': history}
    (output / 'report.json').write_text(json.dumps(summary, indent=2))
    return summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', type=Path)
    req = p.add_mutually_exclusive_group(required=True)
    req.add_argument('--requirement')
    req.add_argument('--requirement-file', type=Path)
    p.add_argument('--tests', type=Path, help='JSON array of input/output objects')
    p.add_argument('--model', type=Path, default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
    p.add_argument('--compiler', default='tcc' if shutil.which('tcc') else 'gcc')
    p.add_argument('--output', type=Path, default=ROOT/'output')
    p.add_argument('--max-repairs', type=int, default=3)
    args = p.parse_args()
    compiler = shutil.which(args.compiler)
    if not compiler:
        p.error('Compiler unavailable: ' + args.compiler)
    model = RepairModel(args.model)
    requirement = args.requirement_file.read_text() if args.requirement_file else args.requirement
    report = repair_program(model, args.source.read_text(), requirement,
                            json.loads(args.tests.read_text()) if args.tests else [],
                            compiler, args.output, args.max_repairs)
    print('Result:', report['status'])
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
