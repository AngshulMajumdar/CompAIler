#!/usr/bin/env python3
"""Always review; diagnose failures; change strategy on stalls; retain passing tests."""
import argparse
import difflib
import json
from pathlib import Path
import re
import shutil
import tempfile
import time
from aicc import ROOT,RepairModel,check

POLICY={
 'version':2,'always_review':True,'max_model_calls':3,'seed_base':42,
 'first_temperature':0,'stalled_rewrite_temperatures':[0.2,0.4],
 'retain_previously_passing_tests':True,
 'feedback':'visible examples, compiler errors, prior patch and its observed effect',
 'heldout_feedback':False,'reference_implementation_in_prompt':False,
}

def feedback(report):
    return {'compiled':report['compiled'],'compiler':report['diagnostics'][-2500:],
            'passed':sum(t['passed'] for t in report['tests']),
            'failures':[{'input':t['input'],'expected':t['expected'],
                         'actual':t['stdout'],'stderr':t['stderr'],
                         'exit':t['returncode']} for t in report['tests'] if not t['passed']]}

def fingerprint(source):
    # Used only to detect repeated proposals; never substitutes for execution.
    return re.findall(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\d+(?:\.\d+)?|\S',source)

class ReviewModel(RepairModel):
    def propose(self,source,requirement,report,tests,previous,attempt,strategy):
        temperature=0 if strategy!='rewrite' else (0.2 if attempt==2 else 0.4)
        if strategy=='review':
            instruction=('Review the program against the complete requirement, including inputs absent from the examples. '
                         'Compilation or passing examples alone do not establish correctness. If the program is already '
                         'correct, return UNCHANGED; do not rewrite merely for formatting or style. Otherwise fix the actual bug.')
        elif strategy=='rewrite':
            instruction=('The previous approach stalled or regressed. Reimplement the affected computation from the '
                         'requirement using a fresh implementation; do not retain the previous faulty loop/index structure. '
                         'Preserve input/output behavior and every previously passing test.')
        else:
            instruction=('Diagnose the actual cause of the failing outputs or compiler errors and repair it. '
                         'Use a minimal semantic correction and preserve every previously passing test.')
        prompt=('Requirement:\n'+requirement+'\nCurrent best source:\n```c\n'+source+'\n```\n'
                +'Observed compiler/test feedback:\n'+json.dumps(feedback(report))+'\n'
                +'Visible regression examples:\n'+json.dumps(tests)+'\n'
                +('Previous attempt and effect:\n'+json.dumps(previous)+'\n' if previous else '')
                +instruction+'\nFirst write DIAGNOSIS: followed by one short sentence naming the cause. '
                'Then return the COMPLETE C program in one ```c block, or a line containing UNCHANGED if review finds no bug. '
                'Do not hardcode example answers or impose input restrictions absent from the requirement. '
                'Output no user prompts from the C program.')
        self.llm.set_seed(42+attempt)
        start=time.monotonic()
        response=self.llm.create_chat_completion(
          messages=[{'role':'system','content':'You audit and repair C programs. Explain the specific fault briefly before emitting code.'},
                    {'role':'user','content':prompt}],temperature=temperature,max_tokens=1200)
        raw=response['choices'][0]['message']['content'] or ''
        blocks=re.findall(r'```(?:c|C)?\s*\n(.*?)```',raw,re.S)
        unchanged=not blocks and bool(re.search(r'(?m)^UNCHANGED\s*$',raw))
        if blocks:code=blocks[0]
        elif unchanged:code=None
        else:code=raw.split('SOURCE:',1)[-1].strip()
        return code,{'raw_response':raw,'seconds':round(time.monotonic()-start,3),
                     'strategy':strategy,'temperature':temperature,'seed':42+attempt,
                     'usage':response.get('usage'),'finish_reason':response['choices'][0]['finish_reason'],
                     'unchanged':unchanged,'prompt':prompt}


def repair_program_v2(model,source,requirement,tests,compiler,output,max_calls=3):
    output.mkdir(parents=True,exist_ok=True)
    original=source;attempts=[];previous=None;stalled=False
    with tempfile.TemporaryDirectory(prefix='aicc-v2-') as tmp:
        work=Path(tmp)
        baseline=check(source,work,compiler,tests)
        best=baseline;best_source=source;seen=[fingerprint(source)]
        print('BASELINE',json.dumps({'compiled':baseline['compiled'],'passed':sum(t['passed'] for t in baseline['tests'])}),flush=True)
        for number in range(1,max_calls+1):
            strategy=('review' if baseline['passed'] else 'repair') if number==1 else ('rewrite' if stalled else 'repair')
            candidate,generation=model.propose(best_source,requirement,best,tests,previous,number,strategy)
            (output/f'model_reply_{number}.txt').write_text(generation['raw_response'])
            (output/f'prompt_{number}.txt').write_text(generation['prompt'])
            if candidate is None:
                record={'attempt':number,'generation':generation,'candidate':None,'accepted':False,
                        'check':None,'reason':'model_declared_unchanged'}
                attempts.append(record)
                if best['passed']:break
                previous={'effect':'Declared unchanged although tests still fail.','failures':feedback(best)}
                stalled=True;continue
            (output/f'candidate_{number}.c').write_text(candidate)
            result=check(candidate,work,compiler,tests)
            oldset={i for i,t in enumerate(best['tests']) if t['passed']}
            newset={i for i,t in enumerate(result['tests']) if t['passed']}
            regression=sorted(oldset-newset)
            repeated=fingerprint(candidate) in seen;seen.append(fingerprint(candidate))
            improves=(result['compiled'] and not best['compiled']) or len(newset)>len(oldset)
            accepted=result['compiled'] and not regression and (improves or (best['passed'] and result['passed']))
            diff=''.join(difflib.unified_diff(best_source.splitlines(True),candidate.splitlines(True),
                                            fromfile='best.c',tofile='proposal.c'))[:3000]
            record={'attempt':number,'generation':generation,'candidate':candidate,'check':result,
                    'accepted':accepted,'regressed_test_indices':regression,'repeated_tokens':repeated,
                    'passed_count_improved':improves,'diff':diff}
            attempts.append(record)
            previous={'patch':diff,'accepted':accepted,'repeated':repeated,'regressed_tests':regression,
                      'effect':feedback(result)}
            stalled=repeated or not improves or bool(regression)
            if accepted:best_source=candidate;best=result
            print('ATTEMPT',json.dumps({'number':number,'strategy':strategy,'accepted':accepted,
                                       'passed':len(newset),'regressions':len(regression),'repeated':repeated}),flush=True)
            if accepted and best['passed']:break
        final=check(best_source,work,compiler,tests)
        if final['passed']:shutil.copy2(work/'program',output/'program')
    (output/'original.c').write_text(original)
    (output/'repaired.c').write_text(best_source)
    report={'version':2,'model':model.name,'compiler':compiler,'requirement':requirement,'policy':POLICY,
            'baseline':baseline,'attempts':attempts,'passed':final['passed'],'final':final,
            'model_calls':len(attempts),'source_changed':best_source!=original,
            'generation_seconds':round(sum(a['generation']['seconds'] for a in attempts),3)}
    (output/'report.json').write_text(json.dumps(report,indent=2))
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path)
    req=p.add_mutually_exclusive_group(required=True)
    req.add_argument('--requirement');req.add_argument('--requirement-file',type=Path)
    p.add_argument('--tests',type=Path)
    p.add_argument('--compiler',default='tcc' if shutil.which('tcc') else 'gcc')
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
    p.add_argument('--output',type=Path,default=ROOT/'output_v2')
    args=p.parse_args()
    model=ReviewModel(args.model)
    report=repair_program_v2(model,args.source.read_text(),
      args.requirement_file.read_text() if args.requirement_file else args.requirement,
      json.loads(args.tests.read_text()) if args.tests else [],args.compiler,args.output)
    print('Result:',('tests_passed' if args.tests else 'compiled_only') if report['passed'] else 'failed')
    raise SystemExit(0 if report['passed'] else 1)

if __name__=='__main__':main()
