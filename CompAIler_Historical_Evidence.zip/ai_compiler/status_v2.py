"""Compact progress for an in-progress or completed comparison."""
import json
from aicc import ROOT
p=ROOT/'large_results_v2/summary.json'
if p.exists():
    s=json.loads(p.read_text())
    print({k:s[k] for k in ['completed','v2_validated','controls_passed','model_calls']},
          'regressions',s['regressions'])
lines=(ROOT/'v2_run.log').read_text().splitlines()
print('\n'.join([l for l in lines if not l.startswith(('PROGRESS','REFERENCE','FINISHED'))][-3:]))
