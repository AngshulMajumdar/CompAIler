"""Export reusable CLI inputs without changing the frozen suite."""
import json
from aicc import ROOT

cases=json.loads((ROOT/'large_program_suite/cases.json').read_text())['cases']
for c in cases:
    folder=ROOT/'large_program_suite/inputs'/c['id'];folder.mkdir(parents=True,exist_ok=True)
    (folder/'source.c').write_text(c['source'])
    (folder/'requirement.txt').write_text(c['requirement']+'\n')
    (folder/'visible_tests.json').write_text(json.dumps(c['visible'],indent=2))
print('Exported CLI inputs for',len(cases),'programs')
