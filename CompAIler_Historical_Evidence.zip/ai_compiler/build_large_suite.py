"""Construct a fixed synthetic suite; reference C/oracles are NEVER passed to the model."""
import json
import math
from pathlib import Path
import random

ROOT=Path(__file__).resolve().parent
R=random.Random(20261123)
TASKS=[]
HEAD='#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <ctype.h>\n#include <limits.h>\n'

def arr(a): return str(len(a))+'\n'+' '.join(map(str,a))+'\n'
def lines(a): return ' '.join(map(str,a))
def task(name, requirement, body, pairs, mutations):
    # First four distinct inputs are repair-visible; remaining inputs are held out.
    seen=set();tests=[]
    for i,o in pairs:
        if i not in seen: tests.append({'input':i,'output':str(o)});seen.add(i)
    assert len(tests)>=10,name
    clean=HEAD+'int main(void){\n'+body+'\nreturn 0;\n}\n'
    TASKS.append({'task':name,'requirement':requirement+' Output only the requested answer followed by a newline.',
                  'reference':clean,'visible':tests[:4],'hidden':tests[4:], 'mutations':mutations})

task('sum_to_n','Read n, 0 <= n <= 1000000. Print the sum of all integers from 1 through n, using an exact integer result.',
     'int n; scanf("%d",&n); long long s=(long long)n*(n+1)/2; printf("%lld\\n",s);',
     [(f'{n}\n',n*(n+1)//2) for n in [0,1,5,100000,2,3,1000000]+[R.randint(2,1000000) for _ in range(20)]],
     [('syntax','missing_semicolon','int n;','int n'),
      ('boundary','wrong_endpoint','n*(n+1)/2','n*(n-1)/2'),
      ('overflow','intermediate_int_overflow','(long long)n*','n*')])

task('factorial','Read n, 0 <= n <= 12. Print n factorial.',
     'int n; scanf("%d",&n); long long f=1; for(int i=1;i<=n;i++) f*=i; printf("%lld\\n",f);',
     [(f'{n}\n',math.factorial(n)) for n in [0,1,5,12,2,3,4,6,7,8,9,10,11]],
     [('initialization','zero_accumulator','long long f=1','long long f=0'),
      ('boundary','skipped_last_factor','i<=n','i<n'),
      ('pointer','scanf_missing_address','scanf("%d",&n)','scanf("%d",n)')])

means=[(1,2),(-3,0),(10,20),(-7,-2)]+[(R.randint(-10000,10000),R.randint(-10000,10000)) for _ in range(25)]
task('mean','Read two integers a and b in [-10000,10000]. Print their arithmetic mean with exactly two digits after the decimal point.',
     'int a,b; scanf("%d%d",&a,&b); double m=(a+b)/2.0; printf("%.2f\\n",m);',
     [(f'{a} {b}\n',f'{(a+b)/2:.2f}') for a,b in means],
     [('arithmetic','integer_division','(a+b)/2.0','(a+b)/2'),
      ('arithmetic','wrong_denominator','(a+b)/2.0','(a+b)/3.0'),
      ('sign','incorrect_absolute_value','(a+b)/2.0','abs(a+b)/2.0')])

arrays=[[-8,-2,-5],[9],[7,2,15,4],[-1,0,3]]+[[R.randint(-50,50) for _ in range(R.randint(1,20))] for _ in range(25)]
task('maximum','Read n, 1 <= n <= 100, followed by n integers in [-10000,10000]. Print the maximum value.',
     'int n,a[100]={0}; scanf("%d",&n); for(int i=0;i<n;i++) scanf("%d",&a[i]); int m=a[0]; for(int i=1;i<n;i++) if(a[i]>m)m=a[i]; printf("%d\\n",m);',
     [(arr(a),max(a)) for a in arrays],
     [('initialization','zero_maximum','int m=a[0]','int m=0'),
      ('comparison','minimum_instead','a[i]>m','a[i]<m'),
      ('boundary','skip_last_value','for(int i=1;i<n;i++)','for(int i=1;i<n-1;i++)')])

minarrays=[[8,2,5],[-9],[7,-15,2,4],[0,-1,3]]+[[R.randint(-50,50) for _ in range(R.randint(1,20))] for _ in range(25)]
task('minimum','Read n, 1 <= n <= 100, followed by n integers in [-10000,10000]. Print the minimum value.',
     'int n,a[100]={0}; scanf("%d",&n); for(int i=0;i<n;i++) scanf("%d",&a[i]); int m=a[0]; for(int i=1;i<n;i++) if(a[i]<m)m=a[i]; printf("%d\\n",m);',
     [(arr(a),min(a)) for a in minarrays],
     [('initialization','zero_minimum','int m=a[0]','int m=0'),
      ('comparison','maximum_instead','a[i]<m','a[i]>m'),
      ('boundary','omit_first_element','int m=a[0]','int m=a[1]')])

posarrays=[[0,-2,4],[3,1],[-5,-1],[2,0,-3,7]]+[[R.randint(-5,5) for _ in range(R.randint(1,30))] for _ in range(25)]
task('positive_count','Read n, 1 <= n <= 100, followed by n integers. Count strictly positive values; zero is not positive.',
     'int n,a[100]={0}; scanf("%d",&n); for(int i=0;i<n;i++) scanf("%d",&a[i]); int count=0; for(int i=0;i<n;i++) if(a[i]>0)count++; printf("%d\\n",count);',
     [(arr(a),sum(v>0 for v in a)) for a in posarrays],
     [('comparison','include_zero','a[i]>0','a[i]>=0'),
      ('boundary','skip_first_value','int count=0; for(int i=0;','int count=0; for(int i=1;'),
      ('arithmetic','sum_instead_of_count','count++','count+=a[i]')])

searches=[([5,2,5],5),([9],9),([1,2,3],7),([3,4,5],5)]
for _ in range(25):
    a=[R.randint(-4,4) for _ in range(R.randint(1,20))];searches.append((a,R.randint(-5,5)))
task('linear_search','Read n, 1 <= n <= 100, then n integers, then target x. Print the zero-based index of its FIRST occurrence, or -1 if absent.',
     'int n,a[100],x; scanf("%d",&n); for(int i=0;i<n;i++)scanf("%d",&a[i]); scanf("%d",&x); int at=-1; for(int i=0;i<n;i++)if(a[i]==x){at=i;break;} printf("%d\\n",at);',
     [(arr(a)+f'{x}\n',a.index(x) if x in a else -1) for a,x in searches],
     [('control_flow','last_occurrence','at=i;break;','at=i;'),
      ('indexing','one_based_index','at=i;','at=i+1;'),
      ('comparison','wrong_match_condition','a[i]==x','a[i]<=x')])

binary=[([1,3,5],5),([2],2),([1,3,5],2),([-4,0,8],-4)]
for _ in range(25):
    a=sorted(R.sample(range(-50,51),R.randint(1,25)));binary.append((a,R.randint(-55,55)))
task('binary_search','Read n, 1 <= n <= 100, then n DISTINCT integers in increasing order, then target x. Use binary search to print its zero-based index, or -1 if absent.',
     'int n,a[100],x;scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d",&a[i]);scanf("%d",&x);int l=0,r=n-1,at=-1;while(l<=r){int m=l+(r-l)/2;if(a[m]==x){at=m;break;}if(a[m]<x)l=m+1;else r=m-1;}printf("%d\\n",at);',
     [(arr(a)+f'{x}\n',a.index(x) if x in a else -1) for a,x in binary],
     [('control_flow','wrong_search_direction','a[m]<x','a[m]>x'),
      ('termination','nonshrinking_interval','r=m-1','r=m'),
      ('boundary','exclude_singleton_interval','while(l<=r)','while(l<r)')])

sorts=[[3,1,2],[2,1],[5],[0,-3,0,7,-1]]+[[R.randint(-20,20) for _ in range(R.randint(1,25))] for _ in range(25)]
task('sort','Read n, 1 <= n <= 100, followed by n integers. Print all values in increasing order, separated by single spaces, retaining duplicates.',
     'int n,a[100];scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d",&a[i]);for(int i=0;i<n-1;i++)for(int j=0;j+1<n-i;j++)if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;}for(int i=0;i<n;i++)printf("%s%d",i?" ":"",a[i]);puts("");',
     [(arr(a),lines(sorted(a))) for a in sorts],
     [('comparison','descending_order','a[j]>a[j+1]','a[j]<a[j+1]'),
      ('boundary','omit_last_pair','j+1<n-i','j+1<n-i-1'),
      ('assignment','broken_swap','a[j+1]=t','a[j+1]=a[j]')])

gcdpairs=[(12,18),(7,0),(0,9),(35,14)]+[(R.randint(0,1000),R.randint(1,1000)) for _ in range(25)]
task('gcd','Read nonnegative integers a,b <= 1000000, not both zero. Print their greatest common divisor.',
     'int a,b;scanf("%d%d",&a,&b);while(b!=0){int r=a%b;a=b;b=r;}printf("%d\\n",a);',
     [(f'{a} {b}\n',math.gcd(a,b)) for a,b in gcdpairs],
     [('arithmetic','quotient_not_remainder','int r=a%b','int r=a/b'),
      ('boundary','stop_at_one','while(b!=0)','while(b>1)'),
      ('variable','print_wrong_variable','printf("%d\\n",a)','printf("%d\\n",b)')])

lcmpairs=[(12,18),(999983,999979),(1,7),(24,36)]+[(R.randint(1,1000000),R.randint(1,1000000)) for _ in range(25)]
task('lcm','Read positive integers a,b <= 1000000. Print their least common multiple as an exact 64-bit integer.',
     'int a,b,x,y;scanf("%d%d",&a,&b);x=a;y=b;while(y){int r=x%y;x=y;y=r;}long long answer=(long long)a*b/x;printf("%lld\\n",answer);',
     [(f'{a} {b}\n',math.lcm(a,b)) for a,b in lcmpairs],
     [('arithmetic','omit_gcd_divisor','(long long)a*b/x','(long long)a*b'),
      ('variable','gcd_instead_of_lcm','(long long)a*b/x','x'),
      ('overflow','multiply_as_int','(long long)a*b/x','a*b/x')])

def isprime(n):return n>=2 and all(n%d for d in range(2,math.isqrt(n)+1))
nums=[1,4,7,0,2,3,9,25,49,97,121,997,1000]+[R.randint(0,10000) for _ in range(20)]
task('prime','Read n, 0 <= n <= 1000000. Print 1 if n is prime, otherwise 0.',
     'int n;scanf("%d",&n);int p=n>=2;for(int i=2;i*i<=n;i++)if(n%i==0){p=0;break;}printf("%d\\n",p);',
     [(f'{n}\n',int(isprime(n))) for n in nums],
     [('boundary','one_is_prime','int p=n>=2','int p=1'),
      ('boundary','miss_square_factor','i*i<=n','i*i<n'),
      ('comparison','inverted_divisibility','n%i==0','n%i!=0')])

def fib(n):
    a,b=0,1
    for _ in range(n):a,b=b,a+b
    return a
task('fibonacci','Read n, 0 <= n <= 45. Print F(n), where F(0)=0, F(1)=1, F(n)=F(n-1)+F(n-2).',
     'int n;scanf("%d",&n);long long a=0,b=1;for(int i=0;i<n;i++){long long t=a+b;a=b;b=t;}printf("%lld\\n",a);',
     [(f'{n}\n',fib(n)) for n in [0,1,8,45,2,3,4,5,6,7,9,10,15,20,25,30,35,40]],
     [('boundary','extra_iteration','i<n;i++','i<=n;i++'),
      ('initialization','zero_second_seed','a=0,b=1','a=0,b=0'),
      ('variable','print_next_fibonacci','printf("%lld\\n",a)','printf("%lld\\n",b)')])

powers=[(2,0),(-2,3),(3,4),(0,5)]+[(R.randint(-10,10),R.randint(0,9)) for _ in range(25)]
task('integer_power','Read integers a,e with -10 <= a <= 10 and 0 <= e <= 9. Print a raised to e as an exact integer. Define a^0=1, including 0^0.',
     'int a,e;scanf("%d%d",&a,&e);long long p=1;for(int i=0;i<e;i++)p*=a;printf("%lld\\n",p);',
     [(f'{a} {e}\n',a**e) for a,e in powers],
     [('initialization','zero_product','long long p=1','long long p=0'),
      ('arithmetic','add_not_multiply','p*=a','p+=a'),
      ('boundary','extra_factor','i<e','i<=e')])

words=['abc','a','racecar','Abba','xy','hello','xyzzy','12345','aAa','programming']+[''.join(R.choices('abCD012',k=R.randint(1,30))) for _ in range(20)]
task('reverse_string','Read one nonempty whitespace-free ASCII string of at most 100 characters. Print its characters in reverse order.',
     'char s[101];scanf("%100s",s);int n=strlen(s);for(int i=0;i<n;i++)putchar(s[n-1-i]);putchar(10);',
     [(s+'\n',s[::-1]) for s in words],
     [('indexing','print_forward','s[n-1-i]','s[i]'),
      ('boundary','omit_final_character','i<n','i<n-1'),
      ('syntax','missing_parenthesis','putchar(s[n-1-i]);','putchar(s[n-1-i];')])

pals=['Abba','racecar','ab','a','Aa','abba','12321','abcba','abca','xyyx','xyz','aAa']+words[10:]
task('palindrome','Read one nonempty whitespace-free ASCII string of at most 100 characters. Print 1 if it is a CASE-SENSITIVE palindrome, otherwise 0.',
     'char s[101];scanf("%100s",s);int n=strlen(s),p=1;for(int i=0;i<n/2;i++)if(s[i]!=s[n-1-i])p=0;printf("%d\\n",p);',
     [(s+'\n',int(s==s[::-1])) for s in pals],
     [('specification','ignore_case','s[i]!=s[n-1-i]','tolower(s[i])!=tolower(s[n-1-i])'),
      ('assignment','never_clear_flag',')p=0;',')p=1;'),
      ('indexing','compare_character_to_itself','s[i]!=s[n-1-i]','s[i]!=s[i]')])

vwords=['AEIOU','banana','xyz','Apple','a','e','HELLO','Education','12345','aEiOuX']+words[10:]
task('vowel_count','Read one nonempty whitespace-free ASCII string of at most 100 characters. Count letters a,e,i,o,u in EITHER case. Other characters do not count.',
     'char s[101];scanf("%100s",s);int c=0;for(int i=0;s[i];i++)if(strchr("aeiouAEIOU",s[i])!=NULL)c++;printf("%d\\n",c);',
     [(s+'\n',sum(c in 'aeiouAEIOU' for c in s)) for s in vwords],
     [('specification','lowercase_only','aeiouAEIOU','aeiou'),
      ('comparison','count_nonvowels','!=NULL','==NULL'),
      ('boundary','skip_first_character','int i=0;s[i]','int i=1;s[i]')])

digitnums=[-123,0,507,9,-99999,10000,987654321,1000000000]+[R.randint(-1000000000,1000000000) for _ in range(25)]
task('digit_sum','Read an integer x in [-1000000000,1000000000]. Print the sum of its decimal digits, ignoring its sign. The digit sum of zero is zero.',
     'int x;scanf("%d",&x);x=abs(x);int s=0;while(x){s+=x%10;x/=10;}printf("%d\\n",s);',
     [(f'{x}\n',sum(map(int,str(abs(x))))) for x in digitnums],
     [('sign','retain_negative_sign','x=abs(x);',''),
      ('arithmetic','quotient_as_digit','s+=x%10','s+=x/10'),
      ('initialization','start_at_one','int s=0','int s=1')])

years=[1900,2000,2024,2023,1600,1700,1800,2100,2400,1,4,100,400]+[R.randint(1,9999) for _ in range(20)]
task('leap_year','Read a Gregorian year y, 1 <= y <= 9999. Print 1 for leap years and 0 otherwise: divisible by 4, except centuries unless divisible by 400.',
     'int y;scanf("%d",&y);int leap=(y%4==0 && (y%100!=0 || y%400==0));printf("%d\\n",leap);',
     [(f'{y}\n',int(y%4==0 and (y%100!=0 or y%400==0))) for y in years],
     [('boolean','ignore_century_rule','(y%4==0 && (y%100!=0 || y%400==0))','(y%4==0)'),
      ('boolean','and_instead_of_or','y%100!=0 || y%400==0','y%100!=0 && y%400==0'),
      ('comparison','invert_400_rule','y%400==0','y%400!=0')])

matrices=[[[1,2,3],[4,5,6]],[[7]],[[1],[2],[3]],[[1,2],[3,4]]]
for _ in range(20):
    r,c=R.randint(1,5),R.randint(1,5);matrices.append([[R.randint(-20,20) for _ in range(c)] for _ in range(r)])
mpairs=[]
for a in matrices:
    r,c=len(a),len(a[0]);mpairs.append((f'{r} {c}\n'+'\n'.join(lines(row) for row in a)+'\n','\n'.join(lines(col) for col in zip(*a))))
task('matrix_transpose','Read row count r and column count c, each 1..5, followed by an r-by-c integer matrix. Print its transpose as c rows of r integers, single spaces between values.',
     'int r,c,a[5][5]={{0}};scanf("%d%d",&r,&c);for(int i=0;i<r;i++)for(int j=0;j<c;j++)scanf("%d",&a[i][j]);for(int i=0;i<c;i++){for(int j=0;j<r;j++)printf("%s%d",j?" ":"",a[j][i]);puts("");}',
     mpairs,
     [('indexing','wrong_element_indices','j?" ":"",a[j][i]','j?" ":"",a[i][j]'),
      ('shape','wrong_output_row_count','for(int i=0;i<c;i++){','for(int i=0;i<r;i++){'),
      ('shape','wrong_output_column_count','for(int j=0;j<r;j++)printf','for(int j=0;j<c;j++)printf')])

dots=[([1,2],[3,4]),([100000,100000],[100000,100000]),([-2,3],[4,-5]),([9],[7])]
for _ in range(25):
    n=R.randint(1,20);dots.append(([R.randint(-100000,100000) for _ in range(n)],[R.randint(-100000,100000) for _ in range(n)]))
task('dot_product','Read n, 1 <= n <= 100, followed by n integers for vector a and then n for vector b, each in [-100000,100000]. Print their exact 64-bit integer dot product.',
     'int n,a[100],b[100];scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d",&a[i]);for(int i=0;i<n;i++)scanf("%d",&b[i]);long long s=0;for(int i=0;i<n;i++)s+=(long long)a[i]*b[i];printf("%lld\\n",s);',
     [(arr(a)+lines(b)+'\n',sum(x*y for x,y in zip(a,b))) for a,b in dots],
     [('arithmetic','add_components','(long long)a[i]*b[i]','(long long)a[i]+b[i]'),
      ('indexing','repeat_first_component','a[i]*b[i]','a[i]*b[0]'),
      ('overflow','int_multiplication','(long long)a[i]*b[i]','a[i]*b[i]')])

pref=[[1,2,3],[-2,5,-1],[7],[0,0,4]]+[[R.randint(-30,30) for _ in range(R.randint(1,25))] for _ in range(25)]
prefpairs=[]
for a in pref:
    sums=[];s=0
    for x in a:s+=x;sums.append(s)
    prefpairs.append((arr(a),lines(sums)))
task('prefix_sums','Read n, 1 <= n <= 100, followed by n integers in [-10000,10000]. Print the n inclusive prefix sums, separated by single spaces.',
     'int n,a[100];scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d",&a[i]);long long s=0;for(int i=0;i<n;i++){s+=a[i];printf("%s%lld",i?" ":"",s);}puts("");',
     prefpairs,
     [('state','reset_running_sum','s+=a[i]','s=a[i]'),
      ('arithmetic','subtract_values','s+=a[i]','s-=a[i]'),
      ('boundary','exclusive_prefix','i?" ":"",s','i?" ":"",s-a[i]')])

def balanced(s):
    stack=[];match={')':'(',']':'[','}':'{'}
    for ch in s:
        if ch in '([{':stack.append(ch)
        elif not stack or stack.pop()!=match[ch]:return 0
    return int(not stack)
brackets=['([)]','(','()','{[()]}','[]{}','((()))',')','[[]]','({})','{]','(()','()()']+[''.join(R.choices('()[]{}',k=R.randint(1,25))) for _ in range(20)]
task('balanced_brackets','Read one nonempty whitespace-free string of at most 100 characters containing only ()[]{}. Print 1 exactly when brackets match in type and are properly nested with none left open; otherwise print 0.',
     'char s[101],st[101];scanf("%100s",s);int top=0,ok=1;for(int i=0;s[i];i++){char c=s[i];if(c==40||c==91||c==123)st[top++]=c;else{char want=c==41?40:(c==93?91:123);if(top==0||st[top-1]!=want){ok=0;break;}top--;}}printf("%d\\n",ok&&top==0);',
     [(s+'\n',balanced(s)) for s in brackets],
     [('state','ignore_bracket_type','top==0||st[top-1]!=want','top==0'),
      ('boundary','ignore_unclosed_brackets','ok&&top==0','ok'),
      ('boolean','incorrect_empty_stack_test','top==0||st[top-1]!=want','top!=0||st[top-1]!=want')])

uniques=[[1,1,2,3],[7],[-2,-2,-2],[0,1,2,3]]+[sorted(R.choices(range(-8,9),k=R.randint(1,25))) for _ in range(25)]
task('distinct_count','Read n, 1 <= n <= 100, then n integers sorted in nondecreasing order. Print the number of distinct values.',
     'int n,a[100];scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d",&a[i]);int c=1;for(int i=1;i<n;i++)if(a[i]!=a[i-1])c++;printf("%d\\n",c);',
     [(arr(a),len(set(a))) for a in uniques],
     [('comparison','count_repeated_values','a[i]!=a[i-1]','a[i]==a[i-1]'),
      ('initialization','forget_first_group','int c=1','int c=0'),
      ('variable','print_length','printf("%d\\n",c)','printf("%d\\n",n)')])


def build():
    cases=[]
    for t in TASKS:
        for k,(category,label,old,new) in enumerate(t['mutations'],1):
            assert old in t['reference'],(t['task'],label)
            broken=t['reference'].replace(old,new,1)
            cases.append({'id':f'{t["task"]}_{k}_{label}','task':t['task'],'kind':'faulty',
                          'category':category,'defect':label,'source':broken,
                          **{key:t[key] for key in ['requirement','visible','hidden']}})
    for t in TASKS[:8]:
        # A syntax defect and a logical defect in the same program.
        old,new=t['mutations'][0][2:]
        broken=t['reference'].replace(old,new,1)
        old,new=t['mutations'][1][2:]
        if old in broken:broken=broken.replace(old,new,1)
        # Force a separate syntax error so every mixed case requires both kinds of repair.
        broken=broken.replace('return 0;','return 0',1)
        cases.append({'id':t['task']+'_mixed','task':t['task'],'kind':'faulty',
                      'category':'multiple_faults','defect':'multiple defects including missing semicolon',
                      'source':broken,**{key:t[key] for key in ['requirement','visible','hidden']}})
    for t in TASKS[::3]:
        cases.append({'id':t['task']+'_clean_control','task':t['task'],'kind':'clean_control',
                      'category':'correct_control','defect':'none','source':t['reference'],
                      **{key:t[key] for key in ['requirement','visible','hidden']}})
    dest=ROOT/'large_suite';dest.mkdir(exist_ok=True)
    (dest/'cases.json').write_text(json.dumps(cases,indent=2))
    refs=dest/'references';refs.mkdir(exist_ok=True)
    for t in TASKS:(refs/(t['task']+'.c')).write_text(t['reference'])
    print(json.dumps({'tasks':len(TASKS),'faulty':sum(c['kind']=='faulty' for c in cases),
                      'controls':sum(c['kind']=='clean_control' for c in cases),
                      'heldout_checks':sum(len(c['hidden']) for c in cases)}))
    return cases

if __name__=='__main__':build()
