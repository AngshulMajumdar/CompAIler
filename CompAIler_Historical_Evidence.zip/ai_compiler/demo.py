"""Run predetermined toy repairs using the downloaded model, with no manual patches."""
import json
import argparse
from pathlib import Path
import shutil
from aicc import RepairModel, repair_program

ROOT = Path(__file__).resolve().parent
TCC = ROOT/'vendor/tcc-0.9.27/install/bin/tcc'
COMPILER = str(TCC) if TCC.exists() else (shutil.which('tcc') or shutil.which('gcc'))
CASES = [
    ('factorial', 'Read an integer n, 0 <= n <= 12, and print n factorial followed by a newline.',
     '#include <stdio.h>\nint main(void) { int n; scanf("%d", &n); long long f=1\n for(int i=1;i<n;i++) f*=i; printf("%lld\\n",f); return 0; }\n',
     [('0\n','1'),('1\n','1'),('5\n','120'),('10\n','3628800')]),
    ('mean', 'Read two integers between -10000 and 10000. Print their arithmetic mean with exactly two decimal places and a newline.',
     '#include <stdio.h>\nint main(void) { int a,b; scanf("%d%d", &a,&b); double m=(a+b)/2; printf("%.2f\\n",m); return 0; }\n',
     [('1 2\n','1.50'),('-3 0\n','-1.50'),('10 20\n','15.00')]),
    ('maximum', 'Read n (1 <= n <= 100), then n integers. Print the largest integer and a newline. Values can be negative.',
     '#include <stdio.h>\nint main(void) { int n,x,m=0; scanf("%d",&n); for(int i=0;i<n;i++){scanf("%d",&x);if(x>m)m=x;} printf("%d\\n",m); return 0; }\n',
     [('3\n-8 -2 -5\n','-2'),('1\n-99\n','-99'),('4\n3 9 2 7\n','9')]),
]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',type=Path,default=ROOT/'model/qwen2.5-coder-7b-instruct-q4_k_m.gguf')
    p.add_argument('--output',type=Path,default=ROOT/'results')
    args=p.parse_args()
    model = RepairModel(args.model)
    results=[]
    for name, requirement, source, pairs in CASES:
        print('CASE', name, flush=True)
        tests=[{'input':i,'output':o} for i,o in pairs]
        ex=ROOT/'examples'/name;ex.mkdir(parents=True,exist_ok=True)
        (ex/'broken.c').write_text(source)
        (ex/'tests.json').write_text(json.dumps(tests,indent=2))
        (ex/'requirement.txt').write_text(requirement+'\n')
        report=repair_program(model,source,requirement,tests,COMPILER,args.output/name)
        results.append({'case':name,'passed':report['passed'],'repairs':report['repairs'],
                        'seconds':sum(h.get('generation',{}).get('seconds',0) for h in report['history'])})
    (args.output/'summary.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results,indent=2),flush=True)

if __name__=='__main__':main()
