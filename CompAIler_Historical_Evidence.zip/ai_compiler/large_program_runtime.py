"""Same repair policy, larger context/output capacity, and bounded runaway-output feedback."""
import copy
import json
from pathlib import Path
import time
from aicc_v2 import ReviewModel

CONFIG={'context_tokens':16384,'max_output_tokens':6144,'cpu_threads':4,'gpu_layers':0,
        'batch_tokens':256,'stdout_feedback_characters':512,'stderr_feedback_characters':256,
        'model':'Qwen2.5-Coder-7B-Instruct Q4_K_M','maximum_model_calls':5}

class Backend:
    def __init__(self,model,log):self.model=model;self.log=log;self.calls=0
    def __getattr__(self,name):return getattr(self.model,name)
    def create_chat_completion(self,**kwargs):
        from llama_cpp import LogitsProcessorList
        self.calls+=1;number=self.calls;start=time.monotonic();last=start;base=None
        kwargs['max_tokens']=CONFIG['max_output_tokens']
        def progress(ids,scores):
            nonlocal last,base
            if base is None:base=len(ids)
            now=time.monotonic()
            if now-last>=25:
                print('MODEL_PROGRESS',json.dumps({'call':number,'seconds':round(now-start),
                                                  'output_tokens_so_far':len(ids)-base}),flush=True);last=now
            return scores
        kwargs['logits_processor']=LogitsProcessorList([progress])
        print('MODEL_BEGIN',json.dumps({'call':number,'input_characters':sum(len(x['content']) for x in kwargs['messages']),
                                       'max_output_tokens':kwargs['max_tokens']}),flush=True)
        result=self.model.create_chat_completion(**kwargs)
        entry={'call':number,'seconds':round(time.monotonic()-start,3),'usage':result.get('usage'),
               'finish_reason':result['choices'][0]['finish_reason'],'config':CONFIG}
        with self.log.open('a') as f:f.write(json.dumps(entry)+'\n')
        print('MODEL_END',json.dumps(entry),flush=True)
        return result

class LargeProgramModel(ReviewModel):
    def __init__(self,path,log):
        from llama_cpp import Llama
        self.name=Path(path).name
        model=Llama(model_path=str(path),n_ctx=CONFIG['context_tokens'],n_threads=CONFIG['cpu_threads'],
                    n_threads_batch=CONFIG['cpu_threads'],n_batch=CONFIG['batch_tokens'],n_gpu_layers=0,
                    seed=42,verbose=False)
        self.llm=Backend(model,log)
    def propose(self,source,requirement,report,tests,previous,attempt,strategy):
        report=copy.deepcopy(report)
        for test in report['tests']:
            for key,limit in [('stdout',512),('stderr',256)]:
                if len(test[key])>limit:test[key]=test[key][:limit]+'\n[feedback truncated; full output retained in test report]'
        def bounded(value):
            if isinstance(value,dict):
                return {k:(v[:512]+' [feedback truncated]' if k in ['actual','stderr','stdout'] and isinstance(v,str) and len(v)>512
                           else bounded(v)) for k,v in value.items()}
            if isinstance(value,list):return [bounded(v) for v in value]
            return value
        return super().propose(source,requirement,report,tests,bounded(previous),attempt,strategy)
