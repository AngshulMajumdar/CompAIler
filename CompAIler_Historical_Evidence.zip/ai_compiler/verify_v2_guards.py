"""Integration checks of regression acceptance using stub proposals, not LLM trial results."""
import json
from pathlib import Path
import tempfile
from aicc import ROOT
from aicc_v2 import repair_program_v2

class Stub:
    name='stub-proposals-for-guard-check-only'
    def __init__(self,proposals):self.proposals=iter(proposals);self.inputs=[]
    def propose(self,source,requirement,report,tests,previous,attempt,strategy):
        self.inputs.append((source,strategy));code=next(self.proposals)
        raw='UNCHANGED' if code is None else '```c\n'+code+'```'
        return code,{'raw_response':raw,'prompt':'guard integration check, no model invoked',
                     'seconds':0,'unchanged':code is None,'finish_reason':'stop'}

def main():
    compiler=str(ROOT/'vendor/tcc-0.9.27/install/bin/tcc')
    base='#include <stdio.h>\nint main(void){int x;scanf("%d",&x);printf("%d\\n",x);return 0;}\n'
    wrong=base.replace('printf("%d\\n",x)','printf("%d\\n",4)')
    good=base.replace('printf("%d\\n",x)','printf("%d\\n",x*x)')
    tests=[{'input':'1\n','output':'1'},{'input':'2\n','output':'4'}]
    with tempfile.TemporaryDirectory(prefix='v2-guards-') as tmp:
        model=Stub([wrong,good])
        report=repair_program_v2(model,base,'Read an integer and print its square.',tests,compiler,Path(tmp)/'regression')
        assert report['passed']
        assert not report['attempts'][0]['accepted']
        assert report['attempts'][0]['regressed_test_indices']==[0]
        assert model.inputs[1]==(base,'rewrite')
        assert (Path(tmp)/'regression/repaired.c').read_text()==good
        model=Stub([None])
        correct=repair_program_v2(model,good,'Read an integer and print its square.',tests,compiler,Path(tmp)/'correct')
        assert correct['passed'] and not correct['source_changed'] and model.inputs[0][1]=='review'
    result={'regression_rejected':True,'best_source_retained':True,'stalled_strategy_changed':True,
            'already_passing_code_reviewed':True,'unchanged_correct_source_retained':True,
            'test_type':'stub-proposal integration checks, not measured LLM performance'}
    (ROOT/'v2_guard_checks.json').write_text(json.dumps(result,indent=2));print(result)

if __name__=='__main__':main()
