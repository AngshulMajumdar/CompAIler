"""Exercise boundaries, edit confinement, syntax rejection and behavior preservation."""
import json
from pathlib import Path
import tempfile
from aicc import ROOT,check
from chunk_compile import functions,groups,apply_edits,accept
from run_large_programs import COMPILER

def main():
    cases=json.loads((ROOT/'large_program_suite/cases.json').read_text())['cases']
    for c in cases:
        fs=functions(c['source']);assert len(fs)==c['metadata']['functions'],(c['id'],len(fs))
        assert len({f['name'] for f in fs})==len(fs)
        assert all(a['end']<=b['start'] for a,b in zip(fs,fs[1:]))
        assert all(f['text'].startswith(f['signature']) for f in fs)
        gs=groups(c['source']);assert sorted(sum(gs,[]))==sorted(f['name'] for f in fs)
    sample='int f(void) { /* } */ const char *s="{"; return s[0]; }\nint main(void) { return f(); }\n'
    assert [f['name'] for f in functions(sample)]==['f','main']
    for edits in [[{'old':'return f();','new':'return 0;'}],[{'old':'absent','new':'0'}]]:
        try:apply_edits(sample,['f'],edits)
        except ValueError:pass
        else:raise AssertionError('Escaped or absent edit accepted')
    src='#include <stdio.h>\nint main(void) { puts("OK"); return 0; }\n'
    spaced='int f(void) {\n    int x = 1;\n    return x;\n}\n'
    changed=apply_edits(spaced,['f'],[{'old':'int x = 1;\nreturn x;','new':'return 2;'}])
    assert 'return 2;' in changed
    try:apply_edits(src,['main'],[{'old':'puts("DIFFERENT")','new':'puts("BAD")'}])
    except ValueError:pass
    else:raise AssertionError('String literal tokens were ignored')
    tests=[{'input':'','output':'OK'}]
    with tempfile.TemporaryDirectory() as tmp:
        w=Path(tmp);good=check(src,w,COMPILER,tests);assert good['passed']
        invalid=apply_edits(src,['main'],[{'old':'return 0;','new':'return ;;;;; BROKEN'}])
        assert accept(good,check(invalid,w,COMPILER,tests))==(False,'compiler_rejected')
        wrong=apply_edits(src,['main'],[{'old':'puts("OK")','new':'puts("WRONG")'}])
        assert accept(good,check(wrong,w,COMPILER,tests))==(False,'visible_regression')
        assert accept(good,good)[0]
    result={'all_eight_sources_split_into_expected_functions':True,'strings_and_comments_ignored':True,
       'out_of_chunk_and_absent_edits_rejected':True,'compiler_rejects_malformed_C':True,
       'visible_regression_rejected':True,'neutral_compiling_edits_allowed':True}
    (ROOT/'chunk_guard_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))

if __name__=='__main__':main()
