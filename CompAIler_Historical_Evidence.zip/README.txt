CompAIler historical evidence: frozen files

Assembled 24 November 2026 without running experiments or modifying the archived original files. SHA256.json maps paths relative to ai_compiler/ to SHA-256 digests. All archive members have been checked against those digests.

Includes historical Python controllers and utilities, large-program fixtures, complete-function proposal records, local/dependency search journals, and final native verification/audit records. Clean reference sources are verification oracles, not inputs to repair.

This evidence is separate from GitHub release 5678ce91c1d3514c494637851924a555966e97c8. The pinned release alone does not contain these historical controllers and journals. Publish this archive alongside the project before describing the entire historical evidence as publicly downloadable.

No model weights, compiler binaries, cached executables, or bundled Python environment are included. Historical scripts assume their ROOT is the ai_compiler directory and may use historical installation paths. They require an appropriate Linux sandbox (bubblewrap/seccomp), TinyCC/GCC, and for fresh inference the separately installed llama-cpp-python and Qwen GGUF. Inspect paths and dependencies before attempting replay. Availability of frozen scripts is not a guarantee of byte-identical regeneration on another machine. Some historical scripts resume from existing outputs. This archive was not replayed to certify portable fresh-run reproduction.

Recorded historical audits and independent release checks are distinct. The original 24 evaluation scenarios were used during development. Test ordering: 4 visible, 2 adopted boundary, 24 original evaluation, 24 seed-2402, 24 final post-selection seed-2403. Only the last group is explicitly untouched post-selection verification.
